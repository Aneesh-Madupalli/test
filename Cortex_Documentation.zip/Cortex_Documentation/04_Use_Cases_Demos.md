# Use Cases & Demos

**Page URL:** https://cortex.lilly.com/spe/documentation/use-cases-and-demos/

---

## Overview

This section contains examples and walkthroughs demonstrating Cortex capabilities.

- **End-to-End Walkthroughs:** Step-by-step guides for common use cases
- **Training & Demos:** Video tutorials and feature demonstrations

---

## Sub-pages

- [End-to-End Walkthroughs](/spe/documentation/use-cases-and-demos/end-to-end-walkthroughs/)
- [Training and Demos](/spe/documentation/use-cases-and-demos/training-and-demos/)
