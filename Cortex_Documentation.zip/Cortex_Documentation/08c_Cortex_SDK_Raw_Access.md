# Cortex SDK (Building on Cortex Services)

**Page URL:** https://cortex.lilly.com/spe/documentation/building-on-cortex-services/getting-raw-model-access/cortex-sdk/

---

## Installation

```bash
pip install elilillyco-cortex-sdk
```

> Hosted in Lilly's Artifactory. Configure pip index URL to access it.

---

## What the SDK Provides

Clients for:
- Model configuration and management
- Model ask/chat endpoints
- Data management
- Prompt configuration
- Toolkit management
- Job scheduling

See [Cortex Platform SDK](/spe/documentation/api-and-sdks/sdks/cortex-platform-sdk/) for detailed usage and examples.
