# Select a Model

**Page URL:** https://cortex.lilly.com/spe/documentation/building-on-cortex-services/getting-raw-model-access/select-a-model/

---

## View Available Models

- **Landing Zone:** cortex.lilly.com/spe/landing-zone/llms
- **API:** `GET /model/classes/list`

---

## Model Providers

- **OpenAI** – GPT-4o, GPT-4 Turbo, o-series
- **Anthropic** – Claude 3.5 Sonnet, Claude 3 Haiku
- **Google Vertex** – Gemini models
- **Amazon Bedrock** – Nova, Titan
- **Meta** – Llama models

---

## Model Configuration

Note the `model_class` and `model_iteration` values when you find a model — you'll need these when creating your config.
