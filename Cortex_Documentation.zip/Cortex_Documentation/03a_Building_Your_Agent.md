# Building Your Agent

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/building-your-agent/

---

## Overview

This guide walks you through building an agent on the Cortex platform. Agents can be configured in several ways depending on your needs - from basic LLM chat to complex multi-agent systems with data retrieval and tool execution.

---

## Building Blocks

### 1. Add Data
Connect your agent to data sources through RAG (Retrieval-Augmented Generation). This allows your agent to retrieve and reference specific information from your documents, databases, or other data sources when answering questions.

### 2. Add Tools
Extend your agent's capabilities by connecting it to tools. Tools allow your agent to perform actions like making API calls, querying databases, or executing custom functions.

### 3. Modify Prompts
Customize how your agent behaves by creating and configuring system prompts. Prompts guide the agent's tone, personality, and response style.

### 4. Add Security (Cortex Guard)
Implement security scanning to ensure all inputs and outputs are logged and monitored. Cortex automatically logs all interactions to the Cortex Guard Security Service.

### 5. Realtime Voice Setup and Integration
Enable voice-based interactions for your agent using the Realtime API. Adds voice wrapper on top of your existing text-based agent while maintaining full consistency with your configured prompts, tools, and data sources.

### 6. Special Cases
Handle advanced scenarios such as fine-tuning LLMs for specific tasks or working with large datasets stored in S3.

---

## Sub-pages

- [Add Data](/spe/documentation/guides/building-your-agent/add-data/)
- [Add Tools](/spe/documentation/guides/building-your-agent/add-tools/)
- [Modify Prompts](/spe/documentation/guides/building-your-agent/modify-prompts/)
- [Add Security (Cortex Guard)](/spe/documentation/guides/building-your-agent/add-security/)
- [Realtime Voice Setup and Integration](/spe/documentation/guides/building-your-agent/realtime-voice-setup-and-integration/)
- [Special Cases](/spe/documentation/guides/building-your-agent/special-cases/)
