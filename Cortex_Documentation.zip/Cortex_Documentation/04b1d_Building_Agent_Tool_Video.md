# Building an Agent Tool (Training Video)

**Page URL:** https://cortex.lilly.com/spe/documentation/use-cases-and-demos/training-and-demos/training-videos/building-an-agent-tool/

---

This video explains:

- Different workflow types in Cortex: model-only, RAG, and agentic
- How to build a custom agent tool
- How tools extend LLM capabilities beyond text responses
- How gRPC and Protocol Buffers enable language-agnostic communication between Cortex and your tool servers
