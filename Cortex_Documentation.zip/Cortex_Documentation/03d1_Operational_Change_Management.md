# Operational Change Management

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/preparing-for-release/operational-change-management/

---

## Overview

This guide covers considerations for deploying Cortex agents to production environments.

---

## Environment Promotion

Cortex supports separate development and production environments. When promoting to production:

1. **Validate in development** — Test configuration changes in the dev environment first
2. **Use managed configurations** — Production configurations should be managed via the GitHub PR workflow
3. **Deploy to production** — Merged PRs automatically propagate changes to the production Cortex platform

---

## Pre-Production Checklist

Before deploying to production, verify:

- [ ] Configuration tested in development environment
- [ ] PR reviewed and approved by designated team owners
- [ ] Observability dashboards configured to monitor the agent

---

## Benefits of Controlled Change Management

| Benefit | Description |
|---------|-------------|
| Improved reliability | Reduces configuration drift and manual errors |
| Auditability | Tracks who changed what and when via Git history |
| Quick rollback | Revert PRs to restore previous configurations |
| Access control | Only authorized team members can approve changes |
