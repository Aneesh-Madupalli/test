# Research Assistant (AIDA) — AI Drafting Assistant

**Page URL:** https://cortex.lilly.com/spe/documentation/ai-products/research-assistant/

---

## Overview

AIDA is an AI-powered drafting assistant that helps users create draft content for regulatory and technical documents. Users work with pre-configured prompt templates, customize them, regenerate outputs, and download drafts.

---

## Key Capabilities

- Draft content generation for regulatory documents
- Pre-configured prompt templates (can be edited)
- Regenerate output multiple times
- Download drafts as Excel or Word files

---

## Cortex Integration

AIDA uses the Cortex Platform API for AI capabilities.
