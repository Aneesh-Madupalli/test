# GenAI Lightning Demos

**Page URL:** https://cortex.lilly.com/spe/documentation/use-cases-and-demos/training-and-demos/genai-lightning-demos/

---

## GenAI Lightning Demos | March 19, 2025

357 people attended this event to learn and collaborate about GenAI at Lilly. The page contains a video recording from the session.

**No access to the video?** Request access via the link on the page.
