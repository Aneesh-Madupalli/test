# IIAB - Projects

**Page URL:** https://cortex.lilly.com/spe/documentation/ai-products/insights-in-a-box/user-guide/projects/

---

## Overview

A Project is where analysis extraction happens — linked documents as workspace rows and prompts as columns defining what insights to extract.

---

## Project Common Actions

- **Add Project:** Start Project Set Up, select Project type
- **View Project:** Open the project workspace
- **Edit Project:** Update details, add/edit Tags and Metadata
- **Delete Project:** Remove a project (Project Owner only)
- **Manage User Access:** Manage membership and requests
- **Favorite:** Mark for quick access
- **Share Project link:** Copy direct link

---

## Project Types

### Public Projects
- Accessible to all Vault members based on their Vault role
- Vault Owners & Editors: can edit & create public projects
- Vault Viewers: view-only, cannot create public projects
- **Deletion:** Vault Owners can delete any public project; Editors can only delete projects they own

### Private Projects
- Accessible only to creator and explicitly granted users
- All vault members can create private projects
- Project Owners who are Vault Owners/Editors can grant access to vault members and non-vault members
- Project Owners who are Vault Viewers cannot share private projects

---

## Document Scope Actions

Projects do not upload documents. Instead:
- **Link** Vault documents into the Project
- **Unlink** documents to remove them from analysis scope

---

## Chatbot

AI-powered assistant available as a floating widget (bottom-right corner):
- Ask questions about your project's extracted data with reference to source documents
- Requires at least one completed document extraction before use
- Start new conversations, switch AI models, retry failed messages, resize or expand to fullscreen
