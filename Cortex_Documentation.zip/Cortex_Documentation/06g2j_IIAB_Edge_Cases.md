# IIAB - Edge Cases

**Page URL:** https://cortex.lilly.com/spe/documentation/ai-products/insights-in-a-box/user-guide/edge-cases/

---

## Overview

Common edge cases across the application to help anticipate and handle scenarios outside the typical workflow.

---

## Edge Cases by Area

| Area | Edge Case |
|------|-----------|
| Organization | If you only have access to one Organization, switching is not needed |
| Vaults | A new Organization may have no Vaults yet; a Vault may have no documents yet |
| Projects | A Vault can have no Projects yet; a Project can exist with no linked documents yet |
| Columns | If no columns exist, add them before running meaningful analysis |
| Prompts | Editing a template does not automatically update columns that previously used it |
| Run Analysis | If there are no linked documents, there's nothing to analyze; after updating columns/prompts, a preview run is a good first step |
| Export | If a project has no results yet, export won't be meaningful |
