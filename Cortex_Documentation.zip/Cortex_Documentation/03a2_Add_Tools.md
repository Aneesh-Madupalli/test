# Add Tools

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/building-your-agent/add-tools/

---

## Overview

Tools extend your agent's capabilities beyond text generation, enabling it to perform actions like making API calls, querying databases, executing calculations, or interacting with external systems.

---

## What are Tools?

Tools are functions or services that your agent can invoke to perform specific tasks. When a user submits a query, the agent evaluates available tools and dynamically selects appropriate ones to complete the request.

---

## Types of Tool Integrations

### Marketplace Tools
Pre-built tools available in the Cortex toolkit marketplace, including database query tools, API integrations, file processing, and data transformation capabilities.

### Custom Tools
Tools you build for specific use cases. Custom tools can access internal APIs, implement business logic, integrate with third-party services, and provide specialized data processing.

---

## Sub-pages

- [Use the Tool Marketplace](/spe/documentation/guides/building-your-agent/add-tools/use-tool-marketplace/)
- [Build a Custom Tool](/spe/documentation/guides/building-your-agent/add-tools/build-custom-tool/)
