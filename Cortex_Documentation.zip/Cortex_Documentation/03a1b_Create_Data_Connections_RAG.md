# Create Data Connections for RAG

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/building-your-agent/add-data/create-data-connections-rag/

---

## Overview

Creating a data connection for RAG involves setting up a data configuration that specifies how your documents will be processed, stored, and retrieved. This configuration includes settings for embedding models, vector stores, chunking strategies, and access permissions.

---

## Components

A data configuration includes:

- **Document Store:** A vector database where documents are indexed (Pinecone, Elasticsearch, or Index Factory)
- **Embedding Model:** Converts text into numerical representations for semantic search
- **Chunking Strategy:** Determines how documents are broken into retrievable pieces
- **Access Controls:** Defines who can access and use the data configuration

---

## Prerequisites

- The embedded model list compatible with your LLM (`GET /data/embeddings/list`)
- The model class name for your LLM
- An S3 prefix for storing your data

---

## Step-by-Step Procedure

### Step 1-2: Access API Documentation

Navigate to the Cortex API documentation. Key endpoints:
- `POST /data/` - Set Data Config
- `POST /data/upload/{name}` - Data Upload Handler
- `GET /data/list-files/{name}` - List Files
- `GET /data/embeddings/list` - List Embeddings

### Step 3: Set Up Data Config

```json
{
  "name": "mydemo-data-1",
  "auth": {
    "owners": ["testuser@lilly.com"],
    "owners_group": [],
    "access_groups": [],
    "users": [],
    "private": true
  },
  "s3_bucket": "lly-light-dev",
  "s3_prefix": "llm-dev",
  "s3_prefix_data": "data/mydemo-1/docs",
  "displayName": "My Demo Data",
  "data_config_description": "Sample data configuration for RAG",
  "embedding": {
    "model": "text-embedding-3-small",
    "open_api_type": "azure"
  },
  "model_version": {
    "model_class": "lilly-openai",
    "model_iteration": "7"
  },
  "vectorstore": "pinecone",
  "allowed_model_configs": ["mydemo-1"],
  "chunk_size": 1500,
  "chunk_overlap": 300,
  "contextual_chunking": {
    "is_enable": false,
    "separator": ["\n\n", "\n", ".", " "],
    "chunk_size": 1500,
    "chunk_overlap": 300,
    "depth": 3
  }
}
```

### Step 4: Execute the Request

A successful response returns: `{"message": "success"}`

### Step 5: Verify Data Config

`GET /data/{name}` — A 200 response confirms creation.

### Step 6: Upload Documents

`POST /data/upload/{name}` — Upload PDF, DOCX, CSV, etc. Returns a job ID.

### Step 7: Check Upload Status

`GET /model/job-status/{model}/{job_id}` — Monitor status (queued, running, complete).

### Step 8: Verify Uploaded Files

`GET /data/list-files/{name}` — Lists all files with names and sizes.

### Step 9: Link Data Config to Model

Add your data config name to the model's `data` array:
```json
{
  "name": "mydemo-1",
  "data": ["mydemo-data-1"]
}
```

### Step 10: Test Your RAG Agent

Use Chat in A Box to ask questions about your uploaded documents.

---

## Connecting to External Data Sources

### Connecting to S3 Buckets
Specify S3 bucket and prefix in your data configuration. Supports synchronization.

### Connecting to SharePoint
Create a Sync configuration that mirrors your SharePoint location.

### Connecting to EDB
1. Provide the Cortex role ARN to the EDB team
2. Provide your data config name as the External ID
3. Receive the `assume_role`, `s3_bucket`, and `s3_prefix` from EDB team
4. Create a data config with these details

> Access to EDB data sources is exclusively granted to data owners and custodians.

---

## Next Steps

Learn how to optimize retrieval performance in "Optimizing Your RAG Results".
