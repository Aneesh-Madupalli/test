# Create a Model-Only Config

**Page URL:** https://cortex.lilly.com/spe/documentation/building-on-cortex-services/getting-raw-model-access/create-a-model-only-config/

---

## Overview

A model-only config gives you direct access to an LLM without RAG or agent processing.

The `model-only-chain` chain type sends prompts directly to the LLM and returns the response — no document retrieval or tool execution involved.

---

## Creating the Config

Use the Cortex API or Landing Zone with:

- `chain_class: "model-only-chain"`
- `model_versions`: Your selected model class and iteration
- `auth`: Your ownership and access settings

---

## Using the Landing Zone

Create model-only configs through the Landing Zone UI without writing code.
