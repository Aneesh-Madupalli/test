# Concepts

**Page URL:** https://cortex.lilly.com/spe/documentation/concepts/

---

## Overview

Conceptual overviews of key components and patterns used in the Cortex platform.

---

## Cortex Configuration Model

Cortex separates AI behavior configuration from underlying infrastructure. A Cortex config defines:

| Component | Description |
|-----------|-------------|
| Chain Type | The processing workflow (model-chain, doc-chain, tool-chain, agent-chain) |
| Model Version | The LLM to use (e.g., GPT-4o, Claude 3.5 Sonnet) |
| Data Sources | Optional RAG data configurations for document retrieval |
| Toolkits | Optional external tools the agent can invoke |
| Prompts | Instructions that guide agent behavior |
| Security Config | Scanners and policies for content filtering |

At runtime, Cortex Core orchestrates requests through the configured chain, invoking LLMs, tools, and data retrieval as specified.

---

## Sub-pages

- [Models](/spe/documentation/concepts/models/)
- [Data Patterns](/spe/documentation/concepts/data-patterns/)
- [Agents & Tools Configuration](/spe/documentation/concepts/agents-tools-configuration/)
- [Prompt Configuration](/spe/documentation/concepts/prompt-configuration/)
- [Security & Authentication Configuration](/spe/documentation/concepts/security-authentication-configuration/)
- [Operations](/spe/documentation/concepts/operations/)
