# Overview of Models

**Page URL:** https://cortex.lilly.com/spe/documentation/concepts/models/overview-of-models/

---

## Overview

Cortex provides access to multiple AI model types through a unified API layer, allowing you to switch between models without changing your application code.

---

## How Cortex Handles Models

1. Your application sends requests to the Cortex API
2. Cortex routes requests to the configured model provider (Azure OpenAI, AWS Bedrock, Google Vertex, etc.)
3. Cortex handles authentication, rate limiting, and failover
4. Responses returned through the Cortex API with consistent formatting

---

## Model Types

### Chat/Completion Models
- Accept a prompt or conversation history
- Generate text responses
- Support system prompts for behavior configuration
- May support function calling for tool integration

### Embedding Models
- Accept text input → return fixed-dimension numerical vectors
- Power semantic search in RAG workflows
- Used during document ingestion and query time

---

## Model Configuration

**For LLMs (in model config):**
```json
"model_versions": [
  {"model_class": "lilly-openai", "model_iteration": 7, "priority": 100}
]
```

**For Embeddings (in data config):**
```json
"embedding": {"model": "text-embedding-3-small", "open_api_type": "azure"}
```

---

## Model Access Patterns

| Pattern | Chain Type | Description |
|---------|-----------|-------------|
| Direct model access | model-only-chain | Send prompts directly to LLM without RAG or tools |
| RAG | doc-chain | Combine LLM with document retrieval |
| Single agent | tool-chain | LLM with access to tools/functions |
| Multi-agent | agent-chain | Hierarchical agent structures |

---

## Fine-Tuned Models

Cortex supports fine-tuning using QLoRA, LoRA, and Full fine-tuning (≤3B parameters). Fine-tuned models are registered and accessed through the same configuration system as base models.
