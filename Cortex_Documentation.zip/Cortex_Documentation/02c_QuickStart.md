# QuickStart

**Page URL:** https://cortex.lilly.com/spe/documentation/getting-started/quickstart/  
**Last Modified:** Jun 5, 2026

---

## Overview

The QuickStart guides provide end-to-end paths to help you get productive with Cortex quickly.

### Available QuickStarts:

- **Landing Zone Overview** – understand how to work with the Cortex developer portal.
- **Build Your First RAG Config** – create a doc-chain config that answers questions using your documents.
- **Integrate Cortex with Your App** – call Cortex from an application using the Cortex API or SDK.
- **Connect Cortex to Lilly Data** – configure Cortex to use enterprise data sources.

---

## Sub-pages

- [QuickStart 1: Landing Zone Overview](/spe/documentation/getting-started/quickstart/qs1-landing-zone/)
- [QuickStart 2: Build Your First RAG Config](/spe/documentation/getting-started/quickstart/qs2-rag-model/)
- [QuickStart 3: Integrate Cortex with your App](/spe/documentation/getting-started/quickstart/qs3-integrate-app/)
- [QuickStart 4: Connect Cortex to Lilly Data](/spe/documentation/getting-started/quickstart/qs4-lilly-data/)
