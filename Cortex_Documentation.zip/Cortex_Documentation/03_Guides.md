# Guides

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/

---

## Overview

This section provides comprehensive guides for building, testing, and deploying agents on the Cortex platform. Whether you're creating your first agent or preparing for production deployment, these guides will walk you through each step.

---

## What You'll Find Here

### Building Your Agent
Learn how to construct a complete agent by adding data sources, integrating tools, customizing prompts, implementing security measures, and handling special cases like fine-tuning.

### Building Reusable Components
Create components that can be shared across multiple agents, including MCP (Model Context Protocol) integrations.

### Functional Testing
Run evaluations to test and validate your agent's performance before deployment.

### Preparing For Release
Get your agent ready for production with operational change management, monitoring dashboards, and version control strategies.

### MCP Gateway
Connect external MCP servers and tools to your Cortex agents.

---

## Table of Contents

- [Building Your Agent](/spe/documentation/guides/building-your-agent/)
- [Building Reusable Components](/spe/documentation/guides/building-reusable-components/)
- [Functional Testing](/spe/documentation/guides/functional-testing/)
- [Preparing For Release](/spe/documentation/guides/preparing-for-release/)
- [MCP Gateway](/spe/documentation/guides/mcp-gateway/)
