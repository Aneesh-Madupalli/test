# What is Cortex?

**Page URL:** https://cortex.lilly.com/spe/documentation/getting-started/what-is-cortex/  
**Last Modified:** Jun 5, 2026

---

## Overview

Cortex is an internally developed, secure, and scalable AI platform enabling the development of advanced AI applications at Lilly. Built on the CATS containerized platform, Cortex hosts models, provides embedding functionality, and provides an API for users to build and deploy secure LLM applications. Built with enterprise-grade security, compliance, and quality standards, Cortex is a foundational toolset designed to power innovation across Lilly's diverse business functions.

> **Note:** [Landing Zone](https://cortex.lilly.com/spe/landing-zone) is the portal for managing all Cortex resources: create agents, configure data sources, add tools, and monitor performance.

---

## Key Capabilities

Cortex provides:

- **AI Agent Development** – Build, configure, and deploy intelligent agents that can reason, use tools, and interact with enterprise data to automate complex workflows.
- **Access an Expansive Model Library** – Access a wide range of language models through a unified platform.
- **Retrieval-Augmented Generation (RAG)** – Build agents that query your internal documents and data sources to provide context-aware responses.
- **Custom Tools & Integration** – Extend agent capabilities with custom tools and integrations to enterprise systems and databases.
- **Security & Compliance** – Built-in content filtering, audit logging, access controls, and compliance monitoring through Cortex Guard.
- **Production-Ready Infrastructure** – Scalable, monitored platform running on CATS containerized infrastructure.
- **Developer Portal & APIs** – Manage agent configurations, prompts, data sources, and security through the Landing Zone UI and comprehensive REST APIs.

---

## Sub-pages

- [Platform Overview](/spe/documentation/getting-started/what-is-cortex/platform-overview/)
- [Common Uses](/spe/documentation/getting-started/what-is-cortex/uses/)
- [Access Methods](/spe/documentation/getting-started/what-is-cortex/access-methods/)
- [Architecture](/spe/documentation/getting-started/what-is-cortex/architecture/)
- [Environments](/spe/documentation/getting-started/what-is-cortex/evnrionments/)
