# Full API Reference

**Page URL:** https://cortex.lilly.com/spe/documentation/api-and-sdks/api/full-api-reference/

---

## Overview

Complete API documentation is available via Swagger UI.

---

## Swagger Documentation

| Environment | Swagger URL |
|-------------|-------------|
| Production | https://cortex.lilly.com/docs |
| Dev | https://dev.cortex.lilly.com/docs |
| QA | https://qa.cortex.lilly.com/docs |

The Swagger UI provides:
- Complete endpoint documentation
- Request/response schemas
- Interactive testing ("Try it out")
- Authentication integration
