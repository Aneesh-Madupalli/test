# API & SDKs

**Page URL:** https://cortex.lilly.com/spe/documentation/api-and-sdks/

---

## Overview

Cortex provides programmatic access through HTTP APIs and Python SDKs.

---

## Access Methods

| Method | Description |
|--------|-------------|
| API | RESTful HTTP endpoints for all Cortex operations |
| SDKs | Python client libraries for API integration |

---

## API Base URLs

| Environment | URL |
|-------------|-----|
| Production | api.cortex.lilly.com |
| QA | api.qa.cortex.lilly.com |
| Dev | api.dev.cortex.lilly.com |

---

## Authentication

Cortex APIs require authentication via Microsoft Entra ID or AWS IAM roles. See Prerequisites & Access for setup instructions.

---

## Sub-pages

- [API](/spe/documentation/api-and-sdks/api/)
- [SDKs](/spe/documentation/api-and-sdks/sdks/)
