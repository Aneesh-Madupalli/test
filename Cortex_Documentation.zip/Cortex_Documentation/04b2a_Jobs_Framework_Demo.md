# Jobs Framework (Feature Demo)

**Page URL:** https://cortex.lilly.com/spe/documentation/use-cases-and-demos/training-and-demos/feature-demos/jobs-framework/

---

This video introduces the Cortex Jobs Framework, designed to streamline complex, long-running operations such as data processing and AI/ML tasks.

**Topics covered:**
- Core components: job requests, job manager, queue, and workers
- How to submit jobs, track status, and retrieve results using the Jobs API
- Demo: contextual chunking of a document as an example use case
