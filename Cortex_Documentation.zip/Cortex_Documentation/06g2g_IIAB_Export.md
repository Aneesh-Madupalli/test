# IIAB - Export

**Page URL:** https://cortex.lilly.com/spe/documentation/ai-products/insights-in-a-box/user-guide/export/

---

## Overview

Export downloads analysis results in your preferred format for reporting, sharing, or offline review.

**Who can do it:** Project Owner / Project Editor / Project Viewer

**Preconditions:** At least one analysis run has completed and produced results.

---

## How to Export

1. Open the Project
2. Choose **Export** from the right hand icon panel
3. Select the export format: **.xlsx**, **.csv**, or **.json**
4. Download or view the exported output
