# Drafting Assistant - AIDA (Feature Demo)

**Page URL:** https://cortex.lilly.com/spe/documentation/use-cases-and-demos/training-and-demos/feature-demos/drafting-assistant-aida/

---

This video introduces **AIDA (AI Drafting Assistant)** — a solution built on Cortex for generating initial documents as part of the Accelerated Content Generation (ACG) program.

**Key features demonstrated:**
- Generates full documents by accumulating content section by section
- Reference feature: prompts can reference outputs from other sections

**Impact:** Japanese Periodic Safety Report use case reduced document completion time from **36 days to 17 days**.
