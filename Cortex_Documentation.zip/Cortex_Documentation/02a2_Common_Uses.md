# Common Uses

**Page URL:** https://cortex.lilly.com/spe/documentation/getting-started/what-is-cortex/uses/  
**Last Modified:** Jun 5, 2026

---

## Overview

Cortex enables a wide range of generative AI applications across Lilly's business functions.

---

## Document Q&A Systems

Build chatbots that answer questions based on your organization's documents using RAG (Retrieval-Augmented Generation) to retrieve relevant information and generate accurate, cited responses.

**Examples:** Technical documentation assistants, policy lookup tools, research paper analysis, customer support knowledge bases

---

## Custom Chatbots

Create conversational AI assistants tailored to specific domains or workflows with configurable prompts, multiple LLM options, and custom tools.

**Examples:** Internal help desk assistants, domain-specific advisory bots (legal, scientific, financial), employee onboarding, meeting summarization

---

## Agentic Workflows

Build autonomous agents that use tools to complete complex tasks—query databases, call APIs, process data, and chain operations together.

**Examples:** Data analysis agents, research assistants, workflow automation

**Key Features:** Marketplace tools, custom tool creation, multi-agent hierarchies

---

## Multi-Agent Systems

Create hierarchical agent structures where a supervisor coordinates multiple specialized agents, each handling specific capabilities.

**Examples:** Database query + analysis coordination, information retrieval + writing + fact-checking, domain expert routing (legal, technical, business)

---

## Content Generation

Generate text content for business needs using LLMs with appropriate prompts and context.

**Examples:** Promotional text generation (PromoMaker for pharmaceutical claims), email drafting, report writing, documentation generation

---

## Data Processing & Analysis

Process large datasets, extract insights, and generate structured outputs from unstructured data.

**Examples:** Entity extraction, table summarization, document classification, batch report processing

**Key Features:** S3 integration, EDB connections, contextual chunking, multimodal pipelines (PDF/DOCX)

---

## Real-Time Information Grounding

Enhance agent responses with current information from external sources like web search, internal APIs, and live data lookups.

**Key Features:** Bing Search tool, custom API integrations, tool-chain model type

---

## Pre-Built AI Products

Deploy ready-to-use AI applications:

- **Chat In A Box (CIAB):** Rapid prototyping UI for custom chat assistants—upload files, configure models, and share without building a custom interface.
- **PromoMaker:** Generate pharmaceutical promotional claims with file-based evidence and RAG.

---

## Fine-Tuned Specialized Models

Adapt foundation models to specific domains or tasks using your training data for specialized terminology, classification tasks, or custom format generation.

**Key Features:** QLoRA, LoRA, and full fine-tuning methods; MLflow tracking; Temporal job orchestration

Explore the Guides section for detailed implementation instructions.
