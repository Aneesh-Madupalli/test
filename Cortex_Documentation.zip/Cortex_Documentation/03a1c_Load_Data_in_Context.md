# Load Data in Context

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/building-your-agent/add-data/load-data-in-context/

---

## Overview

This page covers how to upload files directly with your query using the /ask endpoint, rather than setting up a persistent data configuration for RAG.

---

## When to Use In-Context File Upload

**Use in-context file upload when:**
- You need to process a one-off file without setting up a data configuration
- The file content is needed only for the current conversation
- You want the agent to analyze a specific document the user provides

**Use a data configuration instead when:**
- You have a corpus of documents that should persist across conversations
- Multiple users need to query the same documents
- You need semantic search across many documents

---

## How File Upload Works

1. Client uploads file via the /ask endpoint with multipart/form-data
2. API stores file in S3 with a UUID-based filename
3. Agent chain receives S3 location
4. Presigned URL is generated for secure access
5. Tool receives attachment with the presigned URL

---

## Uploading Files via the /ask Endpoint

```bash
curl -X POST "https://cortex.lilly.com/model/ask/your-agent-model" \
  -H "x-user: username" \
  -H "x-groups: groups" \
  -F "q=What is in this document?" \
  -F "uploaded_file=@/path/to/document.pdf"
```

---

## Attachment Format

When a file is uploaded, tools receive it in this format:

```json
{
  "_attachments": [
    {
      "name": "document.pdf",
      "link": "https://s3.amazonaws.com/bucket/path?presigned-url-params",
      "description": "Uploaded file from user"
    }
  ]
}
```

---

## Processing Attachments in Tools

Key considerations:
- **Time-limited URLs:** Presigned URLs expire, so download files promptly
- **Field names:** Cortex uses `link` for the URL field (some systems use `url`)
- **Error handling:** Handle download failures gracefully
- **Size limits:** Consider memory limits when processing large files
