# QuickStart 1: Landing Zone Overview

**Page URL:** https://cortex.lilly.com/spe/documentation/getting-started/quickstart/qs1-landing-zone/

---

## Overview

This QuickStart introduces the Cortex Landing Zone, the developer portal for viewing, creating, and managing Cortex agents and components.

**Access Landing Zone:** https://cortex.lilly.com/spe/landing-zone

Landing Zone is a developer portal that brings together everything you need to work with Cortex. From here, you can create agents, connect data sources, add toolkits, and evaluate performance through an intuitive UI.

When you log in, you'll see your personalized dashboard with quick access to your agents, toolkits, and data configs, along with featured components shared across the organization.

---

## Creating Your First Agent

Click **Create Agent** to open the configuration form, where you can set up:

- Agent name and description
- Model selection
- Chain type (agent-chain, doc-chain, tool-chain)
- Attached data sources and toolkits

For a visual approach, try the **Agent Builder**, a drag-and-drop interface for creating agents without writing configuration code. It includes pre-built templates for chatbots, workflows, and multi-agent systems, along with enterprise integrations for ServiceNow, Workday, and GitHub.

---

## Connecting Data for RAG

To give your agent access to documents and knowledge bases, create a Data Config:

1. Navigate to Data → Create Data
2. Configure your embedding model and vector store
3. Set parameters such as chunk size and overlap for document processing
4. Define access permissions
5. Upload your documents

Once created, attach the data config to your agent to enable RAG capabilities.

---

## Adding Tools to Your Agent

Toolkits extend what your agent can do. Landing Zone includes several featured toolkits ready to use:

| Toolkit | Capabilities |
|---------|-------------|
| Workday | Query employee data, org structures, reporting hierarchies |
| Web Search | Search the web via Bing for real-time information |
| Web Scraper | Extract HTML content from webpages |
| JIRA | Retrieve ticket statuses, post comments |
| ServiceNow | Manage ServiceNow tickets and incidents |

To add a toolkit to your agent, go to Toolkits, find the one you need, and attach it to your agent configuration.

You can also **Register Toolkit** to connect your own custom MCP tool server.

---

## Working with Prompts

Prompts define how your agent communicates. Create reusable prompt templates to ensure consistent behavior:

1. Navigate to Prompts → Create Prompt
2. Define your prompt template with variables
3. Attach to agents that need this behavior

Shared prompts are available across your organization, so you can reuse proven templates.

---

## Choosing a Model

Cortex provides access to inference models and embedding models from leading providers, including:

- **OpenAI:** GPT-4.1, GPT-4o, o1, o3 series
- **Anthropic:** Claude 3.5, Claude 4 series
- **Google/Vertex:** Gemini 2.0, 2.5 series
- **Meta:** Llama 3, Llama 4 series
- **Amazon:** Nova series
- **Mistral AI, Cohere, xAI**

Browse the LLMs section to compare models by input/output token limits, file support, and version status.

---

## Evaluating Your Agent

Before deploying, test your agent's performance using the Evaluation framework:

1. **Create a BQS (Benchmark Question Set):** a collection of test questions with expected answers
2. **Run Evaluation:** trigger a test run against your agent
3. **Review Results:** analyze accuracy, response quality, and identify areas for improvement

Track your evaluation history to measure improvements over time.
