# Insights In A Box (IIAB)

**Page URL:** https://cortex.lilly.com/spe/documentation/ai-products/insights-in-a-box/

---

## Overview

Insights In A Box helps teams turn unstructured documents into structured, actionable data at scale using AI-powered analysis.

**Core structure:** Organization → Vault → Project → Columns & Prompts → Analysis → Export

---

## Sub-pages

- [Quick Guide](/spe/documentation/ai-products/insights-in-a-box/quick-guide/) — Get up and running fast
- [User Guide](/spe/documentation/ai-products/insights-in-a-box/user-guide/) — Detailed flows, roles, and admin instructions
