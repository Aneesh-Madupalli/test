# Use the Tool Marketplace

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/building-your-agent/add-tools/use-tool-marketplace/

---

## Overview

The Tool Marketplace provides a curated registry of enterprise-ready tools that you can add to your Cortex agents. Instead of building every integration from scratch, you can discover pre-built, certified tools and add them to your agent configuration.

**Access the Tool Marketplace:** https://cortex.lilly.com/spe/landing-zone/agent-toolkits

---

## Features

### Toolkit Registry

Browse available toolkits organized by:
- **Featured** – Highlighted toolkits recommended for common use cases
- **My Toolkits** – Toolkits you have registered
- **Shared** – Toolkits shared across the organization

### Featured Toolkits

| Toolkit | Capabilities |
|---------|-------------|
| Workday | Query employee data, org structures, and reporting hierarchies |
| Web Search | Search the web using Bing Search API for real-time information |
| Web Scraper | Extract HTML content from webpages for data collection |
| Jira | Retrieve ticket statuses and post comments |
| ServiceNow | Retrieve ticket status, add comments, and create new tickets |

---

## Register Your Own Toolkit

You can register custom toolkits to make them available to your agents and share them with others.

---

## Key Concepts

### What is a Tool?
A tool is a capability or function that an agent can invoke to perform specific actions—such as searching a database, sending an email, or querying an API. Tools extend your agent's capabilities beyond text generation. In Cortex, tools are organized into toolkits.

### What is a Toolkit?
A toolkit is a collection of related tools packaged together and exposed to Cortex models through a tool server. For example, an "Email Toolkit" might include tools for drafting, sending, and searching emails.
