# Training Videos

**Page URL:** https://cortex.lilly.com/spe/documentation/use-cases-and-demos/training-and-demos/training-videos/

---

Step-by-step video tutorials for building on Cortex.

## Sub-pages

- [Create a Model Config](/spe/documentation/use-cases-and-demos/training-and-demos/training-videos/create-a-model-config/)
- [Create a Data Config](/spe/documentation/use-cases-and-demos/training-and-demos/training-videos/create-a-data-config/)
- [Building AI Solutions with Cortex](/spe/documentation/use-cases-and-demos/training-and-demos/training-videos/building-ai-solutions-with-cortex/)
- [Building an Agent Tool](/spe/documentation/use-cases-and-demos/training-and-demos/training-videos/building-an-agent-tool/)
