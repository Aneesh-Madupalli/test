# Data Integration

**Page URL:** https://cortex.lilly.com/spe/documentation/concepts/data-patterns/data-integration/

---

## Data Integration Workflow

1. **Source Connection** – Configure access to data storage (S3, EDB)
2. **Document Upload** – Transfer files to Cortex-accessible storage
3. **Processing** – Parse, chunk, and embed documents
4. **Storage** – Store embeddings in a vector database
5. **Binding** – Connect data config to model config

---

## Data Configuration Example

```json
{
  "name": "my-data-config",
  "auth": {"owners": ["user@lilly.com"], "private": true},
  "s3_bucket": "lly-light-dev",
  "s3_prefix": "llm-dev",
  "s3_prefix_data": "data/my-project/docs",
  "embedding": {"model": "text-embedding-3-small", "open_api_type": "azure"},
  "model_version": {"model_class": "lilly-openai", "model_iteration": "7"},
  "vectorstore": "pinecone",
  "chunk_size": 1500,
  "chunk_overlap": 300,
  "allowed_model_configs": ["my-model-config"]
}
```

---

## Storage Options

### S3 (Primary Storage)
- `s3_bucket` – The bucket name
- `s3_prefix` – Base path prefix
- `s3_prefix_data` – Path to document folder

### Vector Databases

| Store | Description |
|-------|-------------|
| Pinecone | Managed vector database (recommended) |
| Elasticsearch | Legacy support |
| Index Factory (EDB) | Enterprise vector storage |

---

## Document Processing Pipeline

**Supported File Types:** PDF, DOCX, TXT, CSV

**Processing Steps:**
1. **Parsing** – Extract text content from documents
2. **Chunking** – Split text into retrievable segments
3. **Embedding** – Convert chunks to vectors
4. **Indexing** – Store vectors in vector database

**Fixed Length Chunking:**
```json
{"chunk_size": 1500, "chunk_overlap": 300}
```

**Contextual Chunking (structure-aware):**
```json
{"contextual_chunking": {"is_enable": true, "separator": ["\n\n", "\n", ".", " "], "chunk_size": 1500, "chunk_overlap": 300, "depth": 3}}
```

---

## Access Control

- `owners` – Users who can manage the config
- `private` – Whether the config is visible to others
- `allowed_model_configs` – Which model configs can use this data
- `access_groups` – AD groups with read access
