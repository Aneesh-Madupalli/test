# Cortex Full API Reference

**Source:** https://cortex.lilly.com/docs  
**OpenAPI Spec:** https://cortex.lilly.com/docs/all/v1/openapi.json  
**Version:** v5.10  
**Title:** Cortex — Lilly's Control Plane for AI

**Interactive Swagger UI:**
| Environment | URL |
|-------------|-----|
| Production | https://cortex.lilly.com/docs |
| Dev | https://dev.cortex.lilly.com/docs |
| QA | https://qa.cortex.lilly.com/docs |

---

## System

| Method | Path | Summary |
|--------|------|---------|
| GET | /health | Health check for LLM fabric API |
| GET | /health/diagnostic | Detailed health check diagnostic |

---

## Model | Config

| Method | Path | Summary |
|--------|------|---------|
| POST | /model | Create or Update Model Configuration |
| GET | /model | List all models the user is authorized to access |
| GET | /model/{model} | Get configuration for a specific model |
| DELETE | /model/{model} | Delete the model config |
| GET | /model/{model}/executables | List available executables (agents and tools) for a model config |
| GET | /model/exists/{model} | Check Model Configuration Existence |
| GET | /model/metrics/config-summary | List Model Metrics |

---

## Model | Ask

| Method | Path | Summary |
|--------|------|---------|
| GET | /model/ask/{model} | Send queries to model config |
| POST | /model/ask/{model} | Send queries to model config (with Multimodal support) |
| POST | /model/ask-multifile/{model} | Send queries with multiple files |
| POST | /model/ask/with-custom-filter/{model} | Ask with custom metadata filter on vector store |
| GET | /model/ask-with-custom-prompt/{model} | Ask with custom prompt and context |
| POST | /model/ask-with-custom-prompt/{model} | Ask with custom prompt and context (large payloads) |
| GET | /model/stream-messages/{message_id} | Stream messages from Redis via SSE |

---

## Model | Summarize

| Method | Path | Summary |
|--------|------|---------|
| POST | /model/summarize/{model} | Generate document summaries from uploaded files or text |
| POST | /model/refined-summary/{model} | Generate advanced document summaries |
| POST | /model/summarize-messages/{model} | Generate summary from selected chat messages |

---

## Model | Security

| Method | Path | Summary |
|--------|------|---------|
| GET | /model/security-config/{model} | Get Security Configuration for a Model |
| GET | /model/ismanager/{model} | Check if User is Manager for a Model |
| GET | /model/isauthorized/{model} | Check if User is Authorized for a Model |

---

## Model | LLMs

| Method | Path | Summary |
|--------|------|---------|
| GET | /model/classes/list | List valid model classes and iterations |
| GET | /model/llm/list | List available LLM models and embeddings |

---

## Model | Files

| Method | Path | Summary |
|--------|------|---------|
| GET | /model/list-files/{model} | List files from all data configs associated with the model config |

---

## Model | Evaluation

| Method | Path | Summary |
|--------|------|---------|
| POST | /model/evaluate/{model} | Evaluate model responses using provided ground truth values |

---

## Model | Visualization

| Method | Path | Summary |
|--------|------|---------|
| POST | /model/visualize/{model} | Generate t-SNE Vector Store Visualizations |
| POST | /model/cluster/{model} | Cluster Query Patterns with K-Means |
| GET | /model/summarize-documents/{model} | Retrieve and count unique documents across data configs |
| GET | /model/count-documents/{model} | Count documents in vector stores for all mapped data configs |

---

## Model | Jobs

| Method | Path | Summary |
|--------|------|---------|
| GET | /model/job-status/{model}/{job_id} | Get Job Status and Progress Information |
| GET | /model/download/{model}/{job_id}/{job_type} | Download Job Results and Generated Files |

---

## Model | Beta Cutover

| Method | Path | Summary |
|--------|------|---------|
| POST | /model/enable-beta/{model} | Enable Beta Cutover |
| GET | /model/beta-status/{model} | Return current beta cutover status |
| DELETE | /model/disable-beta/{model} | Disable beta cutover for a model |

---

## Model | Context Cache

| Method | Path | Summary |
|--------|------|---------|
| POST | /model/context_cache | Create a context cache for model |
| GET | /model/context_cache/{cache_key} | Get context cache by cache name |
| PATCH | /model/context_cache/{cache_key} | Update a context cache by name |
| DELETE | /model/context_cache/{cache_key} | Delete context cache by cache name |

---

## RAGAS & DeepEval

| Method | Path | Summary |
|--------|------|---------|
| GET | /model/evaluate-rag/{model} | Evaluate model with Ragas |
| POST | /model/evaluate-rag/{model}/bulk | Bulk evaluate model with Ragas |
| GET | /model/evaluate-rag/{model}/fetch_evaluation/{file_name} | Fetch evaluation results |
| POST | /model/evaluate-rag/generate-test-data | Generate test data |
| POST | /model/evaluate-rag/download-test-data | Download test data |
| GET | /model/evaluate-rag/job-status/{job_id} | Get job status for RAG evaluation |

---

## Data

| Method | Path | Summary |
|--------|------|---------|
| POST | /data | Create or update data configuration |
| GET | /data | List all data configs the user is authorized to access |
| GET | /data/{name} | Get a specific data config |
| DELETE | /data/delete/{name} | Delete a data config |
| GET | /data/{data_name}/exists | Check if data config exists |
| POST | /data/upload/{name} | Upload files to data store |
| POST | /data/upload-text/{name} | Upload text directly with embeddings |
| POST | /data/async_upload/{name} | Generate presigned S3 POST for direct client upload |
| GET | /data/list-files/{name} | List all files in S3 bucket (paginated, default page_size 500) |
| GET | /data/files/{name} | Download a specific file |
| GET | /data/extracted-content/{name} | Get downloadable URLs for extracted content |
| GET | /data/documents/{name} | Get doc chunks from vector store (paginated) |
| DELETE | /data/delete-file-embeddings/{name} | Delete a document and its embeddings |
| GET | /data/job-status-id/{name}/{job_id} | Get detailed status of a specific job by ID |
| GET | /data/job-status/{name} | List ingest jobs for a data config |
| DELETE | /data/jobs/clear-jobs/{name} | Clear all jobs from queue for a data config |
| POST | /data/index/{name} | Index or reindex documents |
| GET | /data/external_s3_list_files/{name} | List files from external S3 bucket |
| GET | /data/list-external-files/{name} | List files ingested from external S3 |
| POST | /data/external/upload/{name} | Upload files from OneDrive or SharePoint |
| GET | /data/external/list | List files from external sources |
| GET | /data/embeddings/list | List all valid embedding models |
| GET | /data/count-documents/{name} | Count indexed documents in vector store |
| GET | /data/summarize-documents/{name} | Generate document inventory report |
| POST | /data/visualize/{name} | Create t-SNE plot of vector store |
| GET | /data/download/{name}/{job_id}/{job_type} | Download visualization or counting job results |
| GET | /data/jobs-count-in-queue/{name} | Get count of jobs in Redis queue |
| GET | /data/search-metadata/{name} | Search documents by metadata |
| POST | /data/custom_search/{config_name} | Custom search query |
| POST | /data/chunks/{name} | Generate document chunks |
| POST | /data/redshift-connector/{name} | Query Redshift data |
| POST | /data/upload_custom_chunking/{name} | Upload JSON for custom chunking into Pinecone |
| DELETE | /data/delete-data-processor-cache/{name} | Delete data processor cache for a specific file |
| POST | /data/event-listener | Process events from external systems |
| POST | /data/migrate/{source}/{destination}/{name} | Migrate index between vector stores |
| GET | /data/jobs/failure/{key_name} | Get failed job results |

---

## Security

| Method | Path | Summary |
|--------|------|---------|
| POST | /security/ | Create Security Config |
| GET | /security/list | List all user security configs |
| GET | /security/{user_security_config_name} | Get Security Config |
| PUT | /security/{user_security_config_name} | Create or Update Security Config |
| DELETE | /security/{user_security_config_name} | Delete Security Config |

---

## Security-Cyber

| Method | Path | Summary |
|--------|------|---------|
| GET | /manage/cyberconfig | Get LLM Guard parent InfoSec configs |
| POST | /manage/cyberconfig | Set LLM Guard parent InfoSec configs |

---

## Prompt

| Method | Path | Summary |
|--------|------|---------|
| GET | /prompt | List prompt names user is authorized to access |
| POST | /prompt | Create a new prompt configuration |
| GET | /prompt/{name} | Get Prompt Config |
| PUT | /prompt/{name} | Update an existing prompt configuration |
| DELETE | /prompt/{name} | Delete Prompt Config |
| GET | /prompt/{prompt_name}/exists | Check if a prompt exists |

---

## Toolkit

| Method | Path | Summary |
|--------|------|---------|
| PUT | /toolkits | Create or Update Toolkit Configuration |
| GET | /toolkits | List all toolkit configs the user has access to |
| GET | /toolkits/{toolkit_name} | Get Toolkit Config |
| DELETE | /toolkits/{toolkit_name} | Delete Toolkit |
| GET | /toolkits/{toolkit_name}/describe | Retrieve all available tools in a toolkit |
| GET | /toolkits/{toolkit_name}/execute | Execute a Toolkit Tool via GET |
| POST | /toolkits/{toolkit_name}/execute | Execute a Toolkit Tool via POST |
| GET | /toolkits/{toolkit_name}/tools | Retrieve simplified tool list from toolkit |
| GET | /toolkits/{toolkit_name}/exists | Check if toolkit exists |
| GET | /toolkits/{model_config}/list-tools | Retrieve all tools available to a model configuration |

---

## Toolkit-Security

| Method | Path | Summary |
|--------|------|---------|
| GET | /toolkits/{toolkit_name}/is-manager | Check Toolkit Manager Permissions |
| GET | /toolkits/{toolkit_name}/is-authorized | Check Toolkit Access Authorization |

---

## Tool Policy

| Method | Path | Summary |
|--------|------|---------|
| GET | /tool-policy | Get Tool Policy |
| PUT | /tool-policy | Create or Update Tool Policy Configuration |

---

## Sync

| Method | Path | Summary |
|--------|------|---------|
| GET | /sync | List available Sync configurations |
| POST | /sync | Create a new sync configuration |
| POST | /sync/is_valid_sync | Validate a sync config without creating it |
| GET | /sync/{name} | Get a specific Sync config and current status |
| PUT | /sync/{name} | Update an existing sync config |
| DELETE | /sync/{name} | Delete a sync config and associated synced files |
| GET | /sync/metrics/{name} | Get detailed synchronization metrics |
| POST | /sync/trigger/{name} | Manually trigger a sync operation |
| GET | /sync/metrics/aggregated/{data_config} | Get aggregated sync metrics for all syncs of a data config |

---

## History

| Method | Path | Summary |
|--------|------|---------|
| GET | /history/{model}/sessions | Retrieve all chat sessions for a user and model |
| GET | /history/{model}/sessions/{session_id} | Retrieve conversation history for a specific session |
| GET | /history/user/{user_id}/messages | Retrieve all messages for a user within a time range (Admin Only) |

---

## Jobs

| Method | Path | Summary |
|--------|------|---------|
| GET | /job/job-status/{job_id} | Get job status for evaluation, clustering, counting, refined summary |
| GET | /job/job-result/{job_id} | Get result of a finished job |
| GET | /job/summary-status/{job_id} | Get status of a document summarization job |
| GET | /job/summary-result/{job_id} | Get results of a document summarization job |
| GET | /job/download/{job_id}/{job_type} | Download results from a job |
| DELETE | /job/clear-jobs/{name} | Clear all jobs from queue for a config |
| POST | /job/requeue-jobs | Requeue expired started jobs |
| GET | /job/redis-queued-jobs-count | Get count of jobs in Redis registries |
| DELETE | /job/kill/workflows/{config_name} | Kill workflows for a config |

---

## OpenAI Compatible

| Method | Path | Summary |
|--------|------|---------|
| POST | /cortex-openai/chat/completions | OpenAI-Compatible Chat Completions API |
| POST | /cortex-openai/openai/deployments/{_}/chat/completions | OpenAI-Compatible Chat Completions (Azure-style URL) |
| POST | /cortex-openai/responses | Responses API |
| POST | /cortex-openai/embeddings | Generate text embeddings |
| POST | /cortex-openai/openai/deployments/{_}/embeddings | Generate embeddings (Azure-style URL) |
| POST | /cortex-openai/v1/async/images/generations | Create async image generation job |
| POST | /cortex-openai/v1/async/images/edits | Create async image edit job |
| GET | /cortex-openai/v1/async/images/generations/{job_id} | Get image generation job status |
| GET | /cortex-openai/v1/async/images/edits/{job_id} | Get image edit job status |

---

## Private LLM

| Method | Path | Summary |
|--------|------|---------|
| POST | /model/private-llm/update | Update Private LLM Configuration |
| POST | /model/private-llm/delete | Delete Private LLM Configuration |

---

## Feature Flag

| Method | Path | Summary |
|--------|------|---------|
| POST | /feature-flag/enable/{flag_name} | Enable a feature flag (super-admin only) |
| POST | /feature-flag/disable/{flag_name} | Disable a feature flag (super-admin only) |
| DELETE | /feature-flag/{flag_name} | Delete a feature flag (super-admin only) |
| GET | /feature-flag/status/{flag_name} | Get current status of a feature flag |
| GET | /feature-flag/list | List all feature flags |

---

## Bifrost Fallback Cache (Super Admin)

| Method | Path | Summary |
|--------|------|---------|
| GET | /model/cache/bifrost-fallback-cache | List Bifrost Fallback Cache entries |
| DELETE | /model/cache/bifrost-fallback-cache/{model_name} | Remove Bifrost Fallback Cache entry |

---

## Migration (Cortex Super Admins Only)

| Method | Path | Summary |
|--------|------|---------|
| POST | /model/migration/application-ids | Create application IDs for all model configs |
| POST | /prompt/migrate | Migrate prompt configs |
| GET | /prompt/migrate/job-status | Get prompt migration job status |
| POST | /data/migrate | Data Config Migration |
| GET | /data/migrate/job-status | Get data migration job status |
| POST | /security/migrate | Child Security Migration |
| GET | /security/migrate/job-status | Get security migration job status |
| POST | /model/migrate | Model Migration |
| GET | /model/migrate/job-status | Get model migration job status |
| POST | /data/pinecone_ids/migrate | Upsert/Delete Pinecone IDs |
| GET | /data/pinecone_ids/migration/job-status | Get Pinecone IDs migration status |
| POST | /data/migration/history | Migrate Cortex History S3 files |
| GET | /data/migration/history/validate | Validate Cortex History migration completion |
| POST | /redis/scan | Scan Redis keys by pattern |
| POST | /redis/scan/user-models | Scan Redis user model keys |
| POST | /redis/meta-ttl | Add TTL to Redis metadata keys |
| POST | /redis/user-model-ttl | Add TTL to Redis user model keys |
| POST | /redis/session-ttl | Add TTL to Redis session keys |
| GET | /redis/ttl/checkpoint | Get Redis TTL migration checkpoint |
