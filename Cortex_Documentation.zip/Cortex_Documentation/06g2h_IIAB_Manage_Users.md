# IIAB - Manage Users

**Page URL:** https://cortex.lilly.com/spe/documentation/ai-products/insights-in-a-box/user-guide/manage-users/

---

## Overview

Manage Users controls who has access to Vaults/Projects and at what role. Owners manage access; other users can request it.

---

## Owner Flows

### Add User(s)
1. Open Vault or Project → Manage User Access
2. Search for person by name or email
3. Select access role (Owner/Editor/Viewer)
4. Click **Add User** → verify user appears in list

### Add Group (Azure AD Group)
1. Manage User Access → choose **AD Group** in the Users dropdown
2. Search and select the group name
3. Select the role → Add the group

### Edit User Role
- Manage User Access → find user → **Edit pencil icon** → select new role → save

### Remove User
- Manage User Access → find user → **Delete icon** → confirm

### Approve/Reject Access Requests
1. Open Vault or Project → Manage User Access
2. Go to **Manage Requests** tab
3. For each request: click **Approve ✔** or **Reject ✗**

---

## Non-Owner Flows

### Request Access
1. Open the Vault or Project → Manage User Access
2. Search for your user name/email
3. Choose the role/access level needed
4. Click **Request Access** → check **My Requests** to track status

### From 403/Access Denied Page
- Click **Request Access** directly from the access denied page
- Submit the role you need and wait for Owner approval

---

## Email Notifications

- **Adding users/groups:** "Send Email Invitation" checkbox (enabled by default) — email includes role and direct link
- **Access requests:** Resource Owner(s) notified automatically when a request is submitted
- **No recurring emails:** Notifications sent only at time of action
- To add without email: uncheck "Send Email Invitation" before submitting
