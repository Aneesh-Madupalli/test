# MCP (External) Toolkit Integration

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/building-reusable-components/mcp-integration/

---

## Overview

The Model Context Protocol (MCP) server enables you to expose Python functions as tools for use in agent-chain within Cortex. Uses FastMCP framework with Streamable-HTTP transport.

---

## Step 1: Project Setup

```
mcp[cli]==1.9.3
```

```bash
pip install -r requirements.txt
```

---

## Step 2: Implement MCP Server (server.py)

```python
from mcp.server.fastmcp import FastMCP
import requests

mcp = FastMCP("Weather Server", host="0.0.0.0", port=6000)

@mcp.tool()
def get_weather(city: str) -> str:
    """Get the weather for a given city."""
    response = requests.get(f"https://wttr.in/{city}", timeout=30)
    return response.text

@mcp.tool()
def add_numbers(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b

if __name__ == "__main__":
    mcp.run(transport="streamable-http")
```

---

## Step 3: Create Toolkit Config

```json
{
  "name": "mcp-server-sample-toolkit",
  "allowed_model_configs": ["mcp-server-sample-model-config"],
  "auth": {"owners": ["testuser@lilly.com"], "private": true},
  "description": "mcp-server-sample-toolkit",
  "server": "mcp://mcp_server:6000",
  "agent_tool_max_iterations": 7,
  "allowed_file_types": ["*"]
}
```

Verify with `GET /toolkits/{toolkit_name}/describe` — returns list of tools with schemas.

---

## Step 4: Create Model Config

```json
{
  "name": "mcp-server-sample-model-config",
  "chain": [{
    "chain_class": "agent-chain",
    "model_iteration": 1,
    "order": 1,
    "chain_params": {
      "max_turns": 50,
      "supervisor": {
        "prompt": "You are a supervisor agent with access to weather and addition tools.",
        "description": "Handoff to supervisor once the response from child agent is received"
      },
      "resources": {
        "executables": [
          {"name": "get_weather", "type": "tool-call", "description": "Gets weather for a city."},
          {"name": "add_numbers", "type": "tool-call", "description": "Adds 2 numbers."}
        ]
      }
    }
  }],
  "toolkits": ["mcp-server-sample-toolkit"],
  "allowed_tools_list": ["get_weather", "add_numbers"]
}
```

---

## Step 5: Test

```
POST /model/ask/mcp-server-sample-model-config
q=How is the climate in Bangalore?
```

The agent will call `get_weather("Bangalore")` and return the result.

---

## References

- pinecone-mcp-server-syed
- LRL_light_k8s_infra_apps
