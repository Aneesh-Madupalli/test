# Supported Models

**Page URL:** https://cortex.lilly.com/spe/documentation/concepts/models/supported-models/

> For the most current list, visit the Cortex Landing Zone.

---

## Large Language Models (LLMs)

- **OpenAI:** GPT-4o, GPT-4o mini, GPT-4 Turbo, o-series reasoning models
- **Anthropic Claude:** Claude 3.5 Sonnet, Claude 3 Sonnet, Claude 3 Haiku
- **Google Vertex:** Gemini 2 Pro, Gemini models
- **Amazon (via Bedrock):** Amazon Nova, Amazon Titan
- **Meta:** Llama 3.2 (1B, 3B), Llama 3 variants
- **Specialized:** BioMistral (biomedical), DeepSeek (reasoning), Mistral 7B, Falcon 7B

---

## Embedding Models

| Model | Provider | Dimensions | Use Case |
|-------|----------|-----------|---------|
| text-embedding-ada-002 | Azure/OpenAI | 1536 | General purpose |
| text-embedding-3-small | Azure/OpenAI | 1536 | Cost-effective |
| text-embedding-3-large | Azure/OpenAI | 3072 | Higher accuracy |
| cohere.embed-multilingual-v3 | Bedrock | 1024 | Multilingual |
| cohere.embed-english-v3 | Bedrock | 1024 | English-optimized |
| text-embedding-004 | Vertex | 768 | Google ecosystem |
| amazon.titan-embed-text-v1 | Bedrock | 1536 | AWS ecosystem |

---

## Model Selection Criteria

| Factor | Guidance |
|--------|---------|
| Task | Reasoning → o-series or Claude; Code → GPT-4o |
| Context length | Longer docs require larger context windows |
| Latency | Smaller models (Haiku, GPT-4o mini) respond faster |
| Function calling | Required for tool-chain and agent-chain; verify support |
| Domain | Specialized models (BioMistral) may perform better for specific domains |

---

## Model References in Configs

```json
"model_versions": [
  {"model_class": "lilly-openai", "model_iteration": 7, "priority": 100}
]
```

Use `GET /models/classes/list` to retrieve the current list of model classes and iterations.
