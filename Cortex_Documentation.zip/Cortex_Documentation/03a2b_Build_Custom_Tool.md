# Build a Custom Tool

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/building-your-agent/add-tools/build-custom-tool/

---

## Overview

This guide walks through creating, deploying, and registering a custom tool for Cortex using the Model Context Protocol (MCP).

> For the most up-to-date instructions, refer to the `cortex-agent-template` GitHub repository.

---

## Steps

1. Create a new repository using the Python MCP server template
2. Define your tools using FastMCP
3. Set up the development environment
4. Deploy the tool to CATS
5. Register the MCP toolkit in Cortex
6. Test the tool in Cortex
7. Add the tool to a Model Config

---

## Key Concepts

### MCP Server
The Model Context Protocol (MCP) is an open standard that enables developers to build secure, two-way connections between data sources and AI-powered tools. In Cortex, an MCP server exposes Python functions as tools that can be orchestrated by agents.

### Tools
Tools are Python functions decorated with `@mcp.tool` that can be invoked by the agent. Each tool should have a clear docstring and type annotations.

---

## Step 1: Create a New Project

Navigate to Backstage Accelerators and select the desired Cortex accelerator.

```
my-cortex-tool/
├── server.py
├── requirements.txt
├── Dockerfile
├── k8s/
│   ├── deployment.yaml
│   └── service.yaml
└── README.md
```

---

## Step 2: Define Your Tools with FastMCP

```python
import logging
import requests
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("MyToolServer", host="0.0.0.0", port=6000)

@mcp.tool
def get_weather(city: str) -> str:
    """Get the weather for a given city."""
    resp = requests.get(f"https://wttr.in/{city}", timeout=30)
    return resp.text

@mcp.tool
def add_numbers(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b

if __name__ == "__main__":
    mcp.run(transport="streamable-http")
```

**requirements.txt:**
```
mcp[cli]==1.9.3
requests>=2.28.0
```

---

## Step 3: Set Up Development Environment

```bash
pip install -r requirements.txt
python server.py
```

**Dockerfile:**
```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY server.py .
EXPOSE 6000
CMD ["python", "server.py"]
```

```bash
docker build -t my-cortex-tool:latest .
docker run -p 6000:6000 my-cortex-tool:latest
```

---

## Step 4: Deploy to CATS

Deploy following the CATS Documentation prerequisites and deployment steps.

---

## Step 5: Register the MCP Toolkit in Cortex

```json
{
  "name": "my-mcp-toolkit",
  "displayName": "My MCP Toolkit",
  "description": "Toolkit wrapping FastMCP weather and math tools",
  "server": "mcp://<your-service-hostname>:6000",
  "allowed_model_configs": ["my-model-config"],
  "agent_tool_max_iterations": 7,
  "auth": {
    "owners": ["your_email@lilly.com"],
    "private": true
  },
  "allowed_file_types": ["*"]
}
```

| Field | Description |
|-------|-------------|
| name | Unique identifier for the toolkit |
| server | MCP server address - use `mcp://` prefix |
| allowed_model_configs | Model configs that can use this tool |
| private | If true, only available to configs in allowed_model_configs |
| agent_tool_max_iterations | Max iterations per turn |

---

## Step 6: Test the Tool

| Endpoint | Description |
|----------|-------------|
| `/toolkits/${ToolName}` | Get toolkit configuration |
| `/toolkits/${ToolName}/describe` | List available tools |
| `/toolkits/${ToolName}/execute` | Execute a tool |

---

## Step 7: Add to a Model Config

```json
{
  "name": "my-agent-config",
  "chain": [{
    "chain_class": "agent-chain",
    "model_iteration": 1,
    "order": 1,
    "chain_params": {
      "max_turns": 50,
      "supervisor": {
        "prompt": "You are a supervisor agent with access to weather lookup and math tools."
      },
      "resources": {
        "executables": [
          {"name": "get_weather", "type": "tool-call", "description": "Gets weather details for a city."},
          {"name": "add_numbers", "type": "tool-call", "description": "Adds two numbers together."}
        ]
      }
    }
  }]
}
```

---

## Additional Resources

- cortex-agent-template - Template repository
- CATS Documentation - Deployment guide
- Toolkit API - API reference
- Tool Marketplace - Browse existing toolkits
- MCP Integration Guide - Full MCP reference
- Model Context Protocol - MCP specification
