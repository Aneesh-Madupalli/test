# Cortex Finetuning Guide

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/building-your-agent/special-cases/cortex-finetuning/

---

## What is Finetuning?

Finetuning adapts a pre-trained LLM to your specific domain/tasks. Use it to:
- Inject domain-specific knowledge not in original training data
- Customize tone, personality, or response style beyond prompting
- Optimize for specific tasks (classification, QA, code generation)

---

## Finetuning Techniques

| Method | Description | Memory Requirements |
|--------|-------------|---------------------|
| QLoRA | Quantized Low-Rank Adaptation (4-bit) | Lowest (~4-9 GB) |
| LoRA | Low-Rank Adaptation without quantization | Medium (~4-18 GB) |
| Full | Updates all model parameters | Highest (~17-44 GB) |

> **Recommendation:** Start with QLoRA for most use cases.

---

## Supported Models

| Model | Parameters | Model Name | QLoRA | LoRA | Full |
|-------|-----------|------------|-------|------|------|
| Llama 3.2 1B | 1B | meta-llama/Llama-3.2-1B-Instruct | ~4 GB | ~4 GB | ~17 GB |
| Llama 3.2 3B | 3B | meta-llama/Llama-3.2-3B-Instruct | ~6 GB | ~9 GB | ~44 GB |
| Llama 3.1 8B | 8B | meta-llama/Llama-3.1-8B-Instruct | ~10 GB | ~20 GB | N/A |
| Falcon 7B | 7B | tiiuae/falcon-7b-instruct | ~9 GB | ~18 GB | N/A |
| Mistral 7B | 7B | mistralai/Mistral-7B-Instruct-v0.2 | ~9 GB | ~18 GB | N/A |

> Full finetuning restricted to models ≤3B parameters.

---

## Dataset Preparation

Required columns: `instruction`, `input`, `output`

```json
[
  {
    "instruction": "Translate to Spanish",
    "input": "Hello, how are you?",
    "output": "Hola, ¿cómo estás?"
  }
]
```

- **Minimum:** 100 rows
- **Recommended:** 1,000+ rows

---

## End-to-End Workflow

**API:** https://finetune.cortex.lilly.com/docs

### Step 1: Create Data Configuration

`POST /data`
```json
{
  "name": "my-finetuning-data",
  "allowed_finetuning_configs": ["my-qlora-finetuning"],
  "s3_bucket": "lly-light-dev",
  "s3_prefix": "llm-dev",
  "dataset_formats": ["json", "csv"],
  "auth": {"owners": ["your-email@lilly.com"]}
}
```

### Step 2: Upload Dataset

`POST /data/upload/{name}` — upload CSV or JSON file.  
Copy the `_custom_train` dataset name from the response.

### Step 3: Create Finetuning Configuration

`POST /finetuning`
```json
{
  "name": "my-qlora-finetuning",
  "data_config_name": "my-finetuning-data",
  "specific_datasets": ["your-dataset-name_custom_train"],
  "training_type": "qlora",
  "hyperparameters": {
    "model_name_or_path": "meta-llama/Llama-3.2-1B-Instruct",
    "template": "llama3",
    "cutoff_len": 2048,
    "learning_rate": 0.0001,
    "num_train_epochs": 3,
    "per_device_train_batch_size": 1,
    "gradient_accumulation_steps": 8,
    "lora_rank": 8,
    "quantization_bit": 4
  }
}
```

### Step 4: Trigger Finetuning

`POST /finetuning/{config_name}/train` — copy `job_id` from response.

### Step 5: Update Config with Job ID

`POST /finetuning` — add `job_id` to `train_job_ids` array.

### Step 6: Monitor Status

`GET /finetuning/{config_name}/train/{job_id}/status`  
Progression: `queued` → `in_progress` → `completed` (or `failed`)

### Step 7: Deploy Finetuned Model

Submit ServiceNow ticket to Operations team with:
- Data config name, Finetuning config name, Model used
- Deployment environment (dev/staging/prod), job_id
- Desired endpoint name

---

## Key Hyperparameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| learning_rate | 0.0001 | Model adaptation speed |
| num_train_epochs | 3 | Complete passes through dataset |
| per_device_train_batch_size | 1 | Examples processed together |
| gradient_accumulation_steps | 8 | Effective batch size multiplier |
| cutoff_len | 2048 | Max sequence length in tokens |
| lora_rank | 8 | LoRA matrix size (higher = more capacity) |
| quantization_bit | 4 | QLoRA bit precision |
