# Retrieval Augmented Generation (RAG)

**Page URL:** https://cortex.lilly.com/spe/documentation/concepts/data-patterns/retrieval-augmented-generation/

---

## Overview

RAG combines information retrieval with generative language models, enabling LLMs to generate responses grounded in your organization's documents.

---

## How RAG Works

### 1. Retrieval Phase
1. Query converted to an embedding using the configured embedding model
2. Vector database searched for chunks with similar embeddings
3. Most relevant chunks retrieved based on similarity scores

### 2. Generation Phase
1. Retrieved chunks formatted as context
2. Context + user query combined into a prompt
3. LLM generates a response using provided context
4. Response returned (optionally with source citations)

---

## RAG Components in Cortex

| Component | Purpose |
|-----------|---------|
| Data Config | Defines document processing and storage |
| Embedding Model | Converts text to vectors |
| Vector Store | Stores and retrieves embeddings (Pinecone) |
| Chain Type | doc-chain for basic RAG, hybrid-doc-chain for hybrid search |
| Prompt Template | Defines how context is presented to the LLM |

---

## Chain Types for RAG

| Chain Type | Description |
|-----------|-------------|
| doc-chain | Basic RAG using similarity search |
| hybrid-doc-chain | Combines keyword and semantic search |
| model-enhanced-query-chain | Expands user queries before retrieval |

---

## Hybrid Search Configuration

```json
"hybrid_search": {
  "rrf_relevance_threshold": 0.012,
  "rrf_constant": 60,
  "hybrid_score_type": "average",
  "lexical_average_weight": 50
}
```

---

## Retrieval Parameters

| Parameter | Description |
|-----------|-------------|
| k_value | Number of chunks to retrieve (default: 20) |
| doc_relevance_threshold | Minimum similarity score for inclusion |
| chunk_size | Size of document chunks |
| chunk_overlap | Overlap between chunks for context continuity |

---

## Best Practices

- **Chunk size:** Smaller (500-1000 tokens) for Q&A; larger for summarization
- **Contextual chunking:** Use for structured documents to preserve logical sections
- **Hybrid search:** Enable when users include specific terminology or product names
- **Citation prompts:** Instruct the model to cite sources for verifiable responses
- **Relevance threshold:** Adjust to filter low-quality matches
