# Building on Cortex Services

**Page URL:** https://cortex.lilly.com/spe/documentation/building-on-cortex-services/

---

## Overview

This section covers how to use Cortex as a foundation for building your own applications — accessing Cortex's LLM and embedding capabilities directly rather than using pre-built agents.

---

## When to Use Raw Model Access

- Need direct LLM calls without RAG or agent orchestration
- Building a custom application with your own orchestration logic
- Want to use Cortex for model access while handling prompts and context yourself

---

## Sub-pages

- [Getting Raw Model Access](/spe/documentation/building-on-cortex-services/getting-raw-model-access/)
