# Text-to-SQL Integration Guide

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/building-your-agent/add-data/text-to-sql/

---

## Overview

This guide walks you through integrating your databases with the Text-to-SQL tool, enabling natural language querying via chatbot or agentic workflows.

**⏱️ Time to Complete:** Typically 3-5 business days (depending on EDB approval process)

**🔐 Prerequisites:** AWS access for secret creation, ServiceNow access for team requests

---

## Summary of Steps

1. **Database Whitelisting** - Allow Cortex to access your database by whitelisting security groups
2. **Create Database Credentials** - Prepare connection information for your database type
3. **Store Credentials in AWS** - Create AWS secret with database connection details
4. **Submit ServiceNow Request** - Request Cortex ops team to configure your toolkit
5. **Create Model Configuration** - Set up a Cortex model to use your new toolkit
6. **Start Chatting** - Use CIAB or Swagger to query your database with natural language

---

## Step 1 - Database Whitelisting

### Security Group Requirements

| Environment | Security Group | AWS Account ID |
|-------------|---------------|----------------|
| DEV-DEV | sg-0a72462fa00bfa796 | 408787358807 |
| QA-QA | sg-043985683cce99d6c | 474366589702 |
| PRD-PRD | sg-0edeff0a932825cd3 | 283234040926 |

### For EDB-Managed Databases
1. Submit an EDB Request Form
2. Create GitHub Pull Request for EDB changes with security group ingress rule

### For Self-Managed Databases
Add inbound rule in AWS Console → EC2 → Security Groups with the Cortex security group.

---

## Step 2 - Database Credentials Configuration

### PostgreSQL/Aurora PostgreSQL
```json
{
  "host": "your-database-host.amazonaws.com",
  "port": 5432,
  "database": "your_database_name",
  "user": "cortex_readonly",
  "password": "your_secure_password",
  "db_type": "postgresql",
  "db_schema": ["public", "your_schema"],
  "ssl_mode": "require"
}
```

### MySQL
```json
{
  "host": "your-mysql-host.amazonaws.com",
  "port": 3306,
  "database": "your_database_name",
  "user": "cortex_readonly",
  "password": "your_secure_password",
  "db_type": "mysql",
  "db_schema": ["your_database_name"],
  "ssl_mode": "require"
}
```

### Amazon Redshift
```json
{
  "host": "your-redshift-cluster.region.redshift.amazonaws.com",
  "port": 5439,
  "database": "your_database_name",
  "user": "cortex_readonly",
  "password": "your_secure_password",
  "db_type": "redshift",
  "db_schema": ["public", "your_schema"],
  "ssl_mode": "require"
}
```

### Databricks (Azure)
```json
{
  "databricks_api_endpoint": "https://your-workspace.cloud.databricks.com",
  "http_path": "/sql/1.0/warehouses/abc123def456",
  "client_id": "your-azure-ad-application-client-id",
  "client_secret": "your-azure-ad-client-secret",
  "tenant_id": "your-azure-ad-tenant-id",
  "scope": "2ff814a6-3304-4ab8-85cb-cd0e6f879c1d/.default",
  "catalog": "main",
  "db_type": "databricks",
  "db_schema": ["default"]
}
```

> **Important:** Always create a dedicated read-only user for Cortex.

---

## Step 3 - AWS Secret Configuration

### Secret Naming Convention
`cortex-text2sql-{environment}-{database_identifier}`

Examples:
- `cortex-text2sql-prod-customer-database`
- `cortex-text2sql-dev-analytics-warehouse`

### How to Create
1. Open AWS Console → Secrets Manager → "Store a new secret"
2. Select "Other type of secret" → "Plaintext" tab
3. Paste your database configuration JSON
4. Name using convention above
5. Review and Create

---

## Step 4 - ServiceNow Request Process

### How to Submit
1. Go to ServiceNow Request Form
2. Select Platform: "Cortex Platform"
3. Select Environment: "dev", "qa", or "production"
4. Issue Type: "Other"
5. Short description: "Text2SQL onboarding for [your team name]"

Include in description:
- Team name, contact, business justification
- AWS Secret Name, Database Name/Type, Target Environment
- Requested Toolkit Name
- Security confirmation checkmarks

**Timeline:** Typically 2-3 business days for processing.

---

## Step 5 - Create Model Configuration for CIAB

### Key Configuration

```json
{
  "name": "your-team-text2sql",
  "chain": [{
    "chain_class": "agent-chain",
    "model_iteration": 1,
    "order": 1,
    "chain_params": {
      "max_turns": 5,
      "react_enabled": true,
      "supervisor": {
        "prompt": "You are a Supervisor Agent: allow only read-only queries; reject all write operations; call get_all_database_schemas always..."
      },
      "resources": {
        "executables": [
          {"name": "execute_query", "type": "tool-call"},
          {"name": "get_all_database_schemas", "type": "tool-call"}
        ]
      }
    }
  }],
  "model_versions": [{"model_class": "lilly-openai", "model_iteration": 22, "priority": 0}],
  "toolkits": ["your-toolkit-name-from-servicenow"],
  "app_binding": "chatbuilder",
  "prompts": {"cortex_agent_tool_prompt_v2": "cortex_text_to_sql_prompt_v2"},
  "temperature": 0
}
```

### Testing
1. Go to https://chat.lilly.com/cortex/dashboard
2. Test: "What tables are available in the database?"
3. Test: "Show me the first 5 rows from [table]"
4. Test: "How many records are in [table]?"

---

## Step 6 - Test via Swagger API

### Available Tools

| Tool Name | Purpose |
|-----------|---------|
| list_accessible_databases | Lists all databases in toolkit |
| get_all_database_schemas | Gets schema for all databases |
| get_database_schema | Gets schema for specific database |
| execute_query | Runs SQL queries |
| invalidate_redis_cache | Clears schema cache |

---

## Advanced: Model Selection

### Non-Reasoning Models
- Direct answers, lower latency and cost
- Best for straightforward NL→SQL with clear schema

### Reasoning Models
- Stepwise reasoning with chain-of-thought
- Better for complex multi-step mapping and nested queries
- Higher latency and cost

---

## Security Features

- **Read-Only Enforcement** - Only SELECT statements allowed
- **Row Limiting** - Maximum 500 rows per query response
- **Timeout Protection** - 2-minute query timeout window
- **Connection Encryption** - SSL/TLS required

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "Security group not found" | Verify correct AWS account ID |
| "Connection timeout" | Check ports match database config |
| "Toolkit not found" | Verify name matches ops team response |
| "Schema retrieval returns empty" | Check db_schema array in AWS secret |
| "Permission denied on query" | Verify read-only user has SELECT permissions |
