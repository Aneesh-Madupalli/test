# Platform Overview

**Page URL:** https://cortex.lilly.com/spe/documentation/getting-started/what-is-cortex/platform-overview/  
**Last Modified:** Jun 5, 2026

---

## Overview

Cortex separates **configuration** of AI behavior from the underlying infrastructure.

Teams define Cortex configs that reference:

- An underlying LLM and config type (agent-chain, tool-chain, doc-chain, or model-chain).
- Optional RAG data sources and search behavior.
- Optional toolkits for calling external services or systems.
- Prompts, security scanners, and permissions.

At runtime, applications send user requests to Cortex. The platform orchestrates LLM calls, tool invocations, and document retrieval (for RAG) based on the config configuration, and logs activity for observability and security.
