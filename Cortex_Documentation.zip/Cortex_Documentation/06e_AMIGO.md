# AMIGO

**Page URL:** https://cortex.lilly.com/spe/documentation/ai-products/amigo/

**Access:** amigo.lilly.com (request via MyAccess)

---

## Overview

AMIGO is a GenAI-powered platform designed to support front-line engineers and manufacturing personnel by providing real-time insights, intelligent recommendations, and alerts for production line management.

Instead of manually searching through siloed records, users can interact with AMIGO through natural language queries to quickly find answers, resolve issues proactively, and access relevant documentation.

---

## Key Capabilities

- Real-time insights and intelligent recommendations for production line management
- Natural language queries — ask questions and get context-aware responses
- Production performance analysis — review historical data and trends
- Proactive issue resolution — surface relevant information before problems escalate
- Advanced document search across multiple repositories

---

## Data Sources

**Structured Data:**
- MES Systems — Batch information and alarm records

**Unstructured Data:**
- Veeva — Documents and SOPs
- OneNote — Team notebooks and notes
- SharePoint — Shared documents and knowledge bases

---

## CORTEX Integration

AMIGO uses CORTEX as its RAG service for document searching, using a multi-agent architecture integrating large language models and prompt engineering to deliver context-aware results across multiple sources.
