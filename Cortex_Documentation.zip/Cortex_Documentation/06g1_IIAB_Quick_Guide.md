# IIAB Quick Start Guide

**Page URL:** https://cortex.lilly.com/spe/documentation/ai-products/insights-in-a-box/quick-guide/

**Access:** liab.legal.lilly.com (request access from nandakumar_nethra@lilly.com)

---

## What is IIAB?

Insights In A Box helps teams turn unstructured documents into structured, actionable data at scale using AI-powered analysis.

**Core structure:** Organization → Vault → Project → Columns & Prompts → Analysis → Export

---

## Quick Start (Step-by-Step)

1. Select your **Organization** from the sidebar dropdown
2. Create or open a **Vault** — your secure document workspace
3. Upload documents (.pdf, .docx, max 15 MB each) via local upload or SharePoint sync
4. Create a **Project** (Public or Private) inside the Vault
5. Link documents from the Vault into the Project
6. Add **columns** — each column defines an insight to extract (e.g., "Termination Date")
7. Write a prompt or select a template
8. Choose an LLM model
9. Optionally chain columns (use one column's output as input for another)
10. Run a **Preview Analysis** to validate setup and review estimated cost
11. Run a **Complete Analysis** once satisfied with the preview
12. Export results as .xlsx, .csv, or .json

---

## Roles at a Glance

| Role | Key Capabilities |
|------|-----------------|
| Vault Owner | Full control — create, edit, delete Vault; manage documents & users |
| Vault Editor | Upload documents, create projects |
| Vault Viewer | View-only; can create private projects |
| Project Owner | Full control — configure columns/prompts, run analysis, manage users |
| Project Editor | Configure columns/prompts, run analysis, link/unlink documents |
| Project Viewer | View results, export data |

> Project Only roles (Editor/Viewer) grant project access without broader Vault access.

---

## Key Navigation

| Sidebar Section | Purpose |
|-----------------|---------|
| Dashboard | Overview of recent vaults, projects & document counts |
| Vaults | Manage vaults, documents & projects |
| Prompts | Manage prompt templates (My Prompts & Public Prompts) |
| Admin Workspace | Org-level admin tools (admins only) |

---

## Analysis Run Modes

| Mode | When to Use |
|------|-------------|
| Preview | Quick validation of setup & cost estimation |
| Complete | Full extraction across all linked documents |
| Newly Linked | Process only documents added since last run |

> **Tip:** Always run a Preview first to validate prompts and estimate costs before a full run.

---

## Important Limits

- **Supported file types:** .pdf, .docx
- **Max file size:** 15 MB per file
- During analysis runs, project actions are restricted for all members
