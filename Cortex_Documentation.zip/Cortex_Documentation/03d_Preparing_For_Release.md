# Preparing For Release

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/preparing-for-release/

---

## Overview

This section covers operational requirements for deploying agents to production: change management, monitoring, and version control.

---

## Production Considerations

### Performance
- Use token-saving strategies where appropriate
- Configure job priority (low/high priority queuing)
- Consider off-peak batch processing for non-urgent workloads

### Scalability
Cortex uses **Temporal** for job management:
- Low/high priority queuing
- Automatic resource allocation
- Long-running job support

### Reliability
- Platform operations team monitoring
- Real-time alarming
- Observability stack integration

---

## Operational Components

1. **Operational Change Management** – Organizational change management process for deployment approval and documentation
2. **Observability Dashboards & Alerting** – Monitoring dashboards and alerts for tracking agent health and performance
3. **Config Change Management** – Version control for configuration changes, rollbacks, and multi-version management

---

## Post-Release

- Monitor performance dashboards
- Respond to alerts
- Track usage patterns
- Collect user feedback
- Document incidents and improvements

---

## Sub-pages

- [Operational Change Management](/spe/documentation/guides/preparing-for-release/operational-change-management/)
- [Observability Dashboards & Alerting](/spe/documentation/guides/preparing-for-release/observability-dashboards-alerting/)
- [Config Change Management](/spe/documentation/guides/preparing-for-release/config-change-management/)
