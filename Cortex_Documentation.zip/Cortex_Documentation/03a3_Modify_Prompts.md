# Modify Prompts

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/building-your-agent/modify-prompts/

---

## Overview

Prompts are instructions that guide your agent's behavior, tone, and response style. In Cortex, you can create reusable prompt configurations that can be shared across multiple agents.

Manage prompts through the [Landing Zone Prompts UI](https://cortex.lilly.com/spe/landing-zone).

---

## Creating a Prompt Configuration

```bash
curl -X POST https://cortex.lilly.com/prompt \
  -H "Content-Type: application/json" \
  -d '{
    "name": "customer-service-prompt",
    "displayName": "Customer Service Assistant",
    "description": "Prompt for customer service interactions",
    "prompt": "You are a helpful customer service representative...",
    "owners": ["your-email@lilly.com"]
  }'
```

---

## Managing Prompts

| Operation | Endpoint |
|-----------|----------|
| List all prompts | `GET /prompt` |
| Get specific prompt | `GET /prompt/{name}` |
| Update prompt | `PUT /prompt` |
| Delete prompt | `DELETE /prompt/{name}` |

---

## Using Prompts in Your Agent

Reference your prompt configuration in a model config:

```json
{
  "name": "support-agent",
  "model_type": "model-chain",
  "base_model": "gpt-4o",
  "system_prompt": "customer-service-prompt",
  "owners": ["your-email@lilly.com"]
}
```

---

## Prompt Engineering Tips

- **Be Specific:** Provide clear, detailed instructions
- **Define Role and Tone:** Specify who the agent should act as
- **Set Constraints:** Define what the agent should and shouldn't do
- **Provide Examples:** Show what good output looks like
- **Handle Uncertainty:** Instruct to say "I don't know" when appropriate

---

## Example Prompts

### Customer Service Agent
```
You are a customer service representative for a healthcare company.

Your responsibilities:
- Respond professionally and empathetically
- Provide accurate information about products and services
- Escalate complex issues to human agents when necessary
- Never provide medical advice

If you don't have information, say "I don't have that information available, but I can connect you with someone who can help."
```

### Technical Documentation Assistant
```
You are a technical documentation assistant helping developers understand our APIs.

Guidelines:
- Use clear, concise language
- Include code examples when relevant
- Provide step-by-step instructions
- Highlight important warnings or limitations
- Base answers only on provided documentation
```

### Data Analysis Assistant
```
You are a data analyst helping users understand their data.

When analyzing data:
1. Identify key trends and patterns
2. Note any anomalies or outliers
3. Provide statistical context when relevant
4. Base conclusions only on the provided data

Format:
- Key Findings (bullet points)
- Detailed Analysis (2-3 paragraphs)
- Recommendations (if applicable)
```

---

## Testing Your Prompts

After configuring prompts, test them with diverse queries. Use Cortex's evaluation tools to measure effectiveness and iterate based on results.
