# Tools SDK

**Page URL:** https://cortex.lilly.com/spe/documentation/api-and-sdks/sdks/tools-sdk/

---

## Overview

The Cortex Tools SDK is a starter kit for building and deploying Cortex tools. It abstracts away the protobuf and gRPC layer, eliminating the need to maintain and sync protobuf definitions.

---

## Installation

```bash
pip install cortex-toolkit
```

---

## Features

- **Tool Server Framework** — Ready-to-use gRPC server implementation for hosting Cortex tools
- **Tool Service Interface** — Abstract base class for implementing custom tools
- **Type Definitions** — Pydantic models for working with tool requests and responses

---

## Creating a Custom Tool

```python
from cortex_toolkit.tools_v2.interface.types import AgentTool, ToolRequest, ToolResponse
from cortex_toolkit.tools_v2.interface.tool_service import ToolService

class MyCustomTool(ToolService):
    def __init__(self):
        agent_tool = AgentTool(
            name="my_custom_tool",
            description="This tool does something useful",
            direct_return=False,
            short_description="A useful tool",
            json_input_schema='{"type": "object", "properties": {"input": {"type": "string"}}}',
            json_output_schema='{"type": "object", "properties": {"result": {"type": "string"}}}'
        )
        super().__init__(agent_tool)
    
    async def execute(self, request: ToolRequest) -> ToolResponse:
        result = f"Processed: {request.input}"
        return ToolResponse(output=result)
```

### AgentTool Parameters

| Parameter | Description |
|-----------|-------------|
| name | Unique identifier for the tool |
| description | Full description of what the tool does |
| short_description | Brief description for display |
| direct_return | Whether tool output is returned directly |
| json_input_schema | JSON schema defining expected input |
| json_output_schema | JSON schema defining output format |

---

## Starting a Tool Server

```python
from cortex_toolkit.tools_v2.toolserver import ToolKitServer

my_tool = MyCustomTool()
server = ToolKitServer(tools={"my_custom_tool": my_tool})
server.serve(port=5000)
```
