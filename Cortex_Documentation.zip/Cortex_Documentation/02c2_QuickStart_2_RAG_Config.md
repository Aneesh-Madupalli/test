# QuickStart 2: Build Your First RAG Config

**Page URL:** https://cortex.lilly.com/spe/documentation/getting-started/quickstart/qs2-rag-model/

---

## Overview

This QuickStart walks through building a simple retrieval-augmented generation (RAG) config in Cortex. You will:

- Create a Cortex Data Config that stores and processes documents for retrieval
- Ingest a small set of documents into Pinecone vector database
- Create a Model Config that implements a doc-chain (RAG) workflow
- Ask questions against the model and see responses that reference the ingested content

**Estimated time:** 5-10 minutes

> Many users will want to create Data and Model Configs through Landing Zone rather than via code. This guide is for developers who need programmatic access.

---

## Prerequisites

Before you begin, ensure you have:

- Access to the Cortex API
- A document to upload (PDF, DOCX, or TXT format)
- Basic familiarity with REST APIs and curl or Python

---

## Step 1: Plan Your RAG Use Case

Before you configure anything, define:

- **Question types** – What kinds of questions should your model answer?
- **Documents** – What documents will serve as your knowledge source?
- **Constraints** – Are there sensitivity requirements, latency needs, or compliance considerations?

---

## Step 2: Create a Data Configuration

A Data Config defines how documents are processed, chunked, embedded, and stored in a vector database.

### Key Configuration Elements

| Field | Description | Example |
|-------|-------------|---------|
| name | Unique identifier (lowercase alphanumeric with dashes) | "my-rag-data" |
| displayName | Human-readable name | "My RAG Data Source" |
| auth | Access control settings | {"owners": ["testuser@lilly.com"]} |
| embedding | Embedding model configuration | {"model": "text-embedding-3-small", "open_api_type": "azure"} |
| model_version | Model for contextual chunking | {"model_class": "lilly-openai", "model_iteration": "7"} |
| vectorstore | Vector database type | "pinecone" |
| chunk_size | Size of text chunks | 1500 |
| chunk_overlap | Overlap between chunks | 300 |

### Example: Create Data Config via API

```bash
curl -X POST "https://<cortex_base_url>/data" \
  -H "Content-Type: application/json" \
  -H "x-user: testuser@lilly.com" \
  -H "x-groups: your-group" \
  -H "x-org: {\"name\": \"your-org\"}" \
  -d '{
  "name": "quickstart-data",
  "displayName": "QuickStart Data Config",
  "data_config_description": "Data source for QuickStart RAG tutorial",
  "auth": {
    "owners": ["testuser@lilly.com"],
    "users": [],
    "owners_group": [],
    "access_groups": []
  },
  "embedding": {
    "model": "text-embedding-3-small",
    "open_api_type": "azure"
  },
  "model_version": {
    "model_class": "lilly-openai",
    "model_iteration": "7"
  },
  "vectorstore": "pinecone",
  "chunk_size": 1500,
  "chunk_overlap": 300,
  "allowed_model_configs": ["quickstart-model"]
}'
```

### Example: Create Data Config via Python

```python
import requests

cortex_url = "https://<cortex_base_url>"
user_email = "testuser@lilly.com"

data_config = {
    "name": "quickstart-data",
    "displayName": "QuickStart Data Config",
    "data_config_description": "Data source for QuickStart RAG tutorial",
    "auth": {
        "owners": [user_email],
        "users": [],
        "owners_group": [],
        "access_groups": []
    },
    "embedding": {
        "model": "text-embedding-3-small",
        "open_api_type": "azure"
    },
    "model_version": {
        "model_class": "lilly-openai",
        "model_iteration": "7"
    },
    "vectorstore": "pinecone",
    "chunk_size": 1500,
    "chunk_overlap": 300,
    "allowed_model_configs": ["quickstart-model"]
}

response = requests.post(
    f"{cortex_url}/data",
    json=data_config,
    headers={
        "x-user": user_email,
        "x-groups": "your-group",
        "x-org": '{"name": "your-org"}'
    }
)

if response.status_code == 200:
    print("Data configuration created successfully!")
else:
    print(f"Error: {response.text}")
```

> The `allowed_model_configs` field specifies which model configs can access this private data source.

---

## Step 3: Upload and Process Documents

### Upload via API

```bash
curl -X POST "https://<cortex_base_url>/data/upload/quickstart-data" \
  -H "x-user: testuser@lilly.com" \
  -H "x-groups: your-group" \
  -H "x-org: {\"name\": \"your-org\"}" \
  -F "files=@/path/to/your/document.pdf"
```

### Check Job Status

```bash
curl -X GET "https://<cortex_base_url>/data/job-status-id/quickstart-data/{job_id}" \
  -H "x-user: testuser@lilly.com" \
  -H "x-groups: your-group" \
  -H "x-org: {\"name\": \"your-org\"}"
```

Possible status values: `queued`, `started`, `finished`, `failed`

---

## Step 4: Create a Model Configuration with doc-chain

A Model Config defines how queries are processed. For RAG, you'll use the `doc-chain` type.

### Key Configuration Elements

| Field | Description | Example |
|-------|-------------|---------|
| name | Unique identifier | "quickstart-model" |
| chain | Chain configuration for RAG | [{"chain_class": "doc-chain", "model_iteration": 1, "order": 1}] |
| model_versions | LLM to use for generation | [{"model_class": "lilly-openai", "model_iteration": 7}] |
| data | Data configs to search | ["quickstart-data"] |
| k_value | Number of chunks to retrieve | 5 |
| doc_relevance_threshold | Minimum similarity score | 0.0 |

### Example: Create Model Config via API

```bash
curl -X POST "https://<cortex_base_url>/model" \
  -H "Content-Type: application/json" \
  -H "x-user: testuser@lilly.com" \
  -d '{
  "name": "quickstart-model",
  "displayName": "QuickStart RAG Model",
  "chainable": true,
  "chain": [{"chain_class": "doc-chain", "model_iteration": 1, "order": 1}],
  "model_versions": [{"model_class": "lilly-openai", "model_iteration": 7, "priority": 0}],
  "data": ["quickstart-data"],
  "vectorstore": "pinecone",
  "k_value": 5,
  "doc_relevance_threshold": 0.0
}'
```

---

## Step 5: Test Your RAG Model

### Query via API

```bash
curl -X POST "https://<cortex_base_url>/model/ask/quickstart-model" \
  -H "x-user: testuser@lilly.com" \
  -F "q=Who is Eli Lilly and what is the company known for?"
```

### Query via Python

```python
question = "Who is Eli Lilly and what is the company known for?"

response = requests.post(
    f"{cortex_url}/model/ask/quickstart-model",
    data={"q": question},
    headers={"x-user": user_email, "x-groups": "your-group", "x-org": '{"name": "your-org"}'}
)

result = response.json()
print(f"Answer: {result['message']}")
```

---

## Chain Types for RAG

| Chain Type | Description | Use Case |
|------------|-------------|----------|
| doc-chain | Basic similarity search RAG | General Q&A over documents |
| hybrid-doc-chain | Combines keyword and semantic search | Queries with specific terminology |
| model-enhanced-query-chain | LLM expands query before retrieval | Short or ambiguous queries |

---

## Key Parameters

### Retrieval Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| k_value | 20 | Number of chunks to retrieve from vector database |
| doc_relevance_threshold | 0.5 | Minimum similarity score (0.0-1.0) |
| chunk_size | 1500 | Size of document chunks in tokens |
| chunk_overlap | 300 | Overlap between adjacent chunks |

### LLM Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| temperature | 0 | Controls randomness (0 = deterministic) |
| max_response_token_size | - | Maximum response length |
| model_class | - | Provider (e.g., lilly-openai, lilly-anthropic) |
| model_iteration | - | Specific model version |

---

## Supported Vector Databases

- Pinecone (recommended for production)
- Elasticsearch (for hybrid search capabilities)
- Index Factory (EDB) (enterprise deployment option)

---

## Common Issues and Solutions

| Issue | Solution |
|-------|----------|
| "Data config is private and model config is not in allowed list" | Add your model config name to `allowed_model_configs` |
| "Model version is deprecated" | Set model_iteration to 7 (GPT-4o) |
| Job stays "started" | Wait 2-5 minutes; check file format, size (<100MB) |
| Responses don't reference documents | Verify job completed, lower threshold, increase k_value |

---

## Next Steps

- Try hybrid search for queries with specific terminology
- Optimize chunk size (500-1000 for Q&A, 2000-3000 for summarization)
- Add evaluations with ground-truth Q&A pairs
- Scale by uploading more documents or creating multiple data configs
