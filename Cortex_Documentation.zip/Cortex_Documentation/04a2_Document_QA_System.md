# Document Q&A System (RAG)

**Page URL:** https://cortex.lilly.com/spe/documentation/use-cases-and-demos/end-to-end-walkthroughs/document-qa-system/

---

## Overview

Create a RAG system that answers questions based on your uploaded documents.

**How RAG Works:**
1. User submits a query
2. System searches indexed documents for relevant content
3. Retrieved documents are passed to the LLM with the query
4. LLM generates a response grounded in your documents

---

## Prerequisites

- A working model-only config (from Build a Simple Chatbot walkthrough)
- Access to the Cortex API

---

## Find Available Embeddings

`GET /data/embeddings/list` — Review embedding models compatible with your LLM.

---

## Step 3: Create a Data Config

`POST /data/`

```json
{
  "name": "mydemo-1",
  "auth": {"owners": ["your-email@lilly.com"], "private": true},
  "s3_bucket": "lly-light-dev",
  "s3_prefix": "llm-dev",
  "s3_prefix_data": "data/mydemo-1/docs",
  "displayName": "mydemo-1",
  "data_config_description": "Sample data for my chat model.",
  "embedding": {"model": "text-embedding-3-small", "open_api_type": "azure"},
  "model_version": {"model_class": "lilly-openai", "model_iteration": "7"},
  "vectorstore": "pinecone",
  "allowed_model_configs": ["mydemo-1"],
  "chunk_size": 1500,
  "chunk_overlap": 300,
  "contextual_chunking": {"is_enable": false, "chunk_size": 1500, "chunk_overlap": 300, "depth": 3}
}
```

### Key Fields

| Field | What to Set |
|-------|------------|
| name | Unique name (should match model config if linking) |
| embedding.model | From `/data/embeddings/list` |
| vectorstore | "pinecone" or "elasticsearch" |
| allowed_model_configs | List of model configs that can access this data |

Success response: `{"message": "success"}`

---

## Steps 5-7: Verify and Upload

- `GET /data/{name}` — Verify data config was created
- `POST /data/upload/{name}` — Upload PDF or document (returns `job_id`)
- `GET /data/list-files/{name}` — Verify uploaded files

---

## Step 8: Link Model and Data Config

Get your model config via `GET /model/{model}`, then `POST /model/` with the `data` field updated:

```json
"data": ["mydemo-1"]
```

---

## Step 9: Test Your Document Q&A System

Go to Chat in a Box and ask questions about your uploaded document content. The chatbot will retrieve relevant information and return grounded responses.
