# Monitoring

**Page URL:** https://cortex.lilly.com/spe/documentation/concepts/operations/monitoring/

---

## Overview

Monitoring provides visibility into platform health and agent performance.

---

## Observability Stack (PLG Stack)

| Component | Purpose |
|-----------|---------|
| Prometheus | Metrics collection |
| Loki | Log aggregation |
| Grafana | Dashboards and visualization |

---

## Dashboards

Applications can build custom Grafana dashboards to monitor agent-specific metrics and behavior.

---

## Alerting

Alerts can be configured through Grafana to notify teams of issues.

---

## API Status

Real-time API endpoint status: https://cortex.lilly.com/spe/status/
