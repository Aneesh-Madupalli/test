# Use APIM Gateway

**Page URL:** https://cortex.lilly.com/spe/documentation/api-and-sdks/api/apim/

---

## Overview

Step-by-step instructions for registering, configuring, and accessing Cortex API through Azure API Management (APIM) Gateway using OAuth 2 client credentials and Entra ID bearer tokens.

---

## Steps to Integrate

### Step 1: Register Your Application
- Request an app registration in Lilly Entra ID
- Cortex requires **one app registration per deployment environment** (dev, QA, production = 3 registrations)

### Step 2: Create Client Secret
- Obtain the `client_id` from App Registration Overview in Entra admin center
- Generate a client secret via Azure Portal → App Registrations
- Store the client secret securely

### Step 3: Request Client ID on Access List
- Submit a request to the Cortex team to add your ClientId to the access list
- Wait up to **48 hours** for confirmation before proceeding

### Step 4: Update Access to Configurations
Add your application `client_id` as an owner in each config (Model, Data, Prompt, Security):

```json
{
  "name": "healthbot",
  "auth": {
    "owners": ["john.doe@lilly.com", "c95fc6ad-f31b-4fb1-b959-5c80fd708717"],
    "private": true
  }
}
```

### Step 5: APIM Endpoints

**Internet-facing:**

| Environment | URL |
|-------------|-----|
| Dev | https://gateway.apim-dev.lilly.com/cortex |
| QA | https://gateway.apim-qa.lilly.com/cortex |
| Production | https://gateway.apim.lilly.com/cortex |

**Lilly private network-facing:**

| Environment | URL |
|-------------|-----|
| Dev | https://gateway-intranet.apim-dev.lilly.com/cortex |
| QA | https://gateway-intranet.apim-qa.lilly.com/cortex |
| Production | https://gateway-intranet.apim.lilly.com/cortex |

### Step 6: Python Authentication Example

**Obtain Access Token** (scope: `api://Cortex.lilly.com/.default`):

```python
import requests

client_id = "your-client-id"
client_secret = "your-client-secret"
tenant_id = "your-tenant-id"

def get_access_token(client_id, client_secret, tenant_id):
    token_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
    payload = {
        'grant_type': 'client_credentials',
        'client_id': client_id,
        'client_secret': client_secret,
        'scope': 'api://Cortex.lilly.com/.default'
    }
    response = requests.post(token_url, data=payload)
    response.raise_for_status()
    return response.json().get('access_token')
```

**Call Cortex API:**

```python
access_token = get_access_token(client_id, client_secret, tenant_id)
api_url = "https://gateway.apim-dev.lilly.com/cortex/model"

def call_crtx_api(access_token, api_url):
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }
    response = requests.get(f"{api_url}/model/{model_name}", headers=headers)
    return response.json()
```
