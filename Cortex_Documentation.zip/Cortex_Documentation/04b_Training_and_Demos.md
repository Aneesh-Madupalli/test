# Training and Demos

**Page URL:** https://cortex.lilly.com/spe/documentation/use-cases-and-demos/training-and-demos/

---

## Overview

Video resources for learning how to use Cortex.

- **Training Videos:** Step-by-step tutorials covering core Cortex workflows
- **Feature Demos:** Demonstrations of specific Cortex capabilities

---

## Sub-pages

- [Training Videos](/spe/documentation/use-cases-and-demos/training-and-demos/training-videos/)
- [Feature Demos](/spe/documentation/use-cases-and-demos/training-and-demos/feature-demos/)
- [GenAI Lightning Demos](/spe/documentation/use-cases-and-demos/training-and-demos/genai-lightning-demos/)
