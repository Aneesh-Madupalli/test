# A2A (Agent-to-Agent) Protocol

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/building-reusable-components/a2a-protocol/

---

## Overview

Enable secure, scalable, and framework-agnostic agent-to-agent communication across the Lilly ecosystem. A2A is based on Google's Agent2Agent Protocol (contributed to Linux Foundation, v0.3.0) — the de facto standard for agent interoperability.

**A2A Registry:** https://a2a.cortex.lilly.com/docs

---

## A2A vs MCP

| Protocol | Purpose |
|----------|---------|
| A2A | Agent-to-agent communication — delegates tasks between agents |
| MCP | Tool-to-agent communication — connects agents to external tools/services |

Both are complementary: an orchestrator uses A2A to call a specialized agent, which uses MCP to access tools.

---

## Key Definitions

| Term | Definition |
|------|-----------|
| Agent Card | JSON description of an agent's capabilities and interface |
| Task | Stateful unit of work with unique ID and lifecycle |
| Task State | pending, active, input-required, completed, failed, canceled |
| SSE | Server-Sent Events for real-time streaming |
| JSON-RPC 2.0 | Primary transport protocol |

---

## Authentication

- **Delegated Auth** — Individual user credentials
- **AWS Auth** — IAM roles for backend services
- **APIM Auth** — Entra ID tokens with scope `api://Cortex.lilly.com/.default`

---

## Architecture Components

1. **FastAPI Server** — Central registry, handles all registration/lookup/management
2. **PostgreSQL Database** — Stores agent registry info for discovery
3. **Transport Layer** — JSON-RPC 2.0 + SSE for streaming

### Database Schema

```sql
CREATE TABLE agent_registry (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL UNIQUE,
    description TEXT,
    agent_url VARCHAR(512) NOT NULL,
    protocol_version VARCHAR(20) NOT NULL,
    preferred_transport VARCHAR(20) DEFAULT 'JSON-RPC',
    capabilities JSONB,
    security_schemes JSONB,
    skills JSONB,
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    agent_card_cache JSONB
);
```

---

## API Endpoints

### Agent Card Configuration

| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| POST | /a2a/agent_card | Create agent card | cortex-admin only |
| GET | /a2a/agent_card/{id} | Read agent card | All users |
| PUT | /a2a/agent_card/{id} | Update agent card | cortex-admin only |
| DELETE | /a2a/agent_card/{id} | Delete agent card | cortex-admin only |

### Cortex A2A Server

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /a2a/{agent_name}/.well-known/agent-card.json | Get A2A agent card |
| POST | /a2a/{agent_name} | Call A2A server |

---

## Example Agent Card

```json
{
  "name": "Orchestrator Agent",
  "description": "Orchestrates task generation and execution",
  "url": "http://localhost:10101/",
  "version": "1.0.0",
  "capabilities": {
    "streaming": true,
    "pushNotifications": true,
    "stateTransitionHistory": false
  },
  "defaultInputModes": ["text", "text/plain"],
  "defaultOutputModes": ["text", "text/plain"],
  "skills": [{
    "id": "executor",
    "name": "Task Executor",
    "description": "Orchestrates task generation and execution",
    "tags": ["execute plan"],
    "examples": ["Plan my trip to London, submit an expense report"]
  }]
}
```

---

## Model Configuration Integration

Enable automatic A2A agent card sync by setting `sync_a2a_card: true`:

```json
{
  "name": "my-agent-model",
  "sync_a2a_card": true,
  "chain": [{"chain_class": "agent-chain", "model_iteration": 1, "order": 1}],
  "model_versions": [{"model_class": "lilly-openai", "model_iteration": 7}]
}
```

> **cortex-admin only:** Setting `sync_a2a_card: true` requires cortex-admin privileges. Submit a ServiceNow ticket to request access.

### How It Works

When `sync_a2a_card` is enabled:
- **Automatic Registration** — Model config creates agent card in A2A registry
- **Sync on Updates** — Changes to model config trigger agent card updates
- **Cleanup on Deletion** — Removing model config removes agent card
- **Discovery** — Agent becomes discoverable through A2A endpoints

### Use Cases

- Multi-Agent Workflows — Agents discover and communicate with each other
- Service Integration — External systems discover available Cortex agents
- Dynamic Agent Networks — Runtime discovery of agent capabilities
