# Welcome to Cortex Documentation

**Page URL:** https://cortex.lilly.com/spe/documentation/welcome/  
**Last Modified:** Jun 5, 2026

---

## Overview

Cortex is Lilly's enterprise platform for building AI applications. This documentation will help you build, test, deploy, and operate AI agents using large language models (LLMs), retrieval-augmented generation (RAG), custom tools, data integrations, security controls, and production-ready deployment strategies.

---

## What You'll Find Here

### Getting Started
Start here to understand what the platform offers, get access, and build your first config. The QuickStart guides walk you through fundamental workflows including RAG configs, app integration, and data connections.

### Guides
Step-by-step instructions for building production-ready AI systems and agents. Learn how to add data sources, create custom tools, optimize prompts, implement security, and prepare for deployment with proper monitoring and versioning.

### Use Cases & Demos
Real-world examples and video walkthroughs showing end-to-end implementations. Explore working chatbots, document Q&A systems, agentic workflows, and feature demonstrations.

### API & SDKs
Technical references for integrating Cortex into your applications. Includes the Cortex Platform SDK for building agents and the Tools SDK for creating custom agent tools.

### AI Products
Documentation for Lilly's pre-built AI products including Chat In a Box (CIAB) and PromoMaker.

### Concepts
Foundational knowledge about generative AI, LLMs, RAG workflows, agents, and the Cortex architecture. Review these to deepen your understanding of the platform's capabilities.

### Building on Cortex Services
Learn how to get raw model access, select models, create model-only configs, and use the Cortex SDK for chat completions and embeddings.

### Support
Information about platform support, service level agreements, and how to get help when you need it.

---

## How to Use This Documentation

- **If you're new**: Start with Getting Started → "What is Cortex?" then proceed to the QuickStart guides
- **If you're building**: Go to Guides for detailed implementation instructions
- **If you're troubleshooting**: Check Support for help resources and contact information
- **If you're learning**: Explore Use Cases & Demos for practical examples and Concepts for deeper understanding

---

## Prerequisites

To use Cortex, you'll need approved access. See the Prerequisites & Access page for detailed requirements and how to request access.
