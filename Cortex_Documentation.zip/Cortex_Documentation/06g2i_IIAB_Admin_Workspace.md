# IIAB - Admin Workspace

**Page URL:** https://cortex.lilly.com/spe/documentation/ai-products/insights-in-a-box/user-guide/admin-workspace/

---

## Overview

The Admin Workspace is the organization-level control center for admins to manage access, review membership, monitor usage and costs, and configure available LLM models.

**Who can do it:** Organization admins only

---

## Tabs and Actions

### 1. Admin Tab
- View, add, and remove organization admins

### 2. Organization Members Tab
- Review Azure AD groups that have organization access
- Review AD group configuration and members
- No editing or adding users/groups in this view

### 3. Usage & Cost Metrics Tab
- Review usage and cost metrics for top vaults
- Monthly cost across organization and top LLMs used
- Use for governance and cost oversight

### 4. Manage Vaults & Projects Tab
- View vault/project contents, top LLM, cost breakdown, and content breakdown
- **Bulk access assignment:** Add users/groups to multiple vaults at once

**Bulk access flow:**
1. Open Manage Vaults & Projects
2. Select multiple Vaults
3. Choose **Add Users/Groups**
4. Search and select users or groups
5. Choose the role to assign (Owner/Editor/Viewer)
6. Confirm and review summary

### 5. Configure LLM Tab
- Review and disable/enable LLM models for analysis across the organization
- Reorder enabled LLMs — the **first LLM becomes default**
