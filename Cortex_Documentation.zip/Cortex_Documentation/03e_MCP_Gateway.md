# MCP Gateway

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/mcp-gateway/

---

## Overview

The MCP Gateway is the **enterprise access pattern for all MCPs at Lilly**. Once onboarded, users and agents can access MCPs from Cortex, Chat in a Box, and Enterprise Claude via the Cortex Connector.

> **Mandate:** All software at Lilly must provide a Model Context Protocol (MCP) server where AI interaction is applicable.

> Point-to-point agent-to-MCP connections are **strongly discouraged**. The MCP Gateway provides additional controls, access management, and protections.

---

## Two Workflows on This Page

1. **Adding Your MCP to the Gateway** — for MCP System Owners onboarding through Cortex Platform Operations
2. **Technical Reference** — for developers registering MCP clients, managing access, and calling tools via the API

---

## Deployment Scenarios

| Type | Description | Advantages | Disadvantages |
|------|-------------|-----------|---------------|
| Internal MCP | Deployed to Lilly's CATS environment | Easier to build, deploy in appropriate network segment | Requires MCP Owner to implement production operations |
| External MCP | Deployed on vendor's cloud | Built/maintained by vendor | Requires network modifications, may need auth infrastructure |

---

## Shared Responsibility

**Cortex is responsible for:**
- Security, performance, and uptime of the MCP Gateway itself
- Authorization service for owners to set access permissions
- Cortex tooling to measure MCP usage
- Forwarding MCP traffic logs to Cybersecurity

**MCP Owners are responsible for:**
- Security, performance, and uptime of the MCPs themselves
- Ongoing development, validation, and implementation
- Operations including security updates
- Communicating releases to Cortex Operations
- Managing authorization scope

---

## Onboarding Steps

### Step 1 — Develop and Validate Your MCP
- Test core functionality in pre-production
- Test the authentication flow
- For External MCPs: establish network connection before proceeding

### Step 2 — Register Your MCP Client (for HANGAR/CATS deployed MCPs)
Follow Register an MCP Client instructions. Once registered, MCP appears as a toolkit in Landing Zone.

### Step 3 — Submit a ServiceNow Ticket

Required fields:

| Field | Description |
|-------|-------------|
| name* | Name of the MCP client |
| MCP_Owner* | Primary technical owner email |
| ops_owner* | Operations contact |
| ops_channel* | Slack URL and support page URL |
| SAE_number* | SAE number for cybersecurity review |
| Host/URL* | Hosting environment or URL |
| configuration_item_servicenow* | ServiceNow CI name |
| assignment_group_servicenow* | ServiceNow assignment group |
| Admins* | Who can modify MCP configuration |
| Users* | Who can access this MCP |
| Public_flag* | Available to all MCP Gateway users? |
| Discoverable_flag* | Can all users see this MCP exists? |
| service_tier* | development, qa, or production |
| SLA* | Intended SLA in plain language |

### Steps 4-7
- Cortex Operations reviews ticket and confirms approval
- Configure GitHub repository with shared workflow step from Cortex Operations
- Go live, test, and announce in Viva Cortex channel

---

## Technical Reference

### Environments

| Environment | Application Service | MCP Gateway | Docs |
|-------------|---------------------|-------------|------|
| Production | v2.api.cortex.lilly.com/application | mcpgateway.api.cortex.lilly.com | v2.cortex.lilly.com |
| QA | v2-qa.api.cortex.lilly.com/application | mcpgateway-qa.api.cortex.lilly.com | v2-qa.cortex.lilly.com |
| Dev | v2-dev.api.cortex.lilly.com/application | mcpgateway-dev.api.cortex.lilly.com | v2-dev.cortex.lilly.com |

### Step 1: Register for MCP Gateway Access

Access is auto-provisioned on first call — no separate registration needed. First request may return 503 while provisioning; retry after 3-5 minutes.

```bash
curl -X POST https://mcpgateway.api.cortex.lilly.com/mcp \
  -H "Authorization: Bearer CATS_PLATFORM_TOKEN"
```

### Step 2: Create an Application

```bash
curl -X POST https://v2.api.cortex.lilly.com/application/v1/applications \
  -H "Authorization: Bearer CATS_PLATFORM_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "my-cortex-app",
    "owner_team": "my-team",
    "contact_email": "team@example.com",
    "description": "Application for MCP client management",
    "tier": "development"
  }'
```

Save the returned `id` — this is your `X-Application-ID` for all subsequent requests.

### Step 3: Register an MCP Client

**Minimal (no auth):**
```bash
curl -X POST https://v2.api.cortex.lilly.com/application/v1/mcp-clients \
  -H "Authorization: Bearer CATS_PLATFORM_TOKEN" \
  -H "X-Application-ID: YOUR_APPLICATION_ID" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "my-mcp-server",
    "connection_type": "sse",
    "connection_string": "https://my-mcp-server.example.com/sse"
  }'
```

**Key fields:**

| Field | Required | Description |
|-------|----------|-------------|
| name | Yes | Client name. Tools appear as `{name}-{tool_name}` |
| connection_type | Yes | `http` or `sse` |
| connection_string | Yes | URL of MCP server |
| auth_type | No | `none` (default), `headers`, `obo`, or `oauth` |
| tools_to_execute | No | `["*"]` = all (default), `[]` = none, or specific list |
| allow_for_all_apps_and_users | No | Default: false |
| allowed_applications | No | Per-application access grants |
| allowed_users | No | Per-user access grants (email address) |

**Authentication options:**
- **Static headers:** `auth_type: "headers"` + `headers: {"Authorization": "Bearer TOKEN"}`
- **OAuth:** `auth_type: "oauth"` — two-step flow: create returns `authorize_url`, then call `complete-oauth` after user authorizes

### Step 4: Manage MCP Clients

| Operation | Endpoint |
|-----------|----------|
| List clients | `GET /v1/mcp-clients` |
| Get client | `GET /v1/mcp-clients/{id}` |
| Update client | `PUT /v1/mcp-clients/{id}` |
| Delete client | `DELETE /v1/mcp-clients/{id}` |

### Step 5: Call MCP Tools via the Gateway

**List available tools:**
```bash
curl -X POST https://mcpgateway.api.cortex.lilly.com/mcp \
  -H "Authorization: Bearer CATS_PLATFORM_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc": "2.0", "id": "1", "method": "tools/list"}'
```

**Call a tool:**
```bash
curl -X POST https://mcpgateway.api.cortex.lilly.com/mcp \
  -H "Authorization: Bearer CATS_PLATFORM_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": "1",
    "method": "tools/call",
    "params": {
      "name": "my-mcp-server-get_weather",
      "arguments": {"city": "Indianapolis"}
    }
  }'
```

> Tool names are namespaced as `{client_name}-{tool_name}`.

### Access Control

- **Owning application** always has full implicit access
- **Open to all:** `allow_for_all_apps_and_users: true`
- **Specific apps:** `allowed_applications: [{"application_id": "UUID"}]`
- **Specific users:** `allowed_users: [{"user_id": "user@lilly.com"}]`

Each can specify `tools_to_execute` for per-entity tool restrictions.

---

## Application Service Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | /v1/applications | Create a new application |
| POST | /v1/mcp-clients | Register a new MCP client |
| GET | /v1/mcp-clients | List all MCP clients |
| GET | /v1/mcp-clients/{id} | Get MCP client details |
| PUT | /v1/mcp-clients/{id} | Update an MCP client |
| DELETE | /v1/mcp-clients/{id} | Delete an MCP client |
| POST | /mcp | Send MCP JSON-RPC (tools/list, tools/call) |

**Full API Reference:** https://v2.cortex.lilly.com/docs/platform/getting-started/
