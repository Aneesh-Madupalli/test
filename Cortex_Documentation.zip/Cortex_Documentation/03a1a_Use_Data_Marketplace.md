# Use the Data Marketplace

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/building-your-agent/add-data/use-data-marketplace/

---

> ⚠️ **Coming Soon** – The AI-Ready Data Marketplace is currently in development. This page describes planned functionality.

---

## Overview

The Data Marketplace will provide fast access to curated, AI-ready datasets for Cortex builders. Instead of manually preparing and ingesting data, you'll be able to discover pre-built data products, request access, and immediately use them in your agents.

---

## Planned Features

### Data Discovery

The marketplace will include a searchable interface where you can:
- Browse available datasets – View all curated data products
- Search by topic or domain – Find datasets relevant to your use case
- View metadata – Understand contents, source, update frequency, and ownership

**Planned URL:** data.lilly.com/marketplace

### One-Click Access Requests

- Automated access requests – Submit directly through the marketplace
- Owner approval workflow – Data owners receive and approve requests
- Immediate availability – Once approved, datasets appear in Landing Zone

### Integration with Landing Zone

- Add to your agent – Select datasets directly when building agents
- No manual data prep – Pre-processed and optimized for RAG workflows
- Multiple data sources – Combine multiple marketplace datasets in a single agent

### Enterprise Data Cards

Datasets will be published as Enterprise Data Cards—standardized metadata records that:
- Describe the dataset contents and structure
- Identify the owning team and operational contacts
- Are discoverable by agents through the A2A registry

---

## Current Alternatives

While the Data Marketplace is in development:
- **Create Data Connections (RAG)** – Upload and configure your own documents
- **Load Data in Context** – Pass data directly at query time
