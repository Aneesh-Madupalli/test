# Create a Model Config (Training Video)

**Page URL:** https://cortex.lilly.com/spe/documentation/use-cases-and-demos/training-and-demos/training-videos/create-a-model-config/

---

This video walks through the end-to-end process of building a Cortex Configuration using the API. You'll learn how to:

- Create a model config
- Set up a data config
- Upload documents
- Link everything together to create a functional chat experience
- Connect your Configuration to Chat in a Box by setting the `app_binding` field to `chatbuilder`
