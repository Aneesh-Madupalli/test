# Build a Simple Chatbot

**Page URL:** https://cortex.lilly.com/spe/documentation/use-cases-and-demos/end-to-end-walkthroughs/build-a-simple-chatbot/

---

## Overview

Create a basic chatbot using the Cortex API — a model-only configuration that sends queries directly to an LLM.

---

## Prerequisites

- Completed Getting Started and have Cortex access
- Access to Cortex API Documentation
- Access to Chat in a Box

---

## Find Available Models

1. Go to Cortex API and log in
2. Navigate to `GET /model/classes/list`
3. Click Try it out → Execute
4. Review the JSON response for `model_class` and `model_iteration` values

---

## Step 1: Log In

Navigate to https://cortex.lilly.com/docs and log in.

---

## Step 2: Navigate to Model Config API

Key endpoints:
- `GET /model/` – List all model configs
- `POST /model/` – Create a new config
- `GET /model/{model}` – Get details of a specific config
- `DELETE /model/{model}` – Delete a config
- `GET /model/exists/{model}` – Check if a config exists

---

## Step 3: Create Your Configuration

`POST /model/` — Example config:

```json
{
  "name": "mydemo-1",
  "auth": {
    "owners": ["your-email@lilly.com"],
    "private": true
  },
  "displayName": "My Demo Chatbot",
  "model_description": "A simple chatbot for testing",
  "chain": [
    {
      "chain_class": "model-only-chain",
      "model_iteration": 1,
      "order": 1,
      "chain_params": {}
    }
  ],
  "model_versions": [
    {
      "model_class": "lilly-openai",
      "model_iteration": 7,
      "priority": 100
    }
  ],
  "data": [],
  "k_value": 20,
  "doc_relevence_threshold": 0.5,
  "temperature": 0
}
```

### Key Fields

| Field | What to Set |
|-------|------------|
| name | Unique name (lowercase, alphanumeric, hyphens) |
| owners | Your email address |
| displayName | Human-readable name shown in Chat in a Box |
| model_description | Description of your chatbot |
| model_class | From `/model/classes/list` response |
| model_iteration | From `/model/classes/list` response |

---

## Step 4: Execute the Request

A 200 response indicates success.

### Error Responses

| Status | Meaning |
|--------|---------|
| 200 | Success |
| 403/404 | Permission denied or not found |
| 422 | Validation error — check `loc`, `msg`, `type` fields |
| 500 | Server error |

---

## Step 5: Query Your Chatbot

`GET /model/ask/{model}` — Enter your model name and a question (e.g., "What is the color of grass?")

---

## Step 6: Query via Chat in a Box (Optional)

1. Go to Chat in a Box
2. Find your chatbot by `displayName`
3. Click to start chatting

---

## Steps 7-8: Optional

- `GET /model/exists/{model}` — Check if config exists (returns true/false)
- `DELETE /model/{model}` — Delete the configuration
