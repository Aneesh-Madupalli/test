# IIAB - Columns

**Page URL:** https://cortex.lilly.com/spe/documentation/ai-products/insights-in-a-box/user-guide/columns/

---

## Overview

Columns contain configured prompts used for analysis. Each column defines an insight to extract. Columns can chain together — one column uses another's output as input.

**Who can do it:** Project Owner / Project Editor

---

## Column Actions

### Add a Column
1. Open the Project
2. Click Add Column (add icon in top right)
3. Provide: column title, optional source column link, prompt title, prompt instruction, LLM model
4. (Optional) Link to a source column for **column chaining**
5. Save the column

### Edit a Column
- Click the menu in the column header → Edit column → Update details → Save

### Delete a Column
- Click the menu in the column header → Delete column → Confirm
- **Note:** Cannot delete a source column unless you first unlink all dependent columns

---

## Column Chaining

Some columns can reference another column's results as input instead of the original document.

- When you edit a source column, re-run dependent columns to keep analysis up to date
- **Circular dependency prevention:** The app prevents invalid column links that would create a loop (e.g., A → B → A)

---

## Cost Estimation

- Estimated cost depends on: number of columns, number of documents, prompt instructions, and LLM model
- Column chaining may increase overall cost
- Use **"Run preview & estimate cost"** first — runs analysis on up to 50% of documents, shows estimated cost per column and total estimated cost
- Actual costs may vary — estimates based on average output length from preview results
