# Linear Chains with Prompt Tuning

**Page URL:** https://cortex.lilly.com/spe/documentation/use-cases-and-demos/end-to-end-walkthroughs/linear-chains/

---

## Overview

Linear chains enforce a fixed order of operations, ideal for scenarios requiring precision — mathematical calculations, workflow automation, or multi-step processes.

**Two prompt types used in linear chains:**
- **Supervisor Prompts:** Task-specific, detailed instructions
- **System Prompts:** High-level principles for workflow management

---

## Use Case 1: Arithmetic with Standard Operator Precedence (BODMAS)

Supervisor prompt instructs the agent to follow standard BODMAS/PEMDAS rules and chain tool calls sequentially.

**Example:** `(3 + 2) * 5 - (3 - 1) * 6 = 13.0`

Execution steps: AddNumbers → MultiplyNumbers → SubtractNumbers → MultiplyNumbers → SubtractNumbers

---

## Use Case 2: Custom Operator Precedence

Supervisor prompt overrides default rules — addition/subtraction prioritized before multiplication/division.

**Example:** `5+3*9-7/2-0` → reimagined as `(5+3)*(9-7)/(2-0) = 8`

---

## Use Case 3: Fixed Tool Sequence (Ignore User Input)

Supervisor prompt forces a fixed sequence regardless of user query:
1. FixedAlphabet → returns "A"
2. AsciiValue → returns 65
3. IncrementByTen → returns 75

**Result:** Always outputs 75, regardless of what the user asks.

---

## Use Case 4: Fixed Sequence + Acknowledge User Input

Same tool sequence, but the agent also acknowledges the actual user question before reporting the fixed result.

**Example output:** "The ASCII value of 'B' is 66. However, based on the predefined process, the generated number is 75."

---

## Best Practices for Effective Prompting

1. **Establishing Precedence** — Use numbered lists and CAPS for emphasis
2. **Few-Shot Prompting** — Include input/output examples in the prompt
3. **Step-by-Step Instructions** — Break tasks into sequential numbered steps
4. **Reframing User Inputs** — Reorganize input to align with process flow
5. **Caching Intermediate Results** — Store intermediate step results
6. **Specifying Tool Usage** — Explicitly say which tool to use at each step
7. **Structured Outputs** — Define a standard response format
8. **Handling Ambiguous Inputs** — Include fallback instructions
9. **Iterative Refinement** — Allow restart from Step 1 on errors
10. **Contextual Awareness** — Reiterate the goal to prevent deviation
11. **Example Chains** — Use multi-step examples for complex workflows

---

## Benefits of Linear Chains

- **Precision:** Strict adherence to predefined rules/workflows
- **Traceability:** Each step logged for transparency
- **Consistency:** Reduces variability in task execution
