# Access Methods

**Page URL:** https://cortex.lilly.com/spe/documentation/getting-started/what-is-cortex/access-methods/  
**Last Modified:** Jun 5, 2026

---

## Overview

You can interact with Cortex in several ways:

- **[Landing Zone (Developer Portal)](https://cortex.lilly.com/spe/landing-zone)** – a UI for viewing, creating, and operating Cortex Configs, and managing related components such as data, prompts, and security scanners.

- **[Cortex API](https://cortex.lilly.com/docs)** – HTTP endpoints such as `/Ask` for chat interactions, config configuration endpoints (for example `/model/SetConfig`), and direct LLM access and search APIs.

- **[Cortex SDK](/spe/documentation/api-and-sdks/sdks/)** – a client library that exposes chat completions, embeddings, responses, custom vector search, and logging.

- **[AI Products](/spe/documentation/ai-products/)** – internal applications (for example, Chat in a Box) that run on top of Cortex.
