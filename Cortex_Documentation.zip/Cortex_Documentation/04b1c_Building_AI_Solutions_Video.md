# Building AI Solutions with Cortex (Training Video)

**Page URL:** https://cortex.lilly.com/spe/documentation/use-cases-and-demos/training-and-demos/training-videos/building-ai-solutions-with-cortex/

---

This workshop recording walks participants through building and deploying an application on Cortex. The session covers:

- Hands-on exercises using GitHub Codespaces
- Agentic design patterns
- How tools in the Cortex ecosystem can be shared across applications

Pre-work for the workshop is available via the linked resource.
