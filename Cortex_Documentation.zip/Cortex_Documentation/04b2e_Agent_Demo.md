# Agent Demo (Feature Demo)

**Page URL:** https://cortex.lilly.com/spe/documentation/use-cases-and-demos/training-and-demos/feature-demos/agent-demo/

---

## Getting started with Agents

This page contains a video providing an overview of the Agent workflow, guiding you through the crucial steps and processes involved in deploying Cortex Agents.

**Notes:**
- Deploy process templates and documentation are currently in a draft state
- You can build the code from the agent template repository and deploy it to CATS
