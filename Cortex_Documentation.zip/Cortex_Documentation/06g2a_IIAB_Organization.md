# IIAB - Organization

**Page URL:** https://cortex.lilly.com/spe/documentation/ai-products/insights-in-a-box/user-guide/organization/

---

## Overview

An Organization is the top-level container. It determines what Vaults, Prompts, and Admin Workspace settings you can access.

**Who can do it:** All users added to the organization AD group.

---

## How to Switch Organization

1. Open the Organization switcher in the left sidebar
2. Review the list of Organizations you can access
3. Select the Organization you want to work in
4. Continue your work (Vaults, Prompts, Admin Workspace) in the newly selected Organization
