# PromoMaker

**Page URL:** https://cortex.lilly.com/spe/documentation/ai-products/promomaker/

---

## Overview

PromoMaker uses AI to generate promotional text for Lilly medicines. Users can create workspaces for individual brands, indications, and regions, and generate claims for them. Claims can be exported, edited, saved, or refined.

All AI functionality is powered by Cortex, using RAG with uploaded files. Claims can be supported by file-based evidence.

---

## Current Features

- Retrieval-augmented generation through Cortex (file-based evidence support)
- Workspace creation and management for brands, indications and regions
- Multi-claim generation
- Generate different components: headline, subheadline, citations, etc.
- Prompt-Form, Refinement, and Chat UIs
- Generic prompt generation
- Claim saving and exporting
- File uploading and viewing
- Jira Bug and Feature Requests
- Source Viewer
- Save Prompts
- Streaming Query Content
- Query Feedback

---

## Technologies

| Technology | Description |
|-----------|-------------|
| Next.js v14.2.14 | Frontend React-based framework with SSR |
| Tailwind CSS | Utility-first CSS framework |
| AntDesign | React UI library |
| TypeScript | Typed JavaScript superset |
| Docker | Containerization platform |
| GitHub Actions | CI/CD workflows |
| React Testing Library + Jest | Unit testing |

---

## Local Development

```bash
git clone https://github.com/EliLillyCo/Promo-Maker.git
cd Promo-Maker
npm install
# Create .env.local with required env vars (see .env.example.local)
npm run dev
```

Open http://localhost:3000

### DB Commands

```bash
npm run makeMigration    # Creates a new migration file
npm run migrate          # Applies pending migrations
npm run migrationRollback # Reverts the most recent migration
```

---

## Deployment

Deployed to Research AWS Light account using CATS:

| Branch | Environment |
|--------|------------|
| develop | dev CATS cluster |
| main | qa CATS cluster |
| releases | prod CATS cluster |

---

## External Links

- Jira Board
- Figma
