# Contributor Guide

**Page URL:** https://cortex.lilly.com/spe/documentation/editdocumentation/

---

## Overview

Any member of the Cortex community is encouraged to improve the Cortex documentation. The documentation is managed in GitHub as Markdown code, following standard software development practices with Pull Requests reviewed by documentation administrators.

**Repository:** [spe-docs on GitHub](https://github.com/EliLillyCo/spe-docs)  
**Theme:** Just the Docs (Jekyll)

---

## Understanding Front Matter

Every documentation page requires YAML front matter at the top of the file.

### Required Fields

| Field | Description |
|-------|-------------|
| layout | Page template: `page` or `default` |
| title | Page title shown in navigation and at top |
| last_modified_date | Date last updated (Month DD, YYYY) |
| permalink | URL path (e.g., /getting-started/) — must start and end with / |
| nav_order | Numeric position in navigation (lower = first) |
| has_children | `true` if this page has child pages |

### Optional Fields

| Field | Description |
|-------|-------------|
| parent | Title of parent page (for nested docs) |
| grand_parent | Title of grandparent page (for deeply nested pages) |
| has_toc | Set `false` to disable table of contents |

---

## Page Templates

### Standard Documentation Page
```yaml
---
layout: page
title: Your Page Title
last_modified_date: February 23, 2025
permalink: /your-page-url/
nav_order: 2
has_children: false
---
```

### Parent Page with Children
```yaml
---
layout: page
title: Parent Page Title
permalink: /parent-page/
has_children: true
---
```

### Child Page
```yaml
---
layout: page
title: Child Page Title
parent: Parent Page Title
permalink: /parent-page/child-page/
has_children: false
---
```

---

## Step-by-Step Contribution Guide

### 1. Clone the repository
```bash
git clone https://github.com/EliLillyCo/spe-docs.git
```

### 2. Create a branch
```bash
cd spe-docs
git switch -c your-new-branch-name
```

### 3. Make Your Changes

**Creating a New Page:**
- Create a new `.md` file in the appropriate directory
- Add required front matter at the top
- Write content using Markdown syntax
- Update `last_modified_date` to current date
- Choose appropriate `nav_order` value

**Editing an Existing Page:**
- Locate the file → make changes → update `last_modified_date`

### 4–7. Submit Your Changes
```bash
git status
git add .
git commit -m "Put your comment here"
git push -u origin your-branch-name
```

Then submit a Pull Request on GitHub. Repository Admin will review and approve.

---

## Best Practices

- Use clear, concise language
- Include code examples where appropriate
- Add images to `/assets/images/` if needed
- Follow the existing documentation style and tone
