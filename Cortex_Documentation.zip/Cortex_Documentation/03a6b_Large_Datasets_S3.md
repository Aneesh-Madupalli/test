# Working with Large Datasets in S3

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/building-your-agent/special-cases/large-datasets-s3/

---

## Overview

When datasets exceed typical upload limits or you need to connect to existing S3 buckets, Cortex provides several approaches for working with large datasets in S3.

---

## Connection Methods

### Direct S3 Connection

```json
{
  "name": "my-s3-data",
  "s3_bucket": "lly-light-dev",
  "s3_prefix": "llm-dev",
  "s3_prefix_data": "data/my-project/docs"
}
```

### S3 Bucket Synchronization

Cortex supports automatic synchronization with S3 buckets to keep data up-to-date.

### Connecting to EDB S3

For enterprise data sources, use the assume role access pattern.

#### Prerequisites — Cortex Role ARNs

| Environment | Role ARN |
|-------------|----------|
| Dev | arn:aws:iam::408787358807:role/lrl-light-apps/lrl-light-apps-llm-dev-lmm-data |
| QA | arn:aws:iam::474366589702:role/lrl-light-apps/lrl-light-apps-llm-qa-lmm-data |
| PROD | arn:aws:iam::283234040926:role/lrl-light-apps/lrl-light-apps-llm-dev-lmm-data |

1. Provide the Cortex role ARN to the EDB team for your environment
2. Provide your data config name as the External ID
3. EDB team creates a role and provides: `s3_bucket`, `s3_prefix`, `assume_role` ARN

#### Creating EDB Data Configuration

```json
{
  "name": "my-edb-data",
  "auth": {"owners": ["your-email@lilly.com"], "private": true},
  "s3_bucket": "lly-edp-raw-us-east-2-dev",
  "s3_prefix": "cortex_data",
  "assume_role": "arn:aws:iam::123456:role/EDBRoleWithExternalID",
  "embedding": {"model": "text-embedding-3-small", "open_api_type": "azure"},
  "model_version": {"model_class": "lilly-openai", "model_iteration": "7"},
  "vectorstore": "pinecone",
  "chunk_size": 1500,
  "chunk_overlap": 300
}
```

#### Data Ingestion from EDB

- `POST /data/index/{name}` — ingest files with optional filters (`doc_filter`, `filter_list`, `doc_prefix`)
- `GET /data/external_s3_list_files/{name}` — list files in source S3 prefix

> Access to EDB data sources is exclusively granted to data owners and custodians. Request via Lilly Data.

---

## Best Practices

- **Use Appropriate Prefixes:** Organize data with clear S3 prefix structures
- **Filter When Possible:** Use `doc_filter` or `filter_list` to process only needed files
- **Batch Processing:** For large datasets, consider off-peak batch processing
- **Use Assume Role:** For EDB connections, always use the assume role pattern
- **Version Control:** Track which data versions are ingested

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Cannot access S3 bucket | Verify assume_role ARN, confirm External ID matches data config name |
| Files not appearing | Use `external_s3_list_files` to verify, check s3_prefix |
| Ingestion fails | Review job status for errors, check file formats |
