# Observability

**Page URL:** https://cortex.lilly.com/spe/documentation/concepts/operations/observability/

---

## Overview

Observability encompasses logging and the ability to understand system behavior through collected telemetry.

---

## Logging

### Automatic Logging
All model inputs and outputs are automatically logged to the Cortex Guard Security Service. These logs are sent to **Splunk** for security analysis.

### Custom Logging
Applications can add custom logs which are collected by the PLG stack and queryable in Grafana.

---

## Tracing

The observability stack supports tracing to track request flow through services.
