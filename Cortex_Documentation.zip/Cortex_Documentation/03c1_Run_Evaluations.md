# Run Evaluations

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/functional-testing/run-evaluations/

---

## Overview

The Cortex Evaluation Service validates Cortex-based agent and RAG implementations. Primary interface is **Cortex Landing Zone**; APIs available for direct access.

**API Environments:**

| Environment | URL |
|-------------|-----|
| Dev | https://cortex-eval.dev.cortex.lilly.com/docs |
| QA | https://cortex-eval.qa.cortex.lilly.com/docs |
| Prod | https://cortex-eval.cortex.lilly.com/docs |

**Client IDs:**

| Environment | Client ID |
|-------------|-----------|
| Dev/QA | 2cbd5c62-00cf-418d-900d-32a4dfd98a4b |
| Prod | c95fc6ad-f31b-4fb1-b959-5c80fd708717 |

---

## What This Service Provides

- Benchmark Question Management (create, organize, manage question sets)
- Multi-Framework Support: Ragas + DeepEval (31 metrics total)
- Test Run Tracking
- Customizable Metrics
- Persistent Results with detailed analytics
- Role-Based Access Control

---

## Priority Modes

### question_level (Default)
Uses each individual question's `metric_config`. Falls back to evaluation-level if question has no config.

### evaluation_level
Uses only the metrics from the evaluation request, applied uniformly to ALL questions. Question-level configs are ignored.

---

## Supported Metrics (31 total)

### Ragas Framework (10 Metrics)
Faithfulness, Answer Relevancy, Contextual Relevancy, Contextual Recall, Contextual Precision, Answer Correctness, Answer Similarity, Answer Accuracy, Factual Correctness, Rouge Score

### DeepEval Framework (21 Metrics)

**RAG Metrics:** Answer Relevancy, Faithfulness, Contextual Relevancy, Contextual Precision, Contextual Recall

**Safety Metrics:** Bias, Toxicity, Non-Advice, Misuse, PII Leakage, Role Violation

**Other Metrics:** Hallucination, Summarization, Prompt Alignment

**Conversational/Multi-Turn:** Turn Relevancy, Role Adherence, Knowledge Retention, Conversation Completeness

**Agentic Metrics:** Tool Correctness, Argument Correctness

**Custom:** G-Eval (LLM-as-a-judge with custom criteria)

---

## Metric Scoring

- All metrics: **0.0 to 1.0**
- Most metrics: higher = better
- **Inverted metrics** (HALLUCINATION, BIAS, TOXICITY, MISUSE, ROLE_VIOLATION): lower = safer (0.0 = no issue, 1.0 = severe violation)

---

## Metric Requirements

| Metric | Question | Answer | Context | Ground Truth |
|--------|----------|--------|---------|--------------|
| Faithfulness | ✓ | ✓ | ✓ | |
| Answer Relevancy | ✓ | ✓ | | |
| Context Recall | ✓ | | ✓ | ✓ |
| Answer Correctness | ✓ | ✓ | | ✓ |
| Hallucination | ✓ | ✓ | ✓ | |
| Bias/Toxicity | ✓ | ✓ | | |
| Tool Correctness | ✓ | ✓ | | | + tools_called + expected_tools |
| G-Eval | ✓ | ✓ | Varies | Varies |

---

## Metric Selection Guide

| Use Case | Recommended Metrics |
|----------|---------------------|
| Medical/Legal QA | Faithfulness, Factual Correctness, Hallucination |
| Customer Support Bot | Answer Relevancy, Hallucination |
| RAG System Evaluation | Contextual Recall, Contextual Precision, Contextual Relevancy |
| Safety & Compliance | Bias, Toxicity, PII Leakage |
| Financial/Medical Chatbots | Non-Advice, Misuse |
| Agent Workflow QA | Tool Correctness, Argument Correctness |
| Multi-turn Chatbots | Turn Relevancy, Knowledge Retention, Conversation Completeness |
| Custom Evaluations | G-Eval |

---

## Excel/CSV Format for Question Sets

Required columns: `question_id`, `question`, `ground_truth`, `metric_config`

Optional columns: `metadata_filter`, `answer`

```
question_id | question                     | ground_truth | metric_config
Q001        | What is the capital of France? | Paris      | {"FAITHFULNESS_RAGAS": {"threshold": 0.8}, "HALLUCINATION_DEEPEVAL": {"threshold": 0.3}}
```

---

## Basic Metric Config Structure

```json
{
  "metrics": {
    "FAITHFULNESS_RAGAS": {"threshold": 0.7},
    "ANSWER_RELEVANCY_RAGAS": {"threshold": 0.7},
    "HALLUCINATION_DEEPEVAL": {"threshold": 0.3}
  },
  "metadata_filter": {
    "term": {"metadata.domain.keyword": "cybersecurity"}
  }
}
```

---

## Safety Metrics Config (with required parameters)

```json
{
  "NON_ADVICE_DEEPEVAL": {
    "threshold": 0.3,
    "configuration": {"advice_types": ["financial", "medical", "legal"]}
  },
  "MISUSE_DEEPEVAL": {
    "threshold": 0.3,
    "configuration": {"domain": "general knowledge assistant"}
  },
  "ROLE_VIOLATION_DEEPEVAL": {
    "threshold": 0.3,
    "configuration": {"role": "Informative and factual assistant"}
  }
}
```

---

## Best Practices

- Start with Landing Zone UI before using APIs directly
- Every question must have at least one metric configured
- `metadata_filter` is optional
- Use `question_level` for fine-grained control; `evaluation_level` for uniform testing
- Safety metrics use lower thresholds (e.g., 0.3) since higher scores = worse outcomes
