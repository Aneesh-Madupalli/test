# IIAB - Run Analysis

**Page URL:** https://cortex.lilly.com/spe/documentation/ai-products/insights-in-a-box/user-guide/run-analysis/

---

## Overview

Settings for analysis being run on linked documents: full output, quick validation, or incremental updates.

**Who can do it:** Project Owner / Project Editor

**Preconditions:** Project has at least one linked document and applicable columns selected.

---

## Run Modes

| Mode | Description |
|------|-------------|
| Run complete analysis | Full extraction across all linked documents for selected columns |
| Run preview & estimate cost | Smaller run (up to 50% of documents) to validate setup, outputs, and review estimated cost |
| Run analysis for newly linked documents | Process only documents newly linked since the last run |

---

## How to Run Analysis

1. Open the Project
2. Select "Run Analysis" from the right hand icon panel
3. Confirm applicable columns are selected
4. Choose the analysis mode
5. Start the run
6. Monitor progress until completion
7. Review results in the Project

---

## Additional Behaviors

### Stop Analysis
- Use the ⊘ symbol to end a run early if wrong columns/prompt/document set
- Stopping helps control cost and avoid generating unwanted outputs

### Restrictions During a Run
- While any analysis run is in progress, **all project actions are restricted** for all members
- To change columns: stop the run → update configuration → restart with a preview run
