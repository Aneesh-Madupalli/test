# Create a Data Config (Training Video)

**Page URL:** https://cortex.lilly.com/spe/documentation/use-cases-and-demos/training-and-demos/training-videos/create-a-data-config/

---

This video shows how to add data to your Cortex Configuration. You'll learn how to:

- Create a data config
- Upload documents (such as PDFs)
- Link the data config to your model config using the `data` field
- Build a working RAG pipeline that retrieves relevant information from uploaded documents to generate grounded responses
