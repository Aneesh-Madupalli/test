# Eliza — Enterprise AI Assistant

**Page URL:** https://cortex.lilly.com/spe/documentation/ai-products/eliza/

> Responses are AI-generated and may contain errors. Always verify accuracy and consult official sources before taking any action.

---

## Overview

Eliza is your all-in-one AI assistant for email, calendar, people, documents, notes, compliance, cybersecurity, and web research.

---

## What Eliza Can Do

### Email Management
Search inbox, catch up on recent messages, and draft emails. Saves drafts to Outlook Drafts folder for review before sending.

### Calendar & Scheduling
View schedule, check availability, find meetings by subject or attendee, detect scheduling conflicts.

### People & Organization
Look up colleagues, find reporting lines, check org structure, identify direct reports, get contact details.

### Document Search
Find files, policies, presentations, and spreadsheets across SharePoint and OneDrive. Can summarize document contents.

### Notes (OneNote)
Browse and search OneNote notebooks, sections, and pages. Read full page content, extract file attachments (PDF, DOCX, XLSX, PPTX).

### Ethics & Compliance
Answer policy questions on conflicts of interest, HCP interactions, meal/gift limits, anti-bribery, reporting concerns — tailored to your location.

### Cybersecurity Policies
Answer questions about password requirements, access controls, data protection, incident reporting, device/network/cloud security.

### Web Research
Search the web and summarize findings with sources — current events, stock prices, weather, industry news, general knowledge.

### Document Q&A
Upload a document (CSV, DOCX, JSON, MD, PDF, or TXT) and ask questions about its contents.

---

## Capabilities Summary

| Area | Can Do | Cannot Do |
|------|--------|-----------|
| Email | Search, filter, draft emails | Send emails (drafts saved for review) |
| Calendar | View schedule, check availability, detect conflicts | Create, modify, or delete events |
| People | Look up profiles, org charts, reporting lines | Access salary, compensation, or performance data |
| Documents | Search and summarize files on SharePoint/OneDrive | Create, edit, or delete documents |
| Notes | Browse, search, read OneNote pages; extract attachments | Create, edit, or delete notes |
| Ethics & Compliance | Answer policy questions from approved sources | Provide legal advice |
| Cybersecurity | Answer policy questions | Real-time threat intelligence or security scans |
| Web Research | Search web and summarize with sources | Access internal-only information |

> Eliza only accesses data you already have permission to view.

---

## Tips for Best Results

- **Be Specific** — Include names, dates, keywords, or locations
- **Include All Context in One Message** — Eliza does not retain conversation history
- **Combine Multiple Tasks** — Eliza can handle requests spanning multiple areas
- **Ask for Detail** — Include "detailed response" for comprehensive explanations
