# Cortex Environments

**Page URL:** https://cortex.lilly.com/spe/documentation/getting-started/what-is-cortex/evnrionments/  
**Last Modified:** Jun 5, 2026

---

## Overview

Below are the updated URLs across non-prod and prod environments.

---

## Environment URLs

| Environment | Cluster | URL |
|-------------|---------|-----|
| Dev | Dev | https://dev.cortex.lilly.com/docs |
| Stable Dev | Dev | https://stable.dev.cortex.lilly.com/docs |
| QA | QA | https://qa.cortex.lilly.com/docs |
| QA | Production | https://eval.cortex.lilly.com/docs |
| Production | Production | https://cortex.lilly.com/docs |

---

## APIs

| Environment | Cluster | URL |
|-------------|---------|-----|
| Dev | Dev | api.dev.cortex.lilly.com |
| Stable Dev | Dev | stable.api-d.cortex.lilly.com |
| SBX | Dev | api.sbx.cortex.lilly.com |
| QA | QA | api.qa.cortex.lilly.com |
| QA | Production | api.eval.cortex.lilly.com |
| Production | Production | api.cortex.lilly.com |
