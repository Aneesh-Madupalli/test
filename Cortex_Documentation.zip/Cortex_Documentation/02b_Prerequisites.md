# Prerequisites

**Page URL:** https://cortex.lilly.com/spe/documentation/getting-started/prerequisites-access/  
**Last Modified:** Jun 5, 2026

---

## Overview

If you're new to the Cortex platform, follow the detailed **step-by-step guide** to gain access, set up your environment and start building your first model.

### Steps:
1. **STEP 1.** Start the AI Review Process Early
2. **STEP 2.** Request Access to Cortex
3. **STEP 3.** Request an AWS Account

---

## Authentication Guidelines for Cortex

Cortex follows secure and robust authentication mechanisms to protect sensitive data and ensure system integrity. Cortex follows CATS Auth Patterns.

### Authentication Methods:

- **Delegated Auth (End-user Auth):**
  - Ideal for scenarios where individual user permissions are required.
  - The user authenticates directly via their account credentials.

- **AWS Auth:**
  - Used for backend services or automated workflows.
  - AWS roles and permissions are leveraged for secure access.

- **APIM Auth:**
  - Centralizes API security and access policies in one place.
  - Enables seamless integration and monitoring of multiple backend services.
  - Uses Microsoft Entra ID App Registration for authentication.
  - Setup Instructions: [API Authentication](/spe/documentation/api-and-sdks/api/overview/#authentication)

> **Important Notes:** (1) Cortex does not provide usernames/passwords for service accounts to ensure compliance with security policies. (2) For detailed steps, refer to the [Authentication Documentation](https://client-python.apps.lrl.lilly.com/).

---

## Environment Guidelines for Cortex

Cortex APIs are accessed through the **CATS** infrastructure.

### Environment Setup:
- Install required tools and dependencies in your local setup according to CATS guidelines.
- Configure the network and environment settings to comply with organizational security protocols.

### Additional Notes:

- **Codespaces:** If you plan to use LiteClient in Codespaces, reach out to the Cortex team for setup assistance.
- **Postman Usage:** Use browser sessions or cookies for secure authentication when using Postman.
- **Non-Lilly Devices:** Accessing Cortex from non-Lilly machines requires using Virtual Desktop Infrastructure (VDI).

For a detailed step-by-step guide, visit the [CATS Environment Documentation](https://cats.lilly.com/guide/PlatformOverview).

---

## Helpful Links

- [Cortex API Documentation](https://cortex.lilly.com/docs)
