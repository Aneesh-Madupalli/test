# Hybrid Search (Feature Demo)

**Page URL:** https://cortex.lilly.com/spe/documentation/use-cases-and-demos/training-and-demos/feature-demos/hybrid-search/

---

This video explains hybrid search — a retrieval method combining similarity scoring (meaning) with lexical scoring (word matches) for more robust results.

**Topics covered:**
- How hybrid search works in Cortex using Pinecone and Elasticsearch vector stores
- Comparison between standard similarity search and hybrid search responses
