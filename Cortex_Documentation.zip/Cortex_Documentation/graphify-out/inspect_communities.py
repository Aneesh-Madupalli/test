import json
from pathlib import Path

analysis = json.loads(Path('graphify-out/.graphify_analysis.json').read_text(encoding='utf-8'))

for cid, nodes in sorted(analysis['communities'].items(), key=lambda x: int(x[0])):
    cohesion = analysis['cohesion'].get(cid, 0)
    print(f"Community {cid} (cohesion={cohesion:.2f}, {len(nodes)} nodes):")
    for n in nodes[:8]:
        print(f"  - {n}")
    if len(nodes) > 8:
        print(f"  ... +{len(nodes)-8} more")
    print()
