import json
from graphify.build import build_from_json
from graphify.cluster import score_all
from graphify.analyze import god_nodes, surprising_connections, suggest_questions
from graphify.report import generate
from pathlib import Path

extraction = json.loads(Path('graphify-out/.graphify_extract.json').read_text(encoding='utf-8'))
detection  = json.loads(Path('graphify-out/.graphify_detect.json').read_text(encoding='utf-8'))
analysis   = json.loads(Path('graphify-out/.graphify_analysis.json').read_text(encoding='utf-8'))

G = build_from_json(extraction, root='C:/Users/L073881/Desktop/Cortex_Documentation', directed=False)
communities = {int(k): v for k, v in analysis['communities'].items()}
cohesion = {int(k): v for k, v in analysis['cohesion'].items()}
tokens = {'input': extraction.get('input_tokens', 0), 'output': extraction.get('output_tokens', 0)}

labels = {
    0:  "Use Cases & Demos",
    1:  "Core Concepts & Config Model",
    2:  "Platform Overview & Getting Started",
    3:  "Access Methods & Landing Zone",
    4:  "Tools & Custom Toolkit Building",
    5:  "Supported Models & Providers",
    6:  "RAG Optimization & Finetuning",
    7:  "SDK & APIM Authentication",
    8:  "Insights In A Box (IIAB) Core",
    9:  "Security, Guard & Evaluations",
    10: "Production Release & Observability",
    11: "AI Products: Compliance & AMIGO",
    12: "IIAB User & Admin Management",
    13: "Chat in a Box & PromoMaker",
    14: "API Overview & Auth Methods",
    15: "Realtime Voice & WebSocket",
    16: "Text-to-SQL Integration",
    17: "Prompt Configuration",
    18: "Support & SLAs",
    19: "Full API Reference & Swagger",
    20: "Contributor Guide & GitHub",
    21: "IIAB Edge Cases",
}

questions = suggest_questions(G, communities, labels)

report = generate(G, communities, cohesion, labels, analysis['gods'], analysis['surprises'],
                  detection, tokens, 'C:/Users/L073881/Desktop/Cortex_Documentation',
                  suggested_questions=questions)
Path('graphify-out/GRAPH_REPORT.md').write_text(report, encoding='utf-8')
Path('graphify-out/.graphify_labels.json').write_text(
    json.dumps({str(k): v for k, v in labels.items()}, ensure_ascii=False), encoding='utf-8'
)
print('Report updated with community labels')
print('\nGod nodes:')
for g in analysis['gods'][:8]:
    print(f'  {g}')
print('\nSurprising connections:')
for s in analysis['surprises'][:5]:
    print(f'  {s}')
print('\nSuggested questions:')
for q in questions[:5]:
    print(f'  - {q}')
