# Graph Report - C:/Users/L073881/Desktop/Cortex_Documentation  (2026-06-27)

## Corpus Check
- Corpus is ~30,825 words - fits in a single context window. You may not need a graph.

## Summary
- 294 nodes · 367 edges · 22 communities (19 shown, 3 thin omitted)
- Extraction: 88% EXTRACTED · 12% INFERRED · 0% AMBIGUOUS · INFERRED: 44 edges (avg confidence: 0.87)
- Token cost: 7,200 input · 3,100 output

## Community Hubs (Navigation)
- [[_COMMUNITY_Use Cases & Demos|Use Cases & Demos]]
- [[_COMMUNITY_Core Concepts & Config Model|Core Concepts & Config Model]]
- [[_COMMUNITY_Platform Overview & Getting Started|Platform Overview & Getting Started]]
- [[_COMMUNITY_Access Methods & Landing Zone|Access Methods & Landing Zone]]
- [[_COMMUNITY_Tools & Custom Toolkit Building|Tools & Custom Toolkit Building]]
- [[_COMMUNITY_Supported Models & Providers|Supported Models & Providers]]
- [[_COMMUNITY_RAG Optimization & Finetuning|RAG Optimization & Finetuning]]
- [[_COMMUNITY_SDK & APIM Authentication|SDK & APIM Authentication]]
- [[_COMMUNITY_Insights In A Box (IIAB) Core|Insights In A Box (IIAB) Core]]
- [[_COMMUNITY_Security, Guard & Evaluations|Security, Guard & Evaluations]]
- [[_COMMUNITY_Production Release & Observability|Production Release & Observability]]
- [[_COMMUNITY_AI Products Compliance & AMIGO|AI Products: Compliance & AMIGO]]
- [[_COMMUNITY_IIAB User & Admin Management|IIAB User & Admin Management]]
- [[_COMMUNITY_Chat in a Box & PromoMaker|Chat in a Box & PromoMaker]]
- [[_COMMUNITY_API Overview & Auth Methods|API Overview & Auth Methods]]
- [[_COMMUNITY_Realtime Voice & WebSocket|Realtime Voice & WebSocket]]
- [[_COMMUNITY_Text-to-SQL Integration|Text-to-SQL Integration]]
- [[_COMMUNITY_Prompt Configuration|Prompt Configuration]]
- [[_COMMUNITY_Support & SLAs|Support & SLAs]]
- [[_COMMUNITY_Full API Reference & Swagger|Full API Reference & Swagger]]
- [[_COMMUNITY_Contributor Guide & GitHub|Contributor Guide & GitHub]]
- [[_COMMUNITY_IIAB Edge Cases|IIAB Edge Cases]]

## God Nodes (most connected - your core abstractions)
1. `IIAB User Guide` - 9 edges
2. `Cortex Guard` - 9 edges
3. `Cortex Full API Reference` - 9 edges
4. `What is Cortex?` - 8 edges
5. `Cortex Architecture` - 8 edges
6. `Common Uses` - 7 edges
7. `QuickStart 2: Build Your First RAG Config` - 7 edges
8. `Add Data` - 7 edges
9. `Create Data Connections for RAG` - 7 edges
10. `Agentic Workflows Walkthrough` - 7 edges

## Surprising Connections (you probably didn't know these)
- `Supervisor Prompts` --semantically_similar_to--> `Supervisor Agent`  [INFERRED] [semantically similar]
  04a4_Linear_Chains.md → 04a3_Agentic_Workflows.md
- `Chat in a Box (CIAB)` --semantically_similar_to--> `PromoMaker`  [INFERRED] [semantically similar]
  06a_Chat_in_a_Box.md → 06b_PromoMaker.md
- `Compliance Assistant (E&C)` --semantically_similar_to--> `Eliza Enterprise AI Assistant`  [INFERRED] [semantically similar]
  06c_Compliance_Assistant.md → 06f_Eliza.md
- `Working with Large Datasets in S3` --conceptually_related_to--> `Pinecone Vector Store`  [INFERRED]
  03a6b_Large_Datasets_S3.md → 03a1d_Optimizing_RAG_Results.md
- `Safety Evaluation Metrics (Bias, Toxicity, PII)` --conceptually_related_to--> `Add Security (Cortex Guard)`  [INFERRED]
  03c1_Run_Evaluations.md → 03a4_Add_Security_Cortex_Guard.md

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **RAG Pipeline Components** — 02a_what_is_cortex_rag, 02c2_quickstart_2_rag_config_data_config, 03a1b_create_data_connections_rag_embedding_model, 03a1b_create_data_connections_rag_chunking, 02a4_architecture_pinecone [EXTRACTED 0.95]
- **Cortex Access Methods** — 02a3_access_methods_landing_zone, 02a3_access_methods_cortex_api, 02a3_access_methods_cortex_sdk [EXTRACTED 1.00]
- **Cortex Authentication Methods** — 02b_prerequisites_auth_delegated, 02b_prerequisites_auth_aws, 02b_prerequisites_auth_apim [EXTRACTED 1.00]
- **Cortex Security Stack: Guard + LLM Guard + Guardrails AI** — 03a4_cortex_guard, 03a4_llm_guard, 03a4_guardrails_ai [EXTRACTED 1.00]
- **RAG Optimization: Chunking + Hybrid Search + Chain Types** — 03a1d_chunking_configuration, 03a1d_hybrid_search, 03a1d_rag_chain_types [EXTRACTED 1.00]
- **Production Release: Change Mgmt + Observability + Config Mgmt** — 03d1_operational_change_management, 03d2_observability_dashboards, 03d3_config_change_management [EXTRACTED 1.00]
- **Multi-Agent Drug Discovery System** — 04a3_supervisor_agent, 04a3_database_agent, 04a3_scientist_agent, 04a3_chemistry_toolkit [EXTRACTED 1.00]
- **RAG Pipeline with Vector Stores** — 04a2_rag_pipeline, 04a2_pinecone_vectorstore, 04a2_elasticsearch_vectorstore, 04b2b_hybrid_search [EXTRACTED 1.00]
- **Cortex API Authentication Methods** — 05a_api_overview, 05a_delegated_auth, 05a_aws_auth, 05a_apim_auth [EXTRACTED 1.00]
- **IIAB Analysis Pipeline: Vaults → Projects → Columns → Run Analysis → Export** — 06g2b_iiab_vaults, 06g2c_iiab_projects, 06g2d_iiab_columns, 06g2e_iiab_prompts, 06g2f_iiab_run_analysis, 06g2g_iiab_export [EXTRACTED 1.00]
- **Cortex API Access Layer: Platform SDK, Tools SDK, APIM Gateway** — 05c_use_apim_gateway, 05d1_cortex_platform_sdk, 05d2_tools_sdk [INFERRED 0.85]
- **AMIGO Data Source Integration: MES, Veeva, OneNote, SharePoint** — 06e_amigo, 06e_mes_systems, 06e_veeva, 06e_sharepoint, 06e_onenote [EXTRACTED 1.00]
- **RAG Data Pipeline (Data Config + Document Processing + Vector Store + Embedding Models)** — 07c_data_config, 07c_document_processing_pipeline, 07c_vector_databases, 07a_embedding_models, 07d_rag_concept [EXTRACTED 1.00]
- **Cortex Agent Execution Framework (Chain Type + Toolkit + Executable Types + Prompt Template)** — 07_chain_type, 07e_toolkit, 07e_executable_types, 07f_prompt_template [INFERRED 0.85]
- **Cortex Security and Observability (Cortex Guard + LLM Guard + Splunk + PLG Stack)** — 07g_cortex_guard, 07g_llm_guard, 07i_splunk_logging, 07h_plg_stack [EXTRACTED 1.00]

## Communities (22 total, 3 thin omitted)

### Community 0 - "Use Cases & Demos"
Cohesion: 0.07
Nodes (39): Use Cases & Demos, Build a Simple Chatbot Walkthrough, Chat in a Box (CIAB), Model-Only Chain, Document Q&A System (RAG) Walkthrough, Elasticsearch Vector Store, Pinecone Vector Store, RAG Pipeline (+31 more)

### Community 1 - "Core Concepts & Config Model"
Cohesion: 0.08
Nodes (35): Chain Type (model-chain, doc-chain, tool-chain, agent-chain), Concepts Overview, Cortex Configuration Model, Data Configuration, Hybrid Search (Keyword + Semantic), Retrieval Augmented Generation (RAG), RAG Chain Types (doc-chain, hybrid-doc-chain, model-enhanced-query-chain), RAG Concept (Retrieval + Generation) (+27 more)

### Community 2 - "Platform Overview & Getting Started"
Cohesion: 0.08
Nodes (32): Cortex Documentation Site Map, Welcome to Cortex Documentation, Getting Started, MCP Mandate, Platform Overview, Cortex Config, Common Uses, Agentic Workflows (+24 more)

### Community 3 - "Access Methods & Landing Zone"
Cohesion: 0.09
Nodes (29): Access Methods, Cortex API, Cortex SDK, Landing Zone, Pinecone Vector Database, QuickStart 1: Landing Zone Overview, Agent Builder, Benchmark Question Set (BQS) (+21 more)

### Community 4 - "Tools & Custom Toolkit Building"
Cohesion: 0.12
Nodes (23): Add Tools, Custom Tools, Marketplace Tools, Featured Toolkits (Workday, Bing, Jira, ServiceNow), Use the Tool Marketplace, Toolkit Registry, Build a Custom Tool, CATS Deployment (+15 more)

### Community 5 - "Supported Models & Providers"
Cohesion: 0.09
Nodes (23): Chat/Completion Models, Embedding Models, Fine-Tuned Models (QLoRA, LoRA, Full Fine-Tuning), Model Access Patterns, Overview of Models, Amazon Bedrock Models (Nova, Titan), Anthropic Claude Models (Claude 3.5 Sonnet, Claude 3 Haiku), Google Vertex Models (Gemini) (+15 more)

### Community 6 - "RAG Optimization & Finetuning"
Cohesion: 0.16
Nodes (14): Chunking Configuration, Contextual Chunking, Hybrid Search, Optimizing RAG Results, Pinecone Vector Store, RAG Chain Types, Special Cases, Cortex Finetuning Guide (+6 more)

### Community 7 - "SDK & APIM Authentication"
Cohesion: 0.18
Nodes (13): Azure API Management (APIM) Gateway, Lilly Entra ID, OAuth 2 Client Credentials, Use APIM Gateway, Cortex Platform SDK, elilillyco-cortex-sdk Python Package, Lilly Artifactory, cortex-toolkit Python Package (+5 more)

### Community 8 - "Insights In A Box (IIAB) Core"
Cohesion: 0.24
Nodes (13): IIAB Quick Start Guide, IIAB Roles (Vault/Project), IIAB User Guide, IIAB Organization, IIAB Vaults, IIAB Projects, Column Chaining, IIAB Columns (+5 more)

### Community 9 - "Security, Guard & Evaluations"
Cohesion: 0.24
Nodes (12): Add Security (Cortex Guard), Guardrails AI, LLM Guard (ProtectAI), Prompt Injection and Jailbreak Protection, Security Configuration, Evaluation Metrics (31 total), G-Eval (LLM-as-a-judge), Run Evaluations (+4 more)

### Community 10 - "Production Release & Observability"
Cohesion: 0.22
Nodes (10): GitHub PR Workflow for Production, Operational Change Management, Grafana Dashboards, Observability Dashboards and Alerting, OpenObserve Log Dashboard, CODEOWNERS Access Control, Config Change Management, managed-configs GitHub Repository (+2 more)

### Community 11 - "AI Products: Compliance & AMIGO"
Cohesion: 0.22
Nodes (10): Compliance Assistant (E&C), GPT-4.1, WorkDay (Location Source), AMIGO, MES Systems, Multi-Agent Architecture, OneNote, SharePoint (+2 more)

### Community 12 - "IIAB User & Admin Management"
Cohesion: 0.29
Nodes (8): Access Roles: Owner/Editor/Viewer, Azure AD Group (IIAB Access), IIAB - Manage Users, User Access Management (IIAB), Bulk Access Assignment (Vaults and Projects), Configure LLM Tab (Admin Workspace), IIAB - Admin Workspace, Usage and Cost Metrics (Admin Workspace)

### Community 13 - "Chat in a Box & PromoMaker"
Cohesion: 0.29
Nodes (7): Chat in a Box (CIAB), CIAB Model Config Labels, RAG Assistant (CIAB), CATS Deployment (PromoMaker), Next.js v14 Frontend, PromoMaker, RAG via Cortex (PromoMaker)

### Community 14 - "API Overview & Auth Methods"
Cohesion: 0.33
Nodes (6): API & SDKs, API Overview, APIM Auth (Azure API Management / Entra ID), AWS Auth (IAM Roles), Delegated Auth (x-user header), Server-Sent Events (SSE) Streaming

### Community 15 - "Realtime Voice & WebSocket"
Cohesion: 0.40
Nodes (5): Azure APIM Gateway, MSAL Azure AD Authentication, Cortex Realtime API, Realtime Voice Setup and Integration, WebSocket Transport (Voice)

### Community 16 - "Text-to-SQL Integration"
Cohesion: 0.50
Nodes (4): AWS Secrets Manager, Database Whitelisting, Text-to-SQL Security Features, Text-to-SQL Integration Guide

### Community 17 - "Prompt Configuration"
Cohesion: 0.67
Nodes (3): Landing Zone Prompts UI, Modify Prompts, Prompt Configuration

### Community 18 - "Support & SLAs"
Cohesion: 0.67
Nodes (3): ServiceNow Support Channel, SLA Priority Levels (P1/P2/P3), Support and SLAs

## Knowledge Gaps
- **109 isolated node(s):** `Cortex-History`, `Cortex API`, `Delegated Auth (End-user Auth)`, `APIM Auth`, `Agent Builder` (+104 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **3 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `What is Cortex?` connect `Platform Overview & Getting Started` to `Access Methods & Landing Zone`?**
  _High betweenness centrality (0.016) - this node is a cross-community bridge._
- **Why does `Concepts Overview` connect `Core Concepts & Config Model` to `Supported Models & Providers`?**
  _High betweenness centrality (0.012) - this node is a cross-community bridge._
- **Why does `Embedding Models` connect `Supported Models & Providers` to `Core Concepts & Config Model`?**
  _High betweenness centrality (0.011) - this node is a cross-community bridge._
- **What connects `Cortex-History`, `Cortex API`, `Delegated Auth (End-user Auth)` to the rest of the system?**
  _109 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Use Cases & Demos` be split into smaller, more focused modules?**
  _Cohesion score 0.0728744939271255 - nodes in this community are weakly interconnected._
- **Should `Core Concepts & Config Model` be split into smaller, more focused modules?**
  _Cohesion score 0.08235294117647059 - nodes in this community are weakly interconnected._
- **Should `Platform Overview & Getting Started` be split into smaller, more focused modules?**
  _Cohesion score 0.0846774193548387 - nodes in this community are weakly interconnected._