import json
from graphify.detect import detect
from pathlib import Path

result = detect(Path('C:/Users/L073881/Desktop/Cortex_Documentation'))
Path('graphify-out/.graphify_detect.json').write_text(
    json.dumps(result, ensure_ascii=False), encoding='utf-8'
)
print('Detected:', result['total_files'], 'files,', result['total_words'], 'words')
for cat, files in result.get('files', {}).items():
    if files:
        print(' ', cat + ':', len(files), 'files')
