# Cortex Guard

**Page URL:** https://cortex.lilly.com/spe/documentation/concepts/security-authentication-configuration/cortex-guard/

---

## Overview

Cortex Guard is the security layer that scans inputs and outputs for policy violations, integrating LLM Guard and Guardrails AI for comprehensive content filtering.

**Evaluates:** Inputs (user prompts) AND Outputs (LLM responses)

---

## Processing Flow

1. User sends request → Input scanners evaluate
2. If blocking mode: violations prevent processing
3. LLM generates response → Output scanners evaluate
4. Response returned or blocked if violations found
5. All scans logged for audit

---

## Scanning Engines

### LLM Guard (ProtectAI)

| Scanner | Purpose |
|---------|---------|
| PromptInjection | Detect prompt injection attempts |
| Secrets | Detect secrets, API keys, passwords |
| BanSubstrings | Block specific words or phrases |
| BanTopics | Block content about specified topics |
| Toxicity | Detect toxic or harmful content |
| Sentiment | Filter by sentiment |
| BanCode | Prevent code generation |
| Language | Enforce specific languages |
| JSON | Validate JSON output format |

### Guardrails AI

| Validator | Type | Purpose |
|-----------|------|---------|
| detect_pii | Input | Detect emails, phone numbers, addresses |
| competitor_check | Output | Flag competitor mentions |
| regex_match | Input | Custom regex pattern matching |
| detect_jailbreak | Input | Detect jailbreak attempts |

---

## Blocking vs. Non-Blocking Mode

| Mode | `blocking` | Behavior |
|------|-----------|---------|
| Non-Blocking (Default) | `false` | Violations logged but requests proceed |
| Blocking | `true` | Violations prevent request processing |

---

## Configuration Structure

```json
{
  "name": "my-security-config",
  "guard": true,
  "blocking": false,
  "llm_guard": [{
    "input_scanners": {
      "PromptInjection": {"threshold": 0.5},
      "BanSubstrings": {"substrings": ["forbidden", "restricted"]},
      "Secrets": {}
    },
    "output_scanners": {
      "BanTopics": {"topics": ["competitors", "pricing"], "threshold": 0.7}
    }
  }],
  "guardrails_ai": [{
    "input_scanners": {
      "detect_pii": {"pii_types": ["email", "phone_number", "address"]}
    },
    "output_scanners": {
      "competitor_check": {"competitors": ["Competitor A"], "threshold": 0.5}
    }
  }]
}
```

---

## Hierarchical Security

- **Parent Level (InfoSec):** Mandatory policies applied to ALL configurations — cannot be bypassed
- **Child Level (User):** Optional additional policies per configuration

---

## Coverage Summary

| Threat | Scanners | Coverage |
|--------|---------|---------|
| Prompt Injection | PromptInjection, detect_jailbreak | Strong |
| PII/Secrets | Secrets, detect_pii | Strong |
| Malicious Code | BanCode | Strong |
| Toxicity | Toxicity, Sentiment | Good |
| Custom Patterns | regex_match | Strong |

---

## Best Practices

- Start with non-blocking mode to understand violation patterns
- Use LLM Guard for broad coverage, Guardrails AI for specialized needs
- Set appropriate thresholds based on acceptable false-positive rates
- Review logs regularly to tune scanner configurations
- Test security configs thoroughly before enabling blocking mode
