# Support and SLAs

**Page URL:** https://cortex.lilly.com/spe/documentation/cortexsupport/

---

## Overview

Support for Cortex platform and SPE Gen AI Products (including Chat In A Box). Target availability: **>99% across all environments**.

---

## Service Level Agreement (SLA)

### P1 - Business Critical (Production Only)
- **Response Time:** 15 minutes
- **Resolution Time:** 2 hours

### P2 - High
- **Response Time:** 30 minutes
- **Resolution Time:** 4 hours

### P3 - Medium
- **Response Time:** 8 hours
- **Resolution Time:** 3 Business days

---

## Incident Priority Classification

| Priority | Description | Business Impact | Examples |
|----------|-------------|----------------|---------|
| P1 | Business Critical | Significant business disruption | Entire platform outage, multiple user inaccessibility |
| P2 | High | Major functionality affected but workaround available | Core services disrupted but platform remains usable |
| P3 | Medium | Non-critical functionality issues | Minor bugs, individual user issues, AWS/Azure account additions |

> Issues in non-production environments (Dev and QA) are treated as P2 and below.

---

## Get Help

- **Cortex Support:** Submit via ServiceNow
- **Chat In A Box Support:** Separate support channel
- **System Status:** View Cortex Status page for known issues or maintenance

---

## Links

- Cortex Support (ServiceNow): https://cortex.lilly.com/spe/support/
- System Status: https://cortex.lilly.com/spe/status/
