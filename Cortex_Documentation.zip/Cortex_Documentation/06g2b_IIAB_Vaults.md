# IIAB - Vaults

**Page URL:** https://cortex.lilly.com/spe/documentation/ai-products/insights-in-a-box/user-guide/vaults/

---

## Overview

A Vault is the secure workspace where you store/upload documents, create Projects for analysis, and manage Vault-level access.

> **Retention policy:** Inactive vaults are automatically deleted after 90 days with no activity.

---

## Vault Common Actions

- **Open Vault:** Enter the vault workspace
- **Add Vault:** Create a new vault (you become Vault Owner)
- **Edit Vault:** Update vault details, add/edit Tags and Metadata
  - **Tags:** Short labels (e.g., "MSA", "Supplier", "2026")
  - **Metadata:** Key/value fields (e.g., Region = NA, Business Unit = IT)
- **Delete Vault:** Remove a vault (Owners only)
- **Favorite:** Mark for quicker discovery
- **View Cost & Usage:** Owners only
- **Share Vault link:** Copy direct link
- **Manage Vault access:** Control who can view/edit

---

## Vault-Level Document Upload Types

### Upload from Computer
- Files from local device
- Supported: .docx, .pdf | Max: 15 MB per file

### Upload from SharePoint (One-time)
- Import documents from a SharePoint folder as a one-time upload
- Paste SharePoint folder link — all supported files (including subfolders) imported
- Documents managed manually after import — won't auto-update if source changes

### Sync a SharePoint Site (Ongoing)
- Connect SharePoint folder for automatic ongoing document syncing
- Can add multiple SharePoint sites to a single Vault
- **Re-Sync:** Pull in new, updated, or missing files at any time
- **Remove Site:** Disconnect when no longer needed
- Choose this over "Upload from SharePoint" when you want documents to stay current with the source
