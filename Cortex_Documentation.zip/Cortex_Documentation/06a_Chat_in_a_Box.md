# Chat in a Box (CIAB)

**Page URL:** https://cortex.lilly.com/spe/documentation/ai-products/chatinabox/

**Access:** https://chat.lilly.com/cortex/dashboard

---

## Overview

Chat in a Box (CIAB) enables you to craft customized AI chat assistants effortlessly. Simply name your assistant, invite users, and upload files.

Follow the Chat In A Box Viva Engage page for latest updates including software release notes.

---

## Advanced Usage — Labels

Labels are added to the `labels` object of the Cortex Model Config to modify the chat page experience.

| Label Key | Value | Description |
|-----------|-------|-------------|
| custom_error_message | String | Override default error message when /ask returns an error |
| custom_wait_message | String | Custom waiting message shown while waiting for LLM response |
| agent_debug | True | Adds debug logging for agent-chain models |
| background_job | True | Switches to SSE for agent-chain models that execute >2 minutes |
| chatbuilder (key) | read only | Limit a model to be uneditable in Chat in a Box |

---

## Updating Unsupported Assistant Types

To update your model-config using Chat in a Box, ensure the Chat in a Box AWS Role is an Owner:

```json
"owners_aws_roles": [
  "arn:aws:iam::283234040926:role/lrl-light-apps-chatbuilder-prd-ciab"
]
```

| Environment | AWS Role ARN |
|-------------|-------------|
| Develop | arn:aws:iam::283234040926:role/lrl-light-apps-chatbuilder-dev-ciab-dev |
| Eval | arn:aws:iam::283234040926:role/lrl-light-apps-chatbuilder-qa-ciab-dev |
| Prod | arn:aws:iam::283234040926:role/lrl-light-apps-chatbuilder-prd-ciab |

---

## RAG Assistants

When creating a RAG assistant via Cortex for management in Chat in a Box, the **Data Config name must exactly match the Model Config name**.
