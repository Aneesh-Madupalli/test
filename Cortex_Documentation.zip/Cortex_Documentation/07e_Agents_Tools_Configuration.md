# Agents & Tools Configuration

**Page URL:** https://cortex.lilly.com/spe/documentation/concepts/agents-tools-configuration/

---

## Agent Concepts

An agent is a Cortex configuration that enables an LLM to:
- Decide which actions to take based on user input
- Invoke tools to gather information or perform actions
- Iterate through multiple steps to complete a task
- Return a final response to the user

---

## Chain Types

| Chain Type | Description | Use Case |
|-----------|-------------|---------|
| model-only-chain | Direct LLM access | Simple Q&A, no data or tools |
| doc-chain | RAG with similarity search | Document Q&A |
| hybrid-doc-chain | RAG with hybrid search | Document Q&A with keyword matching |
| tool-chain | Single agent with tools | Tool-augmented workflows |
| agent-chain | Multi-agent framework | Complex hierarchical workflows |

---

## Tool Configuration

### Toolkit Structure

```json
{
  "name": "my-toolkit",
  "server": "my-toolkit.namespace.svc.cluster.local:5000",
  "auth": {"owners": ["user@lilly.com"], "private": false},
  "allowed_model_configs": ["my-agent-config"]
}
```

### Tool Definition Fields
- `name` – Identifier used by the LLM
- `description` – Helps LLM decide when to use the tool
- `json_input_schema` – Defines expected input parameters
- `direct_return` – Whether to immediately return results to user

---

## Single Agent Configuration (tool-chain)

```json
{
  "name": "my-agent",
  "chain": [{"chain_class": "tool-chain", "model_iteration": 1, "order": 1}],
  "model_versions": [{"model_class": "lilly-openai", "model_iteration": 7}],
  "toolkits": ["my-toolkit"]
}
```

---

## Multi-Agent Configuration (agent-chain)

```json
{
  "chain_class": "agent-chain",
  "chain_params": {
    "max_turns": 50,
    "supervisor": {
      "prompt": "You are a supervisor agent...",
      "description": "Coordinates between specialized agents"
    },
    "resources": {
      "executables": [
        {"name": "database-agent", "type": "agentic-model", "description": "Handles database queries"},
        {"name": "search_tool", "type": "tool-call", "description": "Searches the web"}
      ]
    }
  }
}
```

### Executable Types

| Type | Description |
|------|-------------|
| tool-call | Invoke a tool from a toolkit |
| agentic-model | Invoke another Cortex agent config |
| model | Invoke a non-agentic model config |

---

## Key Parameters

| Parameter | Description |
|-----------|-------------|
| agent_tool_max_iterations | Maximum tool calls per request |
| max_turns | Maximum conversation turns in agent-chain |
| allowed_tools_list | Restrict which tools from a toolkit are available |
| toolkits | List of toolkit names to enable |
