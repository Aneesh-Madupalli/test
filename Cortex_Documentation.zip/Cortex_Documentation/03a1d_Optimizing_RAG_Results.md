# Optimizing Your RAG Results

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/building-your-agent/add-data/optimizing-rag-results/

---

## Overview

This guide covers configurations for improving the quality and relevance of your RAG (Retrieval-Augmented Generation) results.

---

## Chunking Configuration

Chunking divides documents into smaller pieces for retrieval.

| Parameter | Description | Default |
|-----------|-------------|---------|
| chunk_size | Number of tokens per chunk | 1500 |
| chunk_overlap | Overlapping tokens between chunks | 300 |

### Contextual Chunking

For structured documents, preserves logical structure by dividing based on headings/sections:

```json
{
  "contextual_chunking": {
    "is_enable": true,
    "separator": ["\n\n", "\n", ".", " "],
    "chunk_size": 1500,
    "chunk_overlap": 300,
    "depth": 3
  }
}
```

- `depth`: Controls chunk granularity (1 = major sections, higher = more granular)

---

## Retrieval Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| k_value | Number of chunks to retrieve | 20 |
| doc_relevence_threshold | Minimum similarity score | 0.5 |

---

## Chain Types for RAG

| Chain Type | Description |
|------------|-------------|
| doc-chain | Document retrieval using similarity search |
| hybrid-doc-chain | Combines keyword and semantic search |
| model-enhanced-query-chain | Enhances user queries before retrieval |

---

## Hybrid Search Configuration

```json
{
  "hybrid_search": {
    "rrf_relevance_threshold": 0.012,
    "rrf_constant": 60,
    "hybrid_score_type": "average",
    "lexical_average_weight": 50
  }
}
```

---

## Vector Store Options

| Store | Notes |
|-------|-------|
| Pinecone | Recommended for most use cases |
| Elasticsearch | Legacy support |

---

## Embedding Models

- text-embedding-3-small
- text-embedding-3-large
- text-embedding-ada-002

---

## Best Practices

- **Match chunk size to use case:** Smaller chunks for Q&A, larger for summarization
- **Use contextual chunking for structured documents:** Preserves logical sections
- **Use hybrid search when exact terms matter:** Good for specific terminology
- **Adjust k_value based on needs:** Higher values retrieve more context but may include less relevant chunks
