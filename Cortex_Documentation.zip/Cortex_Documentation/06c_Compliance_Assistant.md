# Compliance Assistant (E&C) — Ethics & Compliance Chat

**Page URL:** https://cortex.lilly.com/spe/documentation/ai-products/compliance-assistant/

**Access:** Ethics & Compliance Chat (internal link)

**Powered by:** GPT-4.1

> Responses are AI-generated and may contain errors. Always verify accuracy and consult official company policies and procedures before taking any action.

---

## Overview

Get help with Ethics and Compliance policy and procedure questions.

---

## How It Works

1. **User Query** — Your question is received
2. **Translation** — The chatbot identifies the language of your query
3. **Location** — Your location is identified from the query or retrieved from WorkDay
4. **Document Retrieval** — Searches location-specific and global documents for relevant information
5. **Response** — A tailored answer is generated based on all gathered context

---

## Tips for Getting the Best Answers

### Be Specific in Your Questions
Include phrases like "detailed response" or "detailed information" for more comprehensive explanations.

**Examples:**
- "What is the sponsorship criteria? Give me a detailed response."
- "Explain the onboarding process with detailed information."

### Include All Context in One Message
The chatbot **does not retain conversation history** — each message is treated independently. Include all necessary context in a single query.

---

## How Responses Are Generated

### Language

| Scenario | Result |
|----------|--------|
| Query in Spanish about Spain | Response in Spanish (if Spanish documents exist) |
| Query in Spanish about United States | Response in English (English documents only) |

### Location

| Scenario | Result |
|----------|--------|
| "How do I seek a conflict of interest?" (user in US) | Response tailored to US policies |
| "How do I seek a conflict of interest in Mexico?" | Response tailored to Mexico policies |

### Local vs. Global Policies

The chatbot searches both local and global documents, with local procedures taking precedence. Global policies are included when they provide relevant, non-redundant information.
