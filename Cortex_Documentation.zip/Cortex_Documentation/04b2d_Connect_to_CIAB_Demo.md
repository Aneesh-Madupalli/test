# Connect to CIAB (Feature Demo)

**Page URL:** https://cortex.lilly.com/spe/documentation/use-cases-and-demos/training-and-demos/feature-demos/connect-to-ciab/

---

This page contains a video demonstration of how to connect a Cortex Configuration to Chat in a Box (CIAB).

*(Video content — visit the page directly to view the embedded demonstration.)*
