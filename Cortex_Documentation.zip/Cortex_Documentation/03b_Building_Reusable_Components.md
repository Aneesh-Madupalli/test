# Building Reusable Components

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/building-reusable-components/

---

## Overview

Cortex allows you to create reusable configurations and integrations that can be shared across multiple agents.

---

## Reusable Configurations

- **Prompt Configs:** System prompts referenced by multiple agents
- **Toolkit Configs:** Tool servers providing shared capabilities
- **Data Configs:** Data sources that can be shared across agents

All configurations use the standard Cortex permissions model (owners, users, access groups, private/public visibility).

---

## Integration Protocols

- **MCP (Model Context Protocol):** Enables agents to access external tools and services through a standardized interface
- **A2A (Agent-to-Agent):** Enables secure communication and collaboration between autonomous agents

---

## Sub-pages

- [MCP (External) Toolkit Integration](/spe/documentation/guides/building-reusable-components/mcp-integration/)
- [A2A Protocol](/spe/documentation/guides/building-reusable-components/a2a-protocol/)
