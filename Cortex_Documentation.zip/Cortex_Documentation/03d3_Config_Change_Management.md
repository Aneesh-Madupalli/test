# Config Change Management

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/preparing-for-release/config-change-management/

---

## Overview

Cortex supports a managed configuration system using **GitHub as the source of truth** for agent configurations, enabling version control, auditability, and controlled deployments.

Configuration management is done through the `managed-configs` repository.

---

## Why Use Managed Configurations

- **Prevent accidental breakage** — All changes go through PR review before being applied
- **Quick rollback** — Revert to previous configurations by reverting the PR
- **Audit and traceability** — Track who changed what and when via Git history

---

## Configuration Types

| Type | Create | Update |
|------|--------|--------|
| Model | Yes | Yes |
| Data | Yes | Yes |
| Prompt | Yes | Yes |
| Security | Yes | Yes |
| Toolkit | No | Yes |

---

## Repository Structure

```
config-repo/
├── prd/
│   ├── team-name/
│   │   ├── model/
│   │   │   └── my-agent.json
│   │   ├── data/
│   │   ├── prompt/
│   │   ├── security/
│   │   └── toolkit/
├── dev/
├── scripts/
├── CODEOWNERS
└── README.md
```

---

## Configuration Update Flow

1. **Create a Pull Request** — Create/update a config JSON file in your team's folder
2. **PR Review and Approval** — Must be reviewed by designated team owners (enforced via CODEOWNERS)
3. **Merge** — System detects changed files, sends API requests only for changed configs
4. **Propagation to Cortex** — Changed configs automatically sent to Cortex via POST/PUT

> Model configurations are processed **last** since other types (data, prompt, security, toolkit) are dependencies.

---

## Rollback Steps

1. Identify the bad configuration
2. Revert the PR in GitHub (use GitHub's revert feature)
3. Merge the revert PR (once approved)
4. Verify rollback is restored and issue resolved

---

## Limitations

- **Configuration deletion** — Not managed through this system
- **No retry logic** — If an API request fails, no automatic retry
- **Toolkit limitations** — Toolkit configs can only be updated, not created
- **Environment scope** — Primarily manages `prd/` configs; `dev/` is for testing the flow
- **Unique naming** — Config name must be unique across the platform for that type
