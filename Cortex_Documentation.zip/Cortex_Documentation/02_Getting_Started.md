# Getting Started

**Page URL:** https://cortex.lilly.com/spe/documentation/getting-started/  
**Last Modified:** Jun 5, 2026

---

## Overview

This section walks through what Cortex is, how to get access, and a set of guided QuickStarts to help you build and integrate your first Cortex configs.

---

## Get Connected

Cortex Platform serves thousands of developer-users, and we stay connected through a few core ways:

- **Cortex Access** – [Self service portal](https://dev.lilly.com/docs/platforms-and-tools/cortex/#onboarding-and-offboarding) Gets you access to shared resources, documentation, video content, inclusion in email communications, and the platform itself. A must!
- **Viva Engage** – [Cortex Page](https://engage.cloud.microsoft/main/org/lilly.com/groups/eyJfdHlwZSI6Ikdyb3VwIiwiaWQiOiIxODY0NTE5NjgwMDAifQ) This is the primary channel for announcements and user communication, including operations notifications.
- **Lilly Flow (Stack Overflow for Lilly)** – [Cortex tag](https://elilillyco.stackenterprise.co/posts/tagged/285) A living knowledge bank of questions and answers, sourced by developer-users and Cortex team. All Office Hour questions must first be asked on Lilly Flow.
- **Office Hours** – US hours Fridays at 10am ET. Instructions to join Office Hours [are captured here](https://engage.cloud.microsoft/main/org/lilly.com/threads/eyJfdHlwZSI6IlRocmVhZCIsImlkIjoiMzY4NDc0MzQ5NDk4MzY4MCJ9?trk_copy_link=V2) and are likely to evolve.
- **Support** – All Issues or Feature Requests are submitted through the [Cortex Support Page (Service Now)](https://cortex.lilly.com/spe/support/) to our world-class support team.

---

## Cortex Roadmap High-Level

[2026 - single slide](https://collab.lilly.com/:b:/r/sites/CortexAccessUsers/Shared%20Documents/Cortex%20Access%20Users/Supplemental/Cortex_roadmap_highlevel_2026_0417.pdf?csf=1&web=1&e=Qv3Msb) (Requires Cortex Access) Frequent updates may be shared via [Viva Engage](https://engage.cloud.microsoft/main/org/lilly.com/groups/eyJfdHlwZSI6Ikdyb3VwIiwiaWQiOiIxODY0NTE5NjgwMDAifQ)

---

## Mandates

- **[MCP Mandate](https://collab.lilly.com/:b:/r/sites/CortexAccessUsers/Shared%20Documents/Cortex%20Access%20Users/Mandates/Lilly_MCP_Mandate.pdf?csf=1&web=1&e=6KW9H6)** - effective February 15, 2026: All software at Lilly—vendor-supplied or internally developed—must provide a Model Context Protocol (MCP) server where AI interaction is applicable.

---

## Learn About Cortex

Overview of the platform, its capabilities, and key features.

👉 [What is Cortex?](/spe/documentation/getting-started/what-is-cortex/)

---

## Get Access For Your Application

Request approvals, set up credentials, and review environment requirements.

👉 [Prerequisites](/spe/documentation/getting-started/prerequisites-access/)

---

## Build Your First Config

Step-by-step guides for creating RAG configs, integrating APIs, and using the Landing Zone UI.

👉 [QuickStart](/spe/documentation/getting-started/quickstart/)

---

## Sub-pages

- [What is Cortex?](/spe/documentation/getting-started/what-is-cortex/)
- [Prerequisites](/spe/documentation/getting-started/prerequisites-access/)
- [QuickStart](/spe/documentation/getting-started/quickstart/)
