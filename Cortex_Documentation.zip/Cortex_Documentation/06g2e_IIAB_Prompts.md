# IIAB - Prompts

**Page URL:** https://cortex.lilly.com/spe/documentation/ai-products/insights-in-a-box/user-guide/prompts/

---

## Overview

Prompts within project columns define how insights are extracted during analysis.

**Who can do it:** Project Owner / Project Editor

---

## Concepts

- **Column Prompts:** Prompts created/configured directly within a project column
- **Prompt Templates:** Reusable prompts available in the Prompts tab
  - **My Prompts:** Templates you create and manage (personal library)
  - **Public Prompts:** Shared templates available across the organization

---

## Within a Project Column

### Add a prompt to a column
1. Open the Project → Add or edit a column
2. In the prompt section: write a new prompt OR search and select an existing template
3. Save the column

### Save prompt as template
1. Find the column → click column header menu → **Save Prompt**
2. Confirm all prompt template fields → Save
3. Automatically saved in **My Prompts**; publish from the Prompts tab

### Edit/Delete a prompt in a column
- Edit column → update prompt content or switch templates
- Delete the column or remove/replace the prompt within column configuration

---

## Within Prompts Tab

### Add a prompt template
1. Sidebar → Prompts → My Prompts
2. Click **Add Prompt Template** → enter content → save

### Edit a template
- My Prompts → menu → **Edit prompt** → update → save
- Note: Templates in **Public Prompts** tab are not editable

### Delete a template
- Find prompt → menu → **Delete Prompt** → confirm

### Publish a template
- My Prompts → menu → **Make Prompt Public** → confirm
