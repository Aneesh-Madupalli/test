# Add Data

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/building-your-agent/add-data/

---

## Overview

Adding data to your Cortex Configuration gives your agent access to your organization's documents and information, enabling it to provide accurate, contextual responses grounded in your specific content.

---

## Available Data Sources

Cortex supports multiple data source types:

- **Direct Upload:** Upload PDF, DOCX, CSV, JSON, and other file types directly through the API
- **S3 Buckets:** Connect to data assets hosted in AWS S3
- **SharePoint:** Connect to Lilly SharePoint data with automatic synchronization
- **Index Factory:** Connect to data assets hosted in EDB

---

## Sub-pages

- [Use the Data Marketplace](/spe/documentation/guides/building-your-agent/add-data/use-data-marketplace/)
- [Create Data Connections for RAG](/spe/documentation/guides/building-your-agent/add-data/create-data-connections-rag/)
- [Load Data in Context](/spe/documentation/guides/building-your-agent/add-data/load-data-in-context/)
- [Optimizing Your RAG Results](/spe/documentation/guides/building-your-agent/add-data/optimizing-rag-results/)
- [Text-to-SQL](/spe/documentation/guides/building-your-agent/add-data/text-to-sql/)
