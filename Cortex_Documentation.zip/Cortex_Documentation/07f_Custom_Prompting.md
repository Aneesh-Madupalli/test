# Custom Prompting

**Page URL:** https://cortex.lilly.com/spe/documentation/concepts/prompt-configuration/custom-prompting/

---

## Creating a Custom Prompt

```bash
curl -X POST https://cortex.lilly.com/prompt \
  -H "Content-Type: application/json" \
  -d '{
    "name": "custom-assistant-prompt",
    "display_name": "Custom Assistant",
    "prompt_type": "with_context",
    "allowed_model_configs": ["my-agent"],
    "auth": {"owners": ["your-email@lilly.com"], "private": true},
    "prompt": {
      "input_variables": ["chat_history", "context", "question"],
      "template": "Your custom template here...",
      "template_format": "f-string"
    }
  }'
```

---

## Prompt Engineering Techniques

### Role Definition
```
You are a pharmaceutical regulatory affairs specialist.
Respond in a professional, precise manner.
Focus on FDA and EMA guidelines when applicable.
```

### Context Handling
```
Use ONLY the information provided in the context below.
If the context doesn't contain the answer, say "I don't have information about that."
Do not make up facts or reference information outside the provided context.

Context:
{context}
```

### Output Formatting
```
Format your response as follows:
1. Brief summary (2-3 sentences)
2. Key points (bullet list)
3. Recommendations if applicable
4. Sources cited
```

### Citation Instructions
```
Cite your claims using the chunk IDs provided in the context.
Use inline citations like (chunk-id-123).
Do not generate a separate reference section.
```

### Handling Uncertainty
```
If you cannot answer the question with the provided context:
1. Acknowledge what you don't know
2. Suggest what information would help
3. Never fabricate information
```

---

## Prompt Templates for Common Scenarios

### Document Q&A
```
You are a document research assistant.
Answer questions based strictly on the provided context.
Always cite your sources.

Context: {context}
Previous conversation: {chat_history}
Question: {question}
Answer:
```

### Agent with Tools
```
You are an AI assistant with access to tools.
Analyze the user's request and decide which tool to use.
Think step-by-step before taking action.

Available tools: {tool_strings}
Question: {question}
```

---

## Binding Prompts to Agents

```json
{
  "name": "my-agent",
  "prompts": {
    "no_context": "default_no_context",
    "with_context": "custom-assistant-prompt",
    "enhance_query": "default_enhance_query"
  }
}
```

---

## Common Pitfalls

- **Overly long prompts** – Keep focused; excessive instructions can confuse the model
- **Conflicting instructions** – Ensure all instructions are consistent
- **Missing edge cases** – Include guidance for when context is insufficient
- **No output format** – Without formatting instructions, responses may be inconsistent
