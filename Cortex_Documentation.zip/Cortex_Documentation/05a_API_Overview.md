# API Overview

**Page URL:** https://cortex.lilly.com/spe/documentation/api-and-sdks/api/overview/

---

## Base URLs

| Environment | URL |
|-------------|-----|
| Production | https://cortex.lilly.com |
| Dev | https://dev.cortex.lilly.com |
| QA | https://qa.cortex.lilly.com |

---

## Authentication

### Delegated Auth (User-facing applications)
Pass user identity in headers:
```
x-user: user@lilly.com
x-groups: your-group
x-org: {"name": "your-org"}
```

### AWS Auth
For backend services — use IAM roles attached to AWS resources (EC2, ECS, Lambda).

### APIM Auth
For programmatic access via Azure API Management — use Entra ID access tokens with scope `api://Cortex.lilly.com/.default`

### APIM Gateway URLs

| Environment | URL |
|-------------|-----|
| Production | https://gateway.apim.lilly.com/cortex |
| QA | https://gateway.apim-qa.lilly.com/cortex |
| Dev | https://gateway.apim-dev.lilly.com/cortex |

---

## Response Format

- Standard responses: JSON
- Streaming responses (chat): Server-Sent Events (SSE)

---

## Error Codes

| Code | Meaning |
|------|---------|
| 200 | Success |
| 400 | Bad request |
| 401 | Unauthorized |
| 404 | Not found |
| 500 | Server error |
