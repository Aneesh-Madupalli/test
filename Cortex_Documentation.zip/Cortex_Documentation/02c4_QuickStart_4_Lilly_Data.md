# QuickStart 4: Connect Cortex to Lilly Data

**Page URL:** https://cortex.lilly.com/spe/documentation/getting-started/quickstart/qs4-lilly-data/

---

## Overview

This QuickStart walks you through connecting a Cortex configuration to enterprise data so your agent can answer questions using your documents through RAG.

---

## Prerequisites

- Access to the Cortex API (dev, qa, eval, or prod)
- Documents available in an approved enterprise location (S3, EDB export, or SND)
- Data owner approval for the documents
- An existing model configuration (LLM) in Cortex
- Permissions to read from the data source

---

## What You Will Build

- A Data Configuration that defines how documents are processed
- Documents ingested, chunked, and embedded
- Vectors stored in a supported vector store
- An agent configuration connected to this data for RAG-based answers

---

## Step 1: Create a Data Configuration

A Data Configuration defines:
- Where documents live
- How they are chunked and embedded
- Where vectors are stored
- Which agents are allowed to access the data

### Required Fields

| Field | Description |
|-------|-------------|
| name | Unique identifier (lowercase, alphanumeric, dashes) |
| s3_bucket | S3 bucket containing documents |
| s3_prefix | Prefix path (no leading/trailing slashes) |
| embedding | Embedding model reference |
| model_version | LLM configuration reference |
| vectorstore | elasticsearch, pinecone, or snd |
| auth | Ownership and access control |

### Common Optional Fields

| Field | Purpose |
|-------|---------|
| chunk_size | Max tokens per chunk (default: 1500) |
| chunk_overlap | Token overlap between chunks (default: 300) |
| contextual_chunking | Structure-aware chunking |
| multimodal | Enable image/table extraction |
| bounding_boxes | Enable PDF citation support |
| allowed_model_configs | Agents allowed to use this data |

### Example: Create a Data Configuration

```json
{
  "name": "product-docs",
  "displayName": "Product Documentation",
  "s3_bucket": "lly-light-dev",
  "s3_prefix": "llm-dev/product-docs",
  "embedding": {
    "model": "text-embedding-3-large",
    "open_api_type": "azure"
  },
  "model_version": {
    "model_class": "lilly-openai",
    "model_iteration": 3
  },
  "vectorstore": "elasticsearch",
  "chunk_size": 1500,
  "chunk_overlap": 300,
  "auth": {
    "owners": ["your-email@lilly.com"],
    "private": true
  }
}
```

`POST /data`

---

## Step 2: Ingest Your Documents

### What Happens During Ingestion
1. Documents are read from the source
2. Content is parsed and chunked
3. Embeddings are generated via LiteLLM
4. Vectors and metadata are stored
5. The data becomes searchable by agents

### Ingestion Options

| Method | Endpoint |
|--------|----------|
| Index existing files in S3 | `POST /data/index/{data_config_name}` |
| Upload and index new files | `POST /data/upload/{data_config_name}` |
| Generate presigned URL for direct upload | `POST /data/async_upload/{data_config_name}` |

### Monitor Ingestion

```
GET /data/job-status/{data_config_name}
GET /data/job-status-id/{data_config_name}/{job_id}
```

---

## Step 3: Connect Data to Your Agent

```json
{
  "name": "product-agent",
  "data": ["product-docs"],
  "chain": [{"chain_class": "hybrid-doc-chain", "order": 1}],
  "model_versions": [{"model_class": "lilly-openai", "model_iteration": 3, "priority": 100}],
  "k_value": 20,
  "doc_relevence_threshold": 0.5,
  "auth": {"owners": ["your-email@lilly.com"], "private": true}
}
```

---

## Recommended Defaults

### Embeddings
- `text-embedding-3-large` – best accuracy
- `text-embedding-3-small` – faster and lower cost

### Vector Store
- **Elasticsearch** (default and recommended)
- **Pinecone** – only if reranking is required
- **SND** – for secure enterprise vault scenarios

### RAG Chain
- `hybrid-doc-chain` (recommended for most use cases)

### Chunking Options

**Default:**
```json
{"chunk_size": 1500, "chunk_overlap": 300}
```

**Contextual Chunking (for structured docs):**
```json
{"contextual_chunking": {"is_enable": true, "depth": 3, "chunk_size": 1500, "chunk_overlap": 300}}
```

---

## Security and Access Control

```json
{
  "auth": {
    "owners": ["data-owner@lilly.com"],
    "access_groups": ["analysts"],
    "private": true
  },
  "allowed_model_configs": ["approved-agent"]
}
```

- Owners can manage the configuration
- Access groups control read access
- Only approved agents can retrieve data

---

## Supported File Types

PDF, DOCX, TXT, Markdown, CSV, JSON, NDJSON, NXML, PPTX, XLSX, MP3, MP4, WAV

---

## Common Issues

| Issue | Solution |
|-------|----------|
| Documents not ingesting | Verify S3 permissions, check file types, check job status |
| Agent not retrieving data | Data config not linked, agent not in allowed_model_configs, k_value too low |

---

## Additional Resources

- Cortex API Docs: https://api.cortex.lilly.com/docs
- Cortex Landing Zone UI: https://cortex.lilly.com/spe/landing-zone
