# Realtime Voice Setup and Integration

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/building-your-agent/realtime-voice-setup-and-integration/

---

## Overview

Enable voice-based interactions for your Cortex agent using the Realtime API. This feature wraps your existing text-based agent with voice capabilities, maintaining full consistency with your configured prompts, tools, data sources, and security settings.

---

## Key Features

- **Voice-First Interface:** Real-time audio streaming with automatic speech detection
- **Zero Configuration:** Uses your existing agent setup (prompts, tools, RAG data)
- **Multi-Agent Support:** Works with simple Q&A and complex multi-step workflows
- **Cross-Session Memory:** Conversation history persists across sessions
- **Live Transcript:** Each turn streamed as `history_added` event
- **Live Execution Events:** Agent, tool, and step progress emitted in real time

---

## Architecture

```
Browser (Voice Chat UI) 
    ↓ ws://your-backend/api/realtime
Your Backend (Next.js OR Python FastAPI)
    - Validates origin + rate limits
    - Acquires Bearer token via MSAL (Azure AD)
    - Injects Authorization header
    - Relays messages bidirectionally
    ↓ wss://gateway.apim-{env}.lilly.com/...
Azure APIM Gateway
    ↓
Cortex Realtime Service
    - GPT Realtime model
    - Your agent prompts, tools, RAG data
```

> The APIM Bearer token must never be sent to or stored in a browser.

---

## Prerequisites

- Existing Cortex Agent with prompts, tools, or data sources
- Azure AD App Registration (Client ID + secret)
- APIM Environment (dev, qa, or prod)
- CATS WebSocket support (if deploying to CATS)

---

## Consistency with Text-Based Agents

| What's Shared | Details |
|---------------|---------|
| Prompts | Same system prompts and instructions |
| Tools | All configured tools available |
| Data Sources | RAG works identically |
| Security | Same auth, authorization, content filtering |
| Memory | Conversation history shared (switch between text/voice) |
| Routing | Same workflow and execution settings |
| User Context | Identity, groups, and permissions preserved |

---

## API Reference

### WebSocket Endpoint

```
WSS wss://gateway.apim-{env}.lilly.com/cortex/model/realtime/ws
    ?session_id={session_id}
    &cortex_model_name={model_name}
```

| Environment | Gateway URL |
|-------------|-------------|
| dev | wss://gateway.apim-dev.lilly.com/cortex/model/realtime/ws |
| qa | wss://gateway.apim-qa.lilly.com/cortex/model/realtime/ws |
| prod | wss://gateway.apim.lilly.com/cortex/model/realtime/ws |

### Client → Server Messages

| Type | Description |
|------|-------------|
| audio | PCM16 audio samples at 24 kHz mono |
| commit_audio | Force end-of-speech |
| interrupt | Stop agent's current response |
| truncate | Truncate audio at specific playback point |

### Server → Client Messages

| Type | Description |
|------|-------------|
| audio | Agent audio response (base64 PCM16, 24 kHz mono) |
| audio_interrupted | User started speaking — discard playback queue |
| history_added | Single new conversation item |
| history_updated | Full conversation history (on session resume) |
| agent_start/end | Agent processing started/finished |
| tool_start/end | Tool execution started/completed |
| handoff | Agent handoff between orchestrators |
| step | Agent-chain step update |
| error | Error from Cortex |

---

## Audio Configuration

| Setting | Value |
|---------|-------|
| Format | PCM16 (16-bit signed integer, little-endian) |
| Sample rate | 24 kHz |
| Channels | Mono (1) |
| VAD | Server-side (prefix padding: 300ms, silence: 500ms) |

---

## Realtime Config (Model-Level)

```json
{
  "name": "your-model-name",
  "realtime_config": {
    "voice": "marin",
    "transcription_model": "gpt-4o-transcribe",
    "realtime_model": "gpt-realtime",
    "transcription_language": "en"
  }
}
```

| Field | Default | Options |
|-------|---------|---------|
| voice | marin | alloy, ash, ballad, coral, echo, sage, shimmer, verse, marin, cedar |
| transcription_model | gpt-4o-transcribe | gpt-4o-transcribe, gpt-4o-mini-transcribe, gpt-4o-transcribe-diarize |
| realtime_model | gpt-realtime | gpt-realtime, gpt-realtime-1.5, gpt-realtime-mini |
| transcription_language | null | ISO 639-1 code: en, es, fr, de, ja, etc. |

---

## Reference Implementations

### Repository Links
- Main repo: `cortex-voice-integrations`
- Next.js: `cortex-voice-nextjs`
- Python: `cortex-voice-python`

### Option A: Next.js

```bash
git clone https://github.com/EliLillyCo/cortex-voice-integrations.git
cd cortex-voice-integrations/cortex-voice-nextjs
npm install
cp .env.local.example .env.local
# Configure AZURE_APP_CLIENT_ID, AZURE_APP_CLIENT_SECRET, APIM_ENV
npm run dev
```

### Option B: Python/FastAPI

```bash
git clone https://github.com/EliLillyCo/cortex-voice-integrations.git
cd cortex-voice-integrations/cortex-voice-python
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Configure credentials
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

---

## Error Codes

| Code | Message |
|------|---------|
| connection_error | Unable to establish connection |
| configuration_error | Service configuration error |
| forbidden | Origin not allowed |
| rate_limited | Too many connections |
| session_expired | Session has expired |
| audio_buffer_overflow | Reduce audio input rate |

---

## Best Practices

- Use MSAL for token management, never hard-code tokens
- Set `ALLOWED_ORIGINS` in production
- Always use 24 kHz mono PCM16
- Run behind HTTPS/WSS (required for getUserMedia)
- Generate a new UUID per conversation
- Close Cortex WebSocket when client disconnects
