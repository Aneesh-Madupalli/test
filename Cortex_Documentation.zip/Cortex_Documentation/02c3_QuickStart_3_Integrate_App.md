# QuickStart 3: Integrate Cortex with your App

**Page URL:** https://cortex.lilly.com/spe/documentation/getting-started/quickstart/qs3-integrate-app/

---

## Overview

This QuickStart shows how to call Cortex from an application using either the Cortex API or the Cortex SDK (Python).

You will:
- Choose or create a Cortex Config to call
- Call the /Ask endpoint directly
- Optionally use the Cortex SDK for chat completions, embeddings, or custom search

---

## Prerequisites

- A Cortex Config you are allowed to call (model-chain, tool-chain, or doc-chain configuration)
- Network and authentication access to Cortex from your environment

---

## Step 1: Understand the /Ask Endpoint

The /Ask endpoint is the primary chat interface for Cortex Configs.

Key characteristics:
- Accepts user queries and context and routes them to the configured config
- Supports in-context file upload for supported configs
- Automatically attaches chat history for the session

### Request Schema

#### Required Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| q | string | The question or query text (1 byte to 10MB) |

#### Optional Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| stream | boolean | false | Enable real-time streaming responses |
| model_session_id_param | string | - | Session ID for chat history |
| model_class | string | - | Specific model class |
| model_iteration | integer | - | Specific model version |
| uploaded_file | file | - | File for multimodal models |
| no_summary | boolean | false | Skip document summarization |
| filter_by_file | array | - | Limit RAG search to specific files |
| workflow_timeout | integer | 1800 | Timeout in seconds |
| background_job | boolean | false | Process in background |

#### Required Headers

| Header | Type | Description |
|--------|------|-------------|
| x-user | string | User identifier (email) |
| x-groups | string | Comma-separated list of user groups |
| x-org | string | Organization metadata as JSON |

### Response Schema (Non-Streaming)

```json
{
  "message": "The model's response text",
  "source_metadata": [...],
  "token_count": {
    "prompt_tokens": 150,
    "completion_tokens": 200,
    "total_tokens": 350
  },
  "steps": [...]
}
```

### Streaming Response

When `stream=true`, response is sent as JSON objects, one per line:
- `type: "step"` — Processing step status
- `type: "message"` — Response content fragments
- `type: "metadata"` — Additional information

---

## Step 2: Authenticate

### Delegated (End-User) Authentication

Required Headers:
```
x-user: testuser@lilly.com
x-groups: your-group
x-org: {"name": "your-org"}
```

### AWS-Based Service Authentication

For AWS environments, uses IAM roles and credentials for service-to-service authentication:
- AWS IAM roles attached to EC2, ECS, or Lambda
- AWS SSO credentials for local development

```bash
make login_aws
# Or
aws sso login --sso-session lilly --no-browser
```

---

## Step 3: Call /Ask from Your Application

### Basic Non-Streaming Request

```bash
curl -X POST "https://<cortex_base_url>/model/ask/my-model" \
  -H "Content-Type: multipart/form-data" \
  -H "x-user: testuser@lilly.com" \
  -H "x-groups: your-group" \
  -H "x-org: {\"name\": \"your-org\"}" \
  -F "q=What is Cortex?" \
  -F "stream=false"
```

### Streaming Request

```bash
curl -X POST "https://<cortex_base_url>/model/ask/my-model" \
  -F "q=Tell me about machine learning" \
  -F "stream=true"
```

### Chat History with Session ID

Use `model_session_id_param` to maintain conversation context:

```bash
curl -F "q=My name is Alice" -F "model_session_id_param=session-123" ...
curl -F "q=What is my name?" -F "model_session_id_param=session-123" ...
```

### Multimodal with File Upload

```bash
curl -F "q=What is in this image?" -F "uploaded_file=@/path/to/image.jpg" ...
```

### Debug Mode

```bash
curl -H "X-DEBUG: true" -F "q=Test query" -F "stream=true" ...
```

---

## Step 3 (Python): Full Client Example

```python
import requests
import json

class CortexClient:
    def __init__(self, base_url, user, groups, org):
        self.base_url = base_url.rstrip('/')
        self.session = requests.Session()
        self.session.headers.update({
            'x-user': user,
            'x-groups': groups,
            'x-org': json.dumps({"name": org})
        })

    def ask(self, model, query, stream=False, session_id=None, uploaded_file=None, debug=False):
        url = f"{self.base_url}/model/ask/{model}"
        data = {'q': query, 'stream': str(stream).lower()}
        if session_id:
            data['model_session_id_param'] = session_id
        
        files = None
        if uploaded_file:
            files = {'uploaded_file': open(uploaded_file, 'rb')}
        
        headers = {'X-DEBUG': 'true'} if debug else {}
        
        response = self.session.post(url, data=data, files=files, headers=headers, stream=stream)
        response.raise_for_status()
        
        if stream:
            for line in response.iter_lines():
                if line:
                    yield json.loads(line)
        else:
            return response.json()
```

---

## Step 4: Use the Cortex SDK (Python)

### Installation

```bash
pip install elilillyco-cortex-sdk
```

> The SDK is hosted in Lilly's Artifactory. Configure pip to use the Lilly-Python repository.

### Basic SDK Usage

```python
from elilillyco_cortex_sdk.configuration import Configuration
from elilillyco_cortex_sdk.api_client import ApiClient
from elilillyco_cortex_sdk.api.model_ask_api import ModelAskApi

config = Configuration(host="https://<cortex_base_url>")
client = ApiClient(config)
client.set_auth_headers({
    'x-user': 'testuser@lilly.com',
    'x-groups': 'engineering',
    'x-org': '{"name": "your-org"}'
})

ask_api = ModelAskApi(client)
response = ask_api.ask_handler_model_ask_model_post(
    model="my-model",
    q="What is machine learning?",
    stream=False
)
print(response.message)
```

### Managing Model Configurations

```python
from elilillyco_cortex_sdk.api.model_config_api import ModelConfigApi

config_api = ModelConfigApi(client)
models = config_api.listmodels_model_get()
```

### Working with Data Configurations

```python
from elilillyco_cortex_sdk.api.data_api import DataApi

data_api = DataApi(client)
data_configs = data_api.listdataconfig_data_get()
```

### Chat History

```python
from elilillyco_cortex_sdk.api.history_api import HistoryApi

history_api = HistoryApi(client)
history = history_api.gethistory_history_model_user_model_session_id_get(
    model="my-model",
    user_model_session_id="session-123"
)
```

---

## Error Handling

| Status Code | Meaning |
|-------------|---------|
| 404 | Model not found |
| 403 | Access denied |
| 500 | Internal server error |

---

## Next Steps

- Integrate HITL patterns for tool-based agents requiring approval
- Add logging, metrics, and evaluations
- Implement error handling and optimize with streaming and caching
- Review security: authentication, input validation, and data handling
