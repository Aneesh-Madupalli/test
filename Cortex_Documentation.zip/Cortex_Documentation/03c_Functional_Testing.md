# Functional Testing & Evaluations

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/functional-testing/

---

## Overview

The Cortex Evaluation Service provides structured testing capabilities to assess your GenAI application's response quality — RAG pipelines, answer faithfulness, and quality tracking over time.

Manage via [Landing Zone Evaluation UI](https://cortex.lilly.com/spe/landing-zone) or the Cortex Evaluation API.

Uses industry-standard metrics from **Ragas** and **DeepEval** frameworks.

---

## How It Works

1. **Create a Question Set** – Define test inputs with questions and (optionally) expected answers and context
2. **Run an Evaluation** – Execute questions against a Cortex Configuration and select metrics
3. **Analyze Results** – Review scores, identify issues, and compare runs over time

All evaluations run in synchronous mode.

---

## Available Metrics (16 total)

### Ragas Metrics

| Metric | What It Measures | Required Inputs |
|--------|-----------------|-----------------|
| Faithfulness | Answer grounded in context | Question, Answer, Context |
| Answer Relevancy | Relevance of answer to question | Question, Answer |
| Context Precision | Relevant context items ranked higher | Question, Answer, Context |
| Context Recall | Ground truth supported by context | Question, Context, Ground Truth |
| Answer Semantic Similarity | Semantic similarity to ground truth | Answer, Ground Truth |
| Answer Correctness | Factual accuracy vs ground truth | Question, Answer, Ground Truth |
| Context Entity Recall | Entity overlap between context and ground truth | Context, Ground Truth |
| Summarization Score | Content coverage vs conciseness | Answer, Context |
| Noise Sensitivity | Ignores irrelevant context | Question, Answer, Context, Ground Truth |
| Response Relevancy | Overall relevance of response | Question, Answer |

### DeepEval Metrics

| Metric | What It Measures | Required Inputs |
|--------|-----------------|-----------------|
| Contextual Precision | Ranking quality of relevant vs irrelevant context | Question, Answer, Context, Ground Truth |
| Contextual Recall | Coverage of ground truth by retrieved context | Question, Answer, Context, Ground Truth |
| Contextual Relevancy | Relevance of retrieved context | Question, Answer, Context |
| Answer Relevancy | Relevance of generated answer | Question, Answer, Context |
| Faithfulness | Claims supported by context | Question, Answer, Context |
| Hallucination | Unsupported or fabricated information | Question, Answer, Context |

---

## Choosing the Right Metrics

| Goal | Recommended Metrics |
|------|---------------------|
| RAG retrieval quality | Context Precision, Context Recall, Contextual Relevancy |
| Answer accuracy | Answer Correctness, Faithfulness, Answer Semantic Similarity |
| Hallucination detection | Hallucination, Faithfulness, Noise Sensitivity |
| Response quality | Answer Relevancy, Response Relevancy |
| Summarization tasks | Summarization Score |

---

## Best Practices

- **Be specific:** Vague questions produce inconsistent results
- **Include edge cases:** Test boundary conditions and unusual inputs
- **Use real queries:** Base test questions on actual user queries
- **Start small:** Begin with 10-20 high-quality questions, then expand
- **Establish baselines:** Run evaluations before making changes
- **Compare runs:** Track how scores change as you modify prompts or data

---

## Sub-pages

- [Run Evaluations](/spe/documentation/guides/functional-testing/run-evaluations/)
