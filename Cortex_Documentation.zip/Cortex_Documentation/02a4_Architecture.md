# Architecture

**Page URL:** https://cortex.lilly.com/spe/documentation/getting-started/what-is-cortex/architecture/  
**Last Modified:** Jun 5, 2026

---

## Overview

The diagram below shows the high-level Cortex architecture and component interactions.

*(Architecture Diagram - see original page for image)*

---

## CATS Ingress

Traffic enters through CATS Ingress, which terminates connections and forwards approved requests to Cortex Core.

---

## Cortex Core

The central orchestration layer that processes requests and coordinates with all downstream components.

---

## Customer-Owned Agents

**Agents (Customer-Owned)** are your Cortex Configs that define how requests are routed and processed. Each agent can leverage multiple platform capabilities.

---

## Vector Databases

- **Pinecone Namespaces** - Vector storage for embeddings

**On-demand Workers for Embeddings** process data from S3 into vector databases (RQ/RW operations).

---

## Microservices

- **Cortex-Guard** - Security logging and content filtering
- **Cortex-LLM** - LLM orchestration and request handling
- **Cortex-History** - Chat history management

---

## External LLMs

Access to multiple model providers:

- **Azure OpenAI**
- **AWS Bedrock**
- **OpenAI**
- **Google**
- **Hugging Face**

A list of all available models is available in [Landing Zone](https://cortex.lilly.com/spe/landing-zone/llms).

---

## Data Storage

- **S3** - Document and file storage
- **Redis** - Caching and coordination across the system
