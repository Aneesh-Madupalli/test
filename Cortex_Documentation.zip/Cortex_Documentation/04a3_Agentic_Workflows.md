# Agentic Workflows

**Page URL:** https://cortex.lilly.com/spe/documentation/use-cases-and-demos/end-to-end-walkthroughs/agentic-workflows/

---

## Overview

Agentic workflows enable multiple specialized agents to collaborate on complex problems using supervisor-based orchestration, tool-calling, and dynamic workflow routing.

**Use Case:** Drug Discovery Research Assistant — a hierarchical multi-agent system with 3 coordinated agents.

---

## Architecture Overview

```
Supervisor Agent (Orchestrates workflow, routes queries, synthesizes answers)
    ├── Database Agent (StructureResolver, ResultRetriever)
    └── Scientist Agent (CompoundProfile, SMILESCanonicalizer, ADMEProfile, SimilarityAnalysis)
```

| Agent | Description | Tools |
|-------|-------------|-------|
| Supervisor | Orchestrates research workflow | Database agent, Scientist agent, General RAG model |
| Database Agent | Data retrieval for chemical structures | StructureResolver, ResultRetriever |
| Scientist Agent | Computational chemistry analysis | CompoundProfile, SMILESCanonicalizer, ADMEProfile, SimilarityAnalysis |

---

## Step 1: Setup Data Configuration

```bash
curl -X POST "https://<cortex_base_url>/data" \
  -H "x-user: testuser@lilly.com" \
  -d '{
    "name": "general",
    "auth": {"owners": ["testuser@lilly.com"], "private": true},
    "displayName": "General Knowledge Base",
    "embedding": {"model": "text-embedding-ada-002", "open_api_type": "azure"},
    "model_version": {"model_class": "lilly-openai", "model_iteration": 3},
    "vectorstore": "elasticsearch",
    "allowed_model_configs": ["general", "supervisor", "scientist", "database"],
    "chunk_size": 1500,
    "chunk_overlap": 300
  }'
```

---

## Step 2: Create Toolkit Configuration

```bash
curl -X PUT "https://<cortex_base_url>/toolkits" \
  -d '{
    "name": "chemistry-toolkit",
    "server": "toolserver:5000",
    "allowed_model_configs": ["supervisor", "scientist", "database"]
  }'
```

---

## Step 3: Create Database Agent

```json
{
  "name": "database",
  "chain": [{
    "chain_class": "agent-chain",
    "chain_params": {
      "max_turns": 50,
      "react_enabled": true,
      "supervisor": {
        "prompt": "You are a database agent specialized in retrieving chemical information...",
        "description": "Retrieves SMILES strings and job results from databases"
      },
      "resources": {
        "executables": [
          {"name": "StructureResolver", "type": "tool-call", "description": "Receives compound name and returns its SMILES string"},
          {"name": "ResultRetriever", "type": "tool-call", "description": "Takes a job ID and returns the result"}
        ]
      }
    }
  }],
  "toolkits": ["chemistry-toolkit"]
}
```

### Agent Config Key Fields

| Field | Description |
|-------|-------------|
| chain_class: "agent-chain" | Activates the agentic runtime |
| max_turns | Maximum reasoning iterations |
| react_enabled | Enables ReAct (Reasoning + Acting) pattern |
| supervisor.prompt | Defines agent behavior and reasoning |
| type: "tool-call" | Directly callable tools |
| type: "agentic-model" | Delegation to another agent |
| type: "model" | Query a RAG model |

---

## Step 4: Create Scientist Agent

Similar structure with chemistry analysis tools: CompoundProfile, SMILESCanonicalizer, ADMEProfile, SimilarityAnalysis.

---

## Step 5: Create Supervisor Agent

```json
{
  "name": "supervisor",
  "chain": [{
    "chain_params": {
      "supervisor": {
        "prompt": "You are a supervisor agent orchestrating a drug discovery workflow..."
      },
      "resources": {
        "executables": [
          {"name": "scientist", "type": "agentic-model"},
          {"name": "database", "type": "agentic-model"},
          {"name": "general", "type": "model"}
        ]
      }
    }
  }],
  "data": ["general"]
}
```

---

## Step 6: Upload Knowledge Documents

```bash
curl -X POST "https://<cortex_base_url>/data/upload/general" \
  -F "files=@./pharmaceutical_knowledge.pdf"
```

---

## Using the Agentic Workflow

```bash
curl -X POST "https://<cortex_base_url>/model/ask/supervisor" \
  -F "q=What is the molecular weight of caffeine?" \
  -F "model_session_id_param=research-session-123"
```

### Example Execution Flow: "What is the molecular weight of caffeine?"

1. Supervisor delegates to database agent → StructureResolver returns SMILES
2. Supervisor delegates to scientist agent → CompoundProfile returns MolWt: 194.19
3. Supervisor synthesizes: "The molecular weight of caffeine is 194.19 g/mol"

The `steps` array in the response shows the complete execution trace with hierarchical parent relationships.

---

## Best Practices

### Turn Limits

| Workflow Type | Recommended Turns |
|---------------|-------------------|
| Simple agents | 10-20 |
| Complex workflows | 30-50 |
| Highly iterative tasks | 50-100 |

### Effective Tool Descriptions

Write descriptions from "When would I use this?" perspective:

✅ Good: "Use StructureResolver when you need to convert a compound name into a SMILES string"

❌ Poor: "StructureResolver converts compound names to SMILES"

### Prompt Engineering Best Practices

- Clearly define capabilities and limitations
- Provide examples of when to use each tool
- Set expectations for output format
- Include termination conditions
- Guide the agent's reasoning process

### Design Clear Agent Boundaries

- Focused responsibility: one clear domain per agent
- Distinct toolset: minimal overlap between agents
- Well-defined interface: clear input/output expectations
