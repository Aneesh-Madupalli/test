# Chat Completions & Embedding

**Page URL:** https://cortex.lilly.com/spe/documentation/building-on-cortex-services/getting-raw-model-access/chat-completions-and-embedding/

---

## Chat Completions

Use the `/model/ask/{model}` endpoint to send prompts and receive responses from your configured model. See the API documentation for request/response formats.

---

## Embeddings

Cortex provides access to embedding models for converting text to vector representations.

**Available embedding models:**
- text-embedding-ada-002
- text-embedding-3-small
- text-embedding-3-large

Embeddings are typically used within data configurations for RAG, but can also be accessed directly through the API.

---

## Testing Your Config

- **API:** Call the `/ask` endpoint directly
- **Chat In A Box:** Access at chat.lilly.com to interact with your model through a UI
