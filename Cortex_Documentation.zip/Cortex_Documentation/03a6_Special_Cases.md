# Special Cases

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/building-your-agent/special-cases/

---

## Overview

This section covers advanced scenarios that go beyond standard agent configuration.

---

## When to Use Special Cases

- **Fine-Tuning LLMs** – When standard prompting isn't sufficient and you need the model to learn domain-specific patterns, terminology, or behaviors.
- **Working with Large Datasets in S3** – When your data exceeds typical upload limits or needs synchronization from existing S3 buckets or enterprise data sources.

---

## Sub-pages

- [Cortex Finetuning](/spe/documentation/guides/building-your-agent/special-cases/cortex-finetuning/)
- [Working with Large Datasets in S3](/spe/documentation/guides/building-your-agent/special-cases/large-datasets-s3/)
