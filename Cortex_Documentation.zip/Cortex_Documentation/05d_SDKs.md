# SDKs

**Page URL:** https://cortex.lilly.com/spe/documentation/api-and-sdks/sdks/

---

## Overview

Cortex provides Python SDKs for programmatic integration.

---

## Available SDKs

| SDK | Purpose |
|-----|---------|
| Cortex Platform SDK | Client library for Cortex API access |
| Tools SDK | Framework for building custom agent tools |

---

## Sub-pages

- [Cortex Platform SDK](/spe/documentation/api-and-sdks/sdks/cortex-platform-sdk/)
- [Tools SDK](/spe/documentation/api-and-sdks/sdks/tools-sdk/)
