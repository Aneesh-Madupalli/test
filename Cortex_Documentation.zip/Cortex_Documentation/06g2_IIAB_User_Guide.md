# IIAB User Guide

**Page URL:** https://cortex.lilly.com/spe/documentation/ai-products/insights-in-a-box/user-guide/

---

## Overview

Insights In A Box (Beta) helps teams organize 10s to 1000s of unstructured documents into structured, actionable data at scale. Users define exactly what information they need and extract it in a standardized format while preserving source fidelity and optimizing LLM usage costs.

**Core structure:** Organizations → Vaults → Projects → Columns & Prompts → Analysis → Export

---

## Roles & Permissions

### Vault Roles

| Role | Key Capabilities |
|------|-----------------|
| Vault Owner | Full control — create/edit/delete Vault, manage documents & users |
| Vault Editor | View/upload documents, create private and public projects |
| Vault Viewer | View documents/public projects, create private projects |

### Project Roles

| Role | Key Capabilities |
|------|-----------------|
| Project Owner | Full control — configure columns/prompts, run analysis, manage users |
| Project Editor | Link/unlink documents, configure analysis, run analysis, export |
| Project Viewer | View content and analysis outputs, export results |
| Project Only Editor | Same as Editor but without Vault access |
| Project Only Viewer | View-only without Vault access |

---

## Application Navigation

### Dashboard
- High-level landing page with recent vaults & project tiles
- Count of vaults, projects, and documents in your organization
- Switch organization via dropdown

### Vaults
- Your Vaults for the selected Organization
- Upload/manage documents at Vault level
- Create and manage Projects inside Vaults
- **Public Projects:** visible to all Vault members
- **Private Projects:** visible only to creator and explicitly added users

### Prompts
- Organization-level prompt library
- **My Prompts:** private prompts you create and manage
- **Public Prompts:** prompts available for broader reuse

### Admin Workspace (Admins only)
- **Admin tab:** Manage administrative access
- **Organization Members tab:** View AD group configuration
- **Usage & Cost Metrics tab:** Review usage and costs
- **Manage Vaults & Projects tab:** Governance and cost monitoring
- **Configure LLM tab:** Configure available models/settings

---

## Core Concepts

### Organization
Top-level container — determines what Vaults, Prompts, and Admin Workspace settings you can access.

### Vault
Secure workspace for storing/managing documents and creating Projects.

### Project
Where analysis work happens:
- Choose project type (private or public)
- Link/unlink documents from Vault into analysis scope
- Select applicable columns for analysis
- Use prompts to guide analysis
- Choose run analysis mode, review results, export

### Documents
Uploaded and managed at Vault level. Within a Project, manage document scope by linking/unlinking.

### Prompts
Define how insights are extracted during analysis.
- **Create a Prompt:** Build custom prompt for your use case
- **Use a Template:** Select from existing My Prompts or Public Prompts

---

## User Flow

```
Organization → Vaults → Projects → Columns → Prompts → Run Analysis → Export → Manage Users
```

---

## Sub-pages

- [Organization](/spe/documentation/ai-products/insights-in-a-box/user-guide/organization/)
- [Vaults](/spe/documentation/ai-products/insights-in-a-box/user-guide/vaults/)
- [Projects](/spe/documentation/ai-products/insights-in-a-box/user-guide/projects/)
- [Columns](/spe/documentation/ai-products/insights-in-a-box/user-guide/columns/)
- [Prompts](/spe/documentation/ai-products/insights-in-a-box/user-guide/prompts/)
- [Run Analysis](/spe/documentation/ai-products/insights-in-a-box/user-guide/run-analysis/)
- [Export](/spe/documentation/ai-products/insights-in-a-box/user-guide/export/)
- [Manage Users](/spe/documentation/ai-products/insights-in-a-box/user-guide/manage-users/)
- [Admin Workspace](/spe/documentation/ai-products/insights-in-a-box/user-guide/admin-workspace/)
- [Edge Cases](/spe/documentation/ai-products/insights-in-a-box/user-guide/edge-cases/)
