# Cortex Platform SDK

**Page URL:** https://cortex.lilly.com/spe/documentation/api-and-sdks/sdks/cortex-platform-sdk/

---

## Overview

The Cortex SDK provides Python client access to Cortex APIs.

---

## Installation

```bash
pip install elilillyco-cortex-sdk
```

> The SDK is hosted in Lilly's Artifactory. Configure pip to use the Lilly-Python repository. See the SDK README for setup instructions.

---

## Available APIs

| API | Purpose |
|-----|---------|
| model_config_api | Model configuration management |
| model_ask_api | Chat/ask operations |
| data_api | Data configuration management |
| prompt_new_api | Prompt management |
| toolkit_api | Toolkit management |
| history_api | Chat history |
| jobs_api | Job management |
| model_evaluation_api | Evaluation operations |

---

## Basic Usage

```python
from elilillyco_cortex_sdk.configuration import Configuration
from elilillyco_cortex_sdk.api_client import ApiClient
from elilillyco_cortex_sdk.api.model_config_api import ModelConfigApi

config = Configuration(host="https://api.cortex.lilly.com")
client = ApiClient(config)
client.set_auth_headers(auth_headers)

api = ModelConfigApi(client)
response = api.listmodels_model_get()
```
