# Add Security (Cortex Guard)

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/building-your-agent/add-security/

---

## Overview

Cortex Guard allows you to assemble security policies by selecting scanners from two protection providers:

- **LLM Guard** (from ProtectAI)
- **Guardrails AI**

The workflow:
1. Build or select a Configuration (your Cortex agent workflow)
2. Build a security config that describes the scanners you want
3. Bind that security config to the Configuration

---

## How Cortex Guard Works

Cortex Guard evaluates both **inputs** (user prompts) and **outputs** (model responses) using two integrated security engines at two hierarchical levels:

- **Information Security / Cyber (Parent Level)** — organization-wide mandatory protections
- **User Level** — optional, user-defined protections added on top of Cyber defaults

**Default behavior:** Non-blocking (scans all interactions but doesn't prevent processing)

**Blocking mode:** Set `blocking: true` to actively prevent violating inputs/outputs.

---

## When to Use Cortex Guard

- Enforce security policies across all AI interactions
- Detect sensitive data leakage (PII, PHI, secrets)
- Prevent unsafe model outputs and queries
- Ensure compliance (HIPAA, SOC2, ISO-27001)
- Provide a safety net for LLM app builders

---

## Attack Coverage Summary

| Threat Type | Scanner(s) | Coverage |
|-------------|-----------|----------|
| Prompt Injection / Jailbreak | PromptInjection, JailBreakScanner | ✅ Strong |
| Sensitive Topics / Political | BanSubstrings, BanTopics, CompetitorCheck | ✅ Strong |
| Secrets / PII | Secrets, DetectPII, Anonymize | ✅ Moderate+ |
| Malicious Code | BanCode, Code | ✅ Strong |
| Toxicity / Hate | Toxicity, Sentiment | ✅ Good |
| Brand / Competitor Mentions | BanCompetitors, CompetitorCheck | ✅ Strong |
| Output Format (JSON) | JSON | ✅ Moderate |
| Language Enforcement | Language | ✅ Strong |
| Custom Pattern / Regex | Regex Match | ✅ Strong |

---

## LLM Guard vs Guardrails AI

| Capability | LLM Guard | Guardrails AI |
|-----------|-----------|---------------|
| Prompt injection detection | ✅ | |
| Jailbreak detection | ✅ | |
| PII/Secrets scanning | ✅ | ✅ (DetectPII) |
| Competitor detection | ✅ (BanCompetitors) | ✅ (CompetitorCheck, output only) |
| Topic/substring filtering | ✅ | |
| Structured output enforcement | ✅ (JSON) | |
| Custom regex matching | | ✅ |
| Extensible marketplace | | ✅ |

### When to Use LLM Guard
- Broad, customizable security policies
- Jailbreak/prompt-injection protection
- Topic/substring/domain restrictions
- Secrets and sensitive information scanning

### When to Use Guardrails AI
- Enterprise-grade PII scanning (emails, phone numbers, addresses)
- Competitor/brand-mention detection in outputs
- Custom regex enforcement (medical record IDs, SSNs, internal IDs)

**Both can be enabled simultaneously** for layered security.

---

## How to Configure

### For All Configurations (Cyber/InfoSec)

Create a Cyber Security Config via `POST /manage/securityconfig`

### For Your Configuration (Users) — 3-Step Process

1. **Create your Configuration** via `POST /model`
2. **Create your Security Config** via `POST /security`
3. **Bind Security Config** to your Configuration using the `security_config` attribute

---

## Privacy Settings

| Private | Allowed Model Config | Owner Type | Can Bind | Can Edit |
|---------|---------------------|------------|----------|----------|
| True | Null | Not Admin | No | No |
| False | Null | Not Admin | Yes | No |
| True | Contains Config Name | Not Admin | Yes | No |
| False | Contains Config Name | Not Admin | Yes | No |
| True/False | Any | Admin | Yes | Yes |

---

## Additional Resources

- Cortex Guard Overview
- IS/OS Scanning Functionality
- LLM Guard Scanner Details
