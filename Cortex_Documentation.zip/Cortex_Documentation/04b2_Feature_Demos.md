# Feature Demos

**Page URL:** https://cortex.lilly.com/spe/documentation/use-cases-and-demos/training-and-demos/feature-demos/

---

Video demonstrations of specific Cortex features and capabilities.

## Sub-pages

- [Jobs Framework](/spe/documentation/use-cases-and-demos/training-and-demos/feature-demos/jobs-framework/)
- [Hybrid Search](/spe/documentation/use-cases-and-demos/training-and-demos/feature-demos/hybrid-search/)
- [Drafting Assistant - AIDA](/spe/documentation/use-cases-and-demos/training-and-demos/feature-demos/drafting-assistant-aida/)
- [Connect to CIAB](/spe/documentation/use-cases-and-demos/training-and-demos/feature-demos/connect-to-ciab/)
- [Agent Demo](/spe/documentation/use-cases-and-demos/training-and-demos/feature-demos/agent-demo/)
