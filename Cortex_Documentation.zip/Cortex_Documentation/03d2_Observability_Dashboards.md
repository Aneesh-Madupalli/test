# Observability Dashboards & Alerting

**Page URL:** https://cortex.lilly.com/spe/documentation/guides/preparing-for-release/observability-dashboards-alerting/

---

## Overview

Cortex provides observability through **Grafana** dashboards and **OpenObserve** for monitoring agent performance.

---

## Dashboard Access

### Grafana

| Environment | URL |
|-------------|-----|
| Dev | metrics.apps-d.lrl.lilly.com |
| Prod | metrics.apps.lrl.lilly.com |

**Primary Dashboard:** `Cortex-For-PRD`

### OpenObserve

| Environment | URL |
|-------------|-----|
| Dev | logging.apps-d.lrl.lilly.com |
| Prod | logging.apps.lrl.lilly.com |

**Primary Dashboard:** `Cortex Latency`

---

## Grafana — Cortex-For-PRD Dashboard

### Ask Calls & API Usage

| Panel | What It Shows |
|-------|--------------|
| Total Asks | Number of times the Ask endpoint was called (1-hour rolling window) |
| Ask Rate | How often Ask endpoints are being used |
| API Interaction Rate | Overall usage volume of Cortex APIs |
| Interaction Rate by Department | API usage broken down by team |

### Token Usage

| Panel | What It Shows |
|-------|--------------|
| Total Input Tokens Cortex | Input token count organized by model |
| Input Token Count by Model Language | Prompt tokens processed per model |
| Response Token Count by Model Language | Output tokens generated per model |

### Error Tracking

| Panel | What It Shows |
|-------|--------------|
| API Success Rate | Rate of successful HTTP requests |
| API Error Rate | Total API calls with 5xx status codes |
| API errors by error code | Breakdown of 4xx and 5xx errors |
| Error count by endpoint | Which endpoints are failing |

### Azure OpenAI Metrics

| Panel | What It Shows |
|-------|--------------|
| Provisioned Throughput Units Utilization | Percentage of allocated PTUs being used |
| Number of Requests | Calls made to Azure OpenAI API |
| Azure OpenAI Avg Time to Response | Time for first response after prompt (streaming) |

---

## OpenObserve — Cortex Latency Dashboard

| Panel | What It Shows |
|-------|--------------|
| Ask Latency | Time from request to full response |
| Embed Latency | Time from document upload to embed completion |
| S3 Latency | S3 operation timing |
| Chain Latency | Chain execution timing |

> Latency values displayed in **microseconds**. Use the duration selector (top right) to adjust time range.

---

## Alerting

Alerts can be configured via Slack or MS Teams when metrics exceed thresholds. Contact the Cortex team to set up alerting for your agent.
