# Changelog

All notable changes to this project will be documented in this file.

---

## [1.6.1-en] - 2026-11-06 (English pip edition)

- Everything is in English: messages, the setup report, the agent skill and the docs.
- Installs, updates and uninstalls with `python -m pip`; uv is no longer needed or installed.
- `agent-reach update` upgrades from `agent-reach configure update-source <pip URL>`; an editable install only syncs tools and the skill.
- `python -m agent_reach` runs the CLI when pip's scripts folder is not on PATH.

Older entries below describe upstream Panniantong/Agent-Reach; mentions of uv there apply to upstream only.

## [1.6.1] - 2026-11-01

English:

- Several 1.6.0 cases where web search, Reddit, Xiaohongshu or Bilibili failed although the content was reachable, or reported success with empty content, are fixed.
- When another program on your computer uses the browser port, Agent Reach can use a different one; you don't have to close that program.
- A login copy that fails now says so instead of reporting success.
- On Windows, Xiaohongshu links with special characters open correctly.

English (technical):
- Web search: every request identifies itself as `agent-reach/<version>`, so Exa's Cloudflare front no longer blocks it (#877).
- Reddit: when the site tool fails transiently (for example it returns HTML instead of data), search and read fall back to the public web (#880).
- Xiaohongshu: OpenCLI 2.0 results are mapped, so read no longer succeeds with empty fields; search and comments no longer return one empty row when there are no results (#861, #895).
- Bilibili: a QR login that saved no usable credential is no longer reported as success, and the hint now says `agent-reach login bilibili` (#866, #883).
- The dedicated browser's port is configurable with `agent-reach configure browser-port <port>`, for when another tool holds 9222 (#848).
- Login reuse: no "copied 0 cookies" record when the browser bridge is down; an explicit `login <channel> --import-existing` that copies nothing now fails clearly (#879).
- Windows: Xiaohongshu note links containing `&` can be read and their comments loaded (#860).

## [1.6.0] - 2026-10-23

English:

- Upgrading from an older version: just send your AI the "update Agent Reach" sentence. Your keys and settings are kept, and the old program is removed for you.
- Adding a platform takes one sentence. Everything it needs is installed for you, with no admin password; you only log in or enter a key.
- Platforms that need a login, such as Xiaohongshu and X, now use Agent Reach's own browser in the background, never yours, and several AIs can search at once.
- RSS and Exa search are now part of "web". When a new version is out, your AI tells you in plain words what changed and updates only if you say yes.

1.6 is a rebuild. Agents call one command, `agent-reach`; everything Agent Reach installs or stores lives under `~/.agent-reach/`.

English (technical):
- 28 of 40 actions passed real acceptance before release; these shipped untested with maintainer approval: Reddit (test network blocked), Instagram (rate limited), Bilibili subtitles, LinkedIn, Xueqiu hot posts/stocks (no login), Xiaoyuzhou (no key).
- Browser channels share one profile, close after ten idle minutes and reopen on demand.
- Adding a channel prepares its tools; removal clears only that site's login. Default platforms can be removed and updates won't add them back.
- Updating keeps tools that have a tested version at that version; other tools get the newest version inside their supported range.
- Public content remains public-first, with a compact capability receipt.
- Keep Xiaoyuzhou transcription; remove the extra planner and duplicate site extraction.
- Reuse existing local site sessions read-only; queries default to headless, with a visible window for human login.
- The dedicated browser is identified by the id its extension saves inside its own profile, so the user's own Chrome is never mistaken for it; a query no longer closes an open login window.
- Browser channels run queries in parallel: up to 2 per platform and 4 in total, with the rest queued instead of failing BUSY at once; login windows, logout and browser setup wait for running queries.
- Report NEED_LOGIN instead of UPSTREAM_BROKEN when not logged in: Xueqiu community (error 400016), Bilibili subtitles (no Bilibili login), LinkedIn (no LinkedIn login in the dedicated browser).
- Smoother upgrade from 1.5: install and update share one guide, install.md, which checks the version first (update.md, where 1.5 sends users, points to it); `agent-reach update` moves a pip/pipx install to uv by itself; `setup` removes the old Agent Reach program (only Agent Reach itself) and the install report explains what was kept, what changed and which old channels can be added back. Install URLs always point at the latest release.
- Upstream errors reach the agent unchanged (the original message and help); the agent tells the user which platform is temporarily unavailable, by platform name. Reach no longer replaces them with its own advice (NEED_LOGIN still gives Reach's dedicated-browser login steps).

### ✨ New

- **Unified entry**: `agent-reach <channel> <action>`, `agent-reach read <url>`, `agent-reach channels`. One JSON envelope per call, unified error codes with hints, per-call timeout, automatic fallback to the next backend.
- **Management**: `setup`, `add` / `remove <channel>`, `login` / `logout <channel>`, `doctor`, `check`, `skill`, `skill link <dir>`, `update`, `configure`, `uninstall`.
- **Skill placement**: one real copy at `~/.agents/skills/agent-reach/SKILL.md` (read directly by Codex, OpenCode, Cline, Warp, Zed); a link to it in the skill folder of Claude Code, OpenClaw, Hermes, Cursor, Gemini CLI, GitHub Copilot and Windsurf when installed (a copy where links are not allowed, e.g. Windows). `agent-reach skill link <dir>` covers any other AI.
- **`add` gives a finished result**: missing prerequisites are installed without an admin password: uv (official script), ffmpeg (`imageio-ffmpeg` in a private venv), Node.js (official release under `~/.agent-reach/tools/node/` when the system has none), CloakBrowser (falling back to installed Chrome on download failure). git is no longer needed (Boss installs from a GitHub archive). The user only logs in or enters a key.
- **Login state under `~/.agent-reach/`**: CLI tool logins in `sessions/`, browser logins in a dedicated Agent Reach browser. The browser opens by itself when a channel needs it and closes after 10 minutes without use. The OpenCLI extension is loaded automatically on each CloakBrowser launch; Windows system-Chrome fallback may need one Web Store click. Only the requested site’s cookies are copied read-only from an existing connected local browser; the source remains unchanged.
- **remove cleans up**: deletes the channel's private tools nobody else uses, its CLI session, its login keys and its site cookies in the Agent Reach browser. The shared browser profile is retained for explicit logout/reuse; unused private tools are pruned.
- **Removable default channels**: `state.json` records `removed_defaults`; `setup` and `update` never add them back; `add` brings one back.
- **doctor states**: not_added, needs_setup, needs_login, unverified, ready, broken; plus `regressed` per channel (passed in the previous check, fails in the latest).
- **update** runs `uv tool install --force` on the latest release, reinstalls every added channel's tools at their declared versions (tested version when set, otherwise the newest version inside `floor`/`exclude`; also when Agent Reach itself has no new release), prunes tools no added channel uses, drops channels no longer in the registry, and refreshes the skill. `result.user_actions` lists in plain sentences what the user must do afterwards. Rollback: `uv tool install --force <previous release zip>`, then `agent-reach update --sync-only`. uv is the only supported installer. 1.5 and earlier installs are migrated on first `setup` / `update`; `config.yaml` keys are kept.
- **Update notice**: explicit `update --check` refreshes the release cache. Ordinary queries never start a background version check or update dependencies. Cached newer releases appear in `meta.update`; updating requires the user’s agreement.
- **Release notes**: every CHANGELOG version section starts with a plain summary for users ; it becomes the GitHub release body the AI shows users.
- Xueqiu quotes and stock search via Tencent public quotes (no login); Xueqiu community data uses a session synced from the dedicated browser with `agent-reach login xueqiu --sync`.
- YouTube `transcribe`; LinkedIn reuses OpenCLI search and job-detail in the shared dedicated browser.

### 🔄 Changed

- The agent skill is generated from the channel list and replaced on every update.

### 🗑️ Removed

- RSS channel (agents read feeds themselves).
- xhs-cli, rdt-cli, twitter-cli backends: they read browser cookies by themselves.
- `configure --from-browser`, `twitter-cookies`, `xhs-cookies`, the old `install --channels`, the old `skill --install`, `format`, `check-update`, MCP server entry.
- `watch` (use `doctor`, which now reports `regressed`), `doctor --live` (use `check`), `browser start` (the browser opens by itself), pipx installs.

### 🐛 Bug Fixes

#### 🔐 BOSS Zhipin — wrong login state (two credential stores)

- **Cause:** BOSS keeps two independent login stores: the local `~/.boss-agent/auth/session.enc` and the browser cookie in the dedicated Chrome profile. `boss status` only checked the first, while strict CDP search uses the browser cookie, so "old local credential + browser not logged in" reported `logged_in: true` and searches then hit `AUTH_EXPIRED`.
- **Fix:** `check()` adds a fourth read-only probe that asks the CDP browser itself (`Storage.getCookies`, a minimal standard-library WebSocket client) whether a zhipin `wt2` cookie exists. The browser is the source of truth; no new dependency, no browser launch, no search.
- **Runbook:** `AUTH_EXPIRED` is ground truth and goes straight to the login flow; `_security_check` is treated as a slider only when there is no `AUTH_EXPIRED`; after opening the dedicated Chrome, pause so the user can confirm the login visually.

### ✨ Features

#### 🎯 BOSS Zhipin channel

- New `boss` channel: job search and full job descriptions through boss-agent-cli and a real Chrome over CDP.
- `check()` runs four read-only probes (boss-agent-cli installed → port 9222 reachable → a zhipin tab exists → a `wt2` login cookie in the browser).
- Data comes from the public API (`search_jobs` + `job_card_browser` + `browser_source="existing-browser"`).
- `agent-reach install --system --channels=boss` installs a pinned upstream boss-agent-cli commit (`4c991b7`); search can forbid headless fallback with `--browser-source existing-browser`.
- code 37 is classified by its original text: an environment-risk message stops immediately; only an explicit token expiry allows one refresh.

## [1.3.1] - 2026-03-27

### 🐛 Bug Fixes

#### 📈 Xueqiu — full repair

- Fixed the root cause of HTTP 400: the homepage only sets `acw_tc`, while `xq_a_token` is generated by the site's JavaScript. Cookies now load in three steps: config file → local Chrome (with browser-cookie3) → homepage fallback.
- Replaced the `agent-reach/1.0` User-Agent, which the site rejected, with a real Chrome UA, and added `Referer: https://xueqiu.com/` to every API request.
- `get_hot_posts()` moved from the retired `/statuses/hot/listV3.json` to `/v4/statuses/public_timeline_by_category.json`.
- `configure --from-browser` now extracts the Xueqiu cookie; docs no longer claim it needs no configuration; `check()` failures point to `configure --from-browser chrome`.

---

## [1.3.0] - 2026-03-12

### 🆕 New Channels

#### 💻 V2EX
- Hot topics, node topics, topic detail + replies, user profile via public JSON API
- Zero config — no auth, no proxy, no API key required
- `get_hot_topics(limit)`, `get_node_topics(node_name, limit)`, `get_topic(id)`, `get_user(username)`

### 📈 Improvements

- Channel count: 14 → 15

---

## [1.1.0] - 2025-02-25

### 🆕 New Channels

#### ~~📷 Instagram~~ (removed — upstream blocked)
- ~~Read public posts and profiles via [instaloader](https://github.com/instaloader/instaloader)~~
- **Removed:** Instagram's aggressive anti-scraping measures broke all available open-source tools (instaloader, etc.). See [instaloader#2585](https://github.com/instaloader/instaloader/issues/2585). Will re-add when upstream recovers.

#### 💼 LinkedIn
- Read person profiles, company pages, and job details via [linkedin-scraper-mcp](https://github.com/stickerdaniel/linkedin-mcp-server)
- Search people and jobs via MCP, with Exa fallback
- Fallback to Jina Reader when MCP is not configured

#### 🏢 BOSS Zhipin
- QR code login via [mcp-bosszp](https://github.com/mucsbr/mcp-bosszp)
- Job search and recruiter greeting via MCP
- Fallback to Jina Reader for reading job pages

### 📈 Improvements

- Channel count: 9 → 12
- `agent-reach doctor` now detects all 12 channels
- CLI: added `search-linkedin`, `search-bosszhipin` subcommands
- Updated install guide with setup instructions for new channels

---

## [1.0.0] - 2025-02-24

### 🎉 Initial Release

- 9 channels: Web, Twitter/X, YouTube, Bilibili, GitHub, Reddit, XiaoHongShu, RSS, Exa Search
- CLI with `read`, `search`, `doctor`, `install` commands
- Unified channel interface — each platform is a single pluggable Python file
- Auto-detection of local vs server environments
- Built-in diagnostics via `agent-reach doctor`
- Skill registration for Claude Code / OpenClaw / Cursor
