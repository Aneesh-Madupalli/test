# Sessions and the dedicated browser

Read this when the user wants to log in, log out or switch accounts, or a result returns `NEED_LOGIN`.

## The dedicated browser

- All browser channels share one dedicated browser profile, separate from the user's everyday Chrome; the program never closes or changes the user's everyday browser.
- The engine is CloakBrowser first; if downloading or installing it fails, the Chrome already on the machine is used, and that fallback is remembered so it is not downloaded every time. After the network is fixed, `agent-reach browser setup --retry-cloak` tries again.
- `agent-reach add <channel>` prepares Node, OpenCLI, the engine and the extension automatically. Tools are installed at the versions tested for this release. On Windows with the Chrome fallback, the user may need to click "Add to Chrome" once.
- Headless by default, no windows. Only `agent-reach login <channel>` shows a window; while that window is open, queries use it and do not close it. While the user is logging in, wait until they say they are done before querying. After the window closes, later queries go back to headless.
- It closes by itself after 10 idle minutes and reopens on the next call; real page activity and Reach calls reset the timer. During login it saves periodically, so the user does not need to close the window.
- It can run in parallel: at most 2 at a time per platform and 4 in total; extra calls queue for up to 2 minutes and return `BUSY` only if they still cannot start. Two searches on the same platform are at least 10 seconds apart. Opening a login window, logging out and reinstalling the browser wait for running queries to finish first.
- `agent-reach browser status` shows status, `browser setup` prepares the engine and extension, `browser stop` closes the browser the program manages.

## Reusing an existing login automatically

1. The first time a site is used, if the user's Chrome is connected to the OpenCLI extension, the program copies that site's login (that site's cookies only) once into the dedicated browser. It never copies the whole browser folder, other sites or the password store, and never changes the source browser.
2. After a successful copy, the saved session is reused from then on, not copied again on a timer. Having cookies does not mean the login is valid; the result of a real action decides.
3. When the user's Chrome is not connected to the extension, do not promise automatic reuse, and do not conclude the user is logged out; use the session Reach already saved.
4. When several browsers on the machine are logged in to the site: `agent-reach browser profiles` lists the sources and `agent-reach browser use <ID>` picks one; it never switches at random.
5. `agent-reach login <channel> --import-existing` copies that site's login again on request, without opening a window. If no login to copy is found, or the OpenCLI Bridge is not running, it returns `NEED_SETUP` and the saved session stays as it is.
6. Once the user has logged in themselves in the dedicated window, or run `logout` / `remove`, it no longer copies automatically, so a logged-out session does not come back.

## When the user needs to log in themselves

- Ask the user to log in only when an action actually returned `NEED_LOGIN` and the remaining task really needs that path. A login button next to the content does not count as a login requirement.
- `agent-reach login <channel>` opens the dedicated browser on the site's login page, and the user logs in themselves. You never log in for them, never ask for passwords and never print cookies.
- If the result's `next` lists follow-up steps, do them; some native-tool channels (such as Xueqiu) need `agent-reach login <channel> --sync` after logging in.
- When the user is done, run the original action again to verify.

## Platform differences

- BOSS Zhipin in-site search goes through OpenCLI and shares the dedicated browser. If a job detail asks for a login because of an upstream false alarm, do not make the user log in again and again.
- Bilibili hands the existing login to Bilibili's official command-line tool only to read subtitles; ordinary search does not prepare the browser.
- Xueqiu community actions need a login; the session expires within a few hours, after which repeat the login steps.

## Logging out and removing

- `agent-reach logout <channel>`: clears that site's login and the channel's own state in the dedicated browser; other sites are kept.
- `agent-reach remove <channel>`: removes the channel and also clears that site's login and storage; other sites are kept. If cleanup fails, the channel record is kept and an error is returned so the user can retry.
- After either one, that site's login is no longer copied automatically.
