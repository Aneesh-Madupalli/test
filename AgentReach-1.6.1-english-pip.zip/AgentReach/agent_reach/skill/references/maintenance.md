# Maintenance

Read this when an update fails, the browser will not start, a channel reports an error, or the user wants to uninstall.

- Update: `agent-reach update` upgrades Agent Reach (with pip), the tools of added channels and the skill; `agent-reach update --check` only checks whether a new version exists. Run it only after the user agrees. An editable install (`pip install -e`) is not reinstalled: the user updates the source folder (for example `git pull`) and then runs `agent-reach update` to sync tools and the skill. A pip install needs an update source once: `agent-reach configure update-source <pip URL, may contain {version}>`.
- Status: `agent-reach doctor --text` reads local status without the network; `agent-reach check <channel> --text` runs one live test (`--search` tests only search/jobs). A successful install is not a passed live test.
- Browser: `agent-reach browser status` shows status, `browser setup` prepares the engine and extension, `browser stop` closes it; after a CloakBrowser download failure, fix the network and run `browser setup --retry-cloak`.
- Tell the failing step apart: dependency download, browser connection, login, page load and platform rate limits are separate; never call a network timeout an expired login.
- Upstream tool errors: note the error and version, run `agent-reach update` once after the user agrees; never edit an upstream tool's installed files, never retry in a loop.
- `PLATFORM_BLOCKED`, `RATE_LIMITED`, `NEED_LOGIN`, `BUSY`: stop this attempt and wait for the user to deal with it before continuing; do not keep opening windows.
- Keys and proxy: `agent-reach configure groq-key | openai-key | proxy | github-token`; the user provides the value themselves.
- Port conflict (`Port <n> belongs to an unmanaged browser`): another program is using the dedicated browser port (default 9222). Do not close the user's program; after the user agrees, run `agent-reach configure browser-port <free port>`.
- Uninstall: show the scope with `agent-reach uninstall --dry-run` first, then run `agent-reach uninstall` once the user confirms. Only what Reach installed is removed; the user's other files and browsers are kept. Remove the program itself with the `remove_program` command it prints (`py -m pip uninstall agent-reach`).
