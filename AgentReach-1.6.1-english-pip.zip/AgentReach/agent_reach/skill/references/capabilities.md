# Capability scope

Read this when the user asks "what can it fetch, is it complete?", or when you need to judge how complete a result is. The table lists declared capabilities; not every network, account and piece of content has been tested.

## Three layers

- **Public, try first**: the agent's own web tools, native tools or public APIs may already be enough for the task; no browser install or login needed. Answer from the evidence you actually got.
- **Reach adds**: the actions declared by this release, see `agent-reach channels`. When setup is needed, reuse the session already saved in the dedicated browser first; the user logs in themselves only when the chosen path really requires it.
- **Verified on this machine**: only the specific actions that recently passed a check here. Installing, saving a session or the network being reachable is not the same as a passed check.

## Channels in this release

| Channel | Public path to try | What Reach adds, and its limits |
|---|---|---|
| GitHub | Public repositories, READMEs, issues/PRs | Repository search; reading repositories, issues and PRs with the comments returned; private access is judged separately |
| YouTube | Search, titles, descriptions; native tools may get some comments and subtitle text | search/read/subtitle/transcribe; no unified comments action yet; a list of tracks is not subtitle text; without subtitles, transcription depends on the matching tool |
| Bilibili | Search, descriptions; some public APIs return comments with parent/child IDs | search/read/hot/subtitle; no unified comments action yet; subtitles vary by video and access path |
| Reddit | Search, post bodies, some comments; some public JSON includes parent/child IDs | Browser search/read/subreddit; whether login is needed depends on the chosen path; no complete comment tree or all replies guaranteed; no commenting |
| X/Twitter | Public single posts found by search; some official public embeds return the full text | search/profile/tweets/thread; a readable single post does not mean the reply stream is readable; no complete comment tree guaranteed |
| Xiaohongshu | Public lists or indexes may have note IDs, authors and titles; do not guess empty fields | search/read/comments; text description, top-level comments and loaded replies; not all comments guaranteed; no claim to understand images/videos |
| Instagram | Some index entries and shallow profile info; the HTML app shell is not a post | search finds users, profile reads a profile, posts reads a given user's post captions; no unified comments action; no claim to understand images/videos |
| Facebook | Some index entries or HTML snippets; snippets may be truncated | search/profile; no unified detail or comments action; never treat a search snippet as the full text |
| LinkedIn | Search public jobs, read public job descriptions | jobs/read try the public web first; only `--backend opencli` goes inside the site; not every job is guaranteed readable |
| BOSS Zhipin | Search indexes may have job summaries | search/read job lists and descriptions; do not guess numbers from encoded salaries; detail fallbacks follow the channel's declaration |
| V2EX | Topics, bodies and public replies | hot/node/read/user; the scope is what this response returned; hidden or missing replies are not guaranteed |
| Xueqiu | Some public quotes and index info | quote/search/hot_posts/hot_stocks; quote and community paths are checked separately |
| Hacker News | Public story pages and comment threads | search/top/read through the Algolia API; read returns the comment tree as returned, capped for size |
| Stack Overflow | Public question pages and answers | search/read through the StackExchange API; read puts the accepted answer first; the anonymous quota is about 300 requests a day per IP |
| PubMed | Public abstract pages | search/read through NCBI E-utilities; read returns the abstract and metadata, not the full paper |
| ClinicalTrials.gov | Public study pages | search (optional status filter)/read through API v2; read returns eligibility, arms, outcomes and locations |
| News | Google News headlines | search/top return headlines, sources, dates and links; read the article itself with the web channel |
| Web | The agent's own search/read | Reach web search/read is the anonymous fallback; snippets, page shells and verification pages are not full text |
| Xiaoyuzhou | Episode page title and description | transcribe turns a whole episode into text; needs a Groq key from the user (`agent-reach configure groq-key`) |

After a login, describe capability as "can enable / try the browser actions above", never as "supports all comments after login". If the user skips logging in, deliver the public evidence you already have.
