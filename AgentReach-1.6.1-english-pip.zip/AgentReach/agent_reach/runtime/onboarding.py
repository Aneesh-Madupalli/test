"""Read-only session discovery and explicit connection choices. Never logs a user in."""
import json
import urllib.request
from datetime import datetime
from urllib.parse import urlsplit

from agent_reach.utils.url import host_matches

from .result import BAD_INPUT, ReachError

# These describe public routes an agent can try, not authenticated Reach readiness.
# A successful sample depends on the tool, network exit, content and platform response.
_PUBLIC_ACCESS = {
    'web': "Use the agent's own web search and reading first; call Reach only for what is left.",
    'github': 'Public repositories, READMEs, issues/PRs and public comments can be read through the web or public APIs first.',
    'youtube': 'Public search and descriptions can be read first; native-tool samples can include comments, subtitles and timestamps.',
    'bilibili': 'Public search, descriptions and stats can be read first; some public APIs return comments and reply threads.',
    'xiaoyuzhou': 'Podcast transcription needs a Groq key; installing needs no login.',
    'v2ex': 'Public topic bodies and some replies can be read first; completeness and paging must be checked separately.',
    'reddit': 'Public search, post bodies and some comments can be read first; some public JSON samples include comments and parent_id.',
    'twitter': 'Public search snippets and some single-post full text can be tried first; public embeds have no comment stream.',
    'xiaohongshu': 'Public discovery pages may give note IDs and authors; that alone does not mean bodies or comments are readable.',
    'instagram': 'Public search or profile info can be tried first; HTML may be only the app shell, captions and comments are not verified.',
    'facebook': 'Public search snippets can be tried first; post bodies and comments depend on the page and access path.',
    'linkedin': 'Public jobs can be searched and read first; a no-login job sample worked on 2026-10-21, not every job is guaranteed.',
    'boss': 'Public job indexes and pages can be tried first; anonymous access was not verified in detail this round.',
    'xueqiu': 'Public stock quotes and name search can be tried first; community content depends on the chosen path.',
    'hackernews': 'Public Algolia API: story search, the front page and comment threads, no login.',
    'stackoverflow': 'Public StackExchange API: question search and answers; the anonymous quota is about 300 requests a day per IP.',
    'pubmed': 'Public NCBI E-utilities: search and abstracts; full text is only on the publisher or PMC page.',
    'clinicaltrials': 'Public ClinicalTrials.gov API v2: study search and full study records.',
    'news': 'Google News RSS: headlines, sources and links; article bodies are read with the web channel.',
}

_CAPABILITY_LIMITS = {
    'youtube': ['read returns metadata and the description; there is no separate comments action.',
                'Subtitles depend on available tracks; transcription also needs a configured service and quota; logging in does not guarantee subtitles.'],
    'bilibili': ['read returns metadata and the description; there is no separate comments action.',
                 'subtitle reads the existing subtitles of the first part only; it may need a login and does not cover multi-part videos.'],
    'reddit': ['read only promises the posts and comments it returns; no complete comment tree, no commenting.'],
    'twitter': ['thread only covers replies actually returned; no complete comment stream, no posting.'],
    'xiaohongshu': ['Only the body, loaded comments and replies actually read are reported; no complete export.'],
    'instagram': ['search finds users; there is no read of arbitrary posts and no separate comments action.'],
    'facebook': ['Only search/profile are declared; no separate post reading or comment export.'],
    'linkedin': ['Only job search and job-description reading are declared; no contacts or feed scraping.'],
    'boss': ['Only job search and job-description reading are declared; logging in does not guarantee the site allows access.'],
    'v2ex': ['Check paging and the returned count to know whether replies are complete.'],
    'hackernews': ['read returns the comment tree the API returns, capped for size; it is not a live view.'],
    'stackoverflow': ['Anonymous use shares a quota of about 300 requests a day per IP; RATE_LIMITED means wait.'],
    'pubmed': ['read returns the abstract and metadata only, not the full paper.'],
    'clinicaltrials': ['search returns a summary per study; read one study for eligibility, arms and locations.'],
    'news': ['Only headlines, sources, dates and links; links are news.google.com redirects to the publisher.'],
}


# Public web options and authenticated Reach actions; detailed limits stay in capability_summary.
_QUICK_ACCESS = {
    'xiaoyuzhou': ('🔑 transcription needs a key', '—'),
    'github': ('✅ find projects, read docs, discussions, comments', '—'),
    'youtube': ('✅ find videos, read descriptions, read subtitles', '—'),
    'bilibili': ('✅ find videos, read descriptions', '❌ read subtitles'),
    'v2ex': ('✅ read topics and replies', '—'),
    'web': ('✅ search, read web pages', '—'),
    'reddit': ('✅ search posts, read bodies and comments', '—'),
    'twitter': ('✅ search snippets, try reading posts', '❌ search tweets, timelines, replies'),
    'xiaohongshu': ('✅ search snippets, find links', '❌ in-site search, read notes, comments'),
    'instagram': ('✅ search bios', '❌ find users, profiles, posts'),
    'facebook': ('✅ search snippets', '❌ in-site search, profiles'),
    'linkedin': ('✅ find jobs, read public details', '❌ in-site search'),
    'boss': ('✅ search titles, find links', '❌ in-site search, read details'),
    'xueqiu': ('✅ find stocks, get quotes', '❌ hot posts, hot stocks'),
    'hackernews': ('✅ search stories, front page, read comments', '—'),
    'stackoverflow': ('✅ search questions, read answers', '—'),
    'pubmed': ('✅ search papers, read abstracts', '—'),
    'clinicaltrials': ('✅ search studies, read study records', '—'),
    'news': ('✅ search headlines, top stories', '—'),
}

_DISPLAY_NAMES = {
    'xiaoyuzhou': 'Xiaoyuzhou (podcasts)',
    'github': 'GitHub', 'youtube': 'YouTube', 'bilibili': 'Bilibili', 'v2ex': 'V2EX',
    'web': 'Web', 'reddit': 'Reddit', 'twitter': 'X / Twitter', 'facebook': 'Facebook',
    'instagram': 'Instagram', 'xiaohongshu': 'Xiaohongshu (RED)', 'linkedin': 'LinkedIn',
    'boss': 'BOSS Zhipin (jobs)', 'xueqiu': 'Xueqiu (stocks)',
    'hackernews': 'Hacker News', 'stackoverflow': 'Stack Overflow', 'pubmed': 'PubMed',
    'clinicaltrials': 'ClinicalTrials.gov', 'news': 'News (Google News)',
}

_STATUS_LABELS = {
    'not_added': 'not added, add when needed', 'needs_setup': 'needs setup', 'unverified': 'added, not yet tested',
    'ready': 'verified', 'search_ready': 'only search verified',
    'needs_login': 'tested action needs login', 'cooldown': 'paused for now',
    'needs_user_action': 'waiting for user verification', 'broken': 'current path broken',
}


def _local_greeting():
    """Use the installing computer's clock and timezone, without a network lookup."""
    hour = datetime.now().hour
    if 5 <= hour < 12:
        return 'Good morning, what would you like to look up? ☀️'
    if 12 <= hour < 18:
        return 'Good afternoon, what would you like to look up?'
    if 18 <= hour < 22:
        return 'Good evening, what would you like to look up?'
    return "It's late, what would you like to look up? 🌙"

def _upgrade_lines(result):
    """Only for users coming from 1.5: what was kept, what changed, what is left to do."""
    migration = result.get('migration')
    if not migration:
        return []
    lines = ['**This is an upgrade from the old version (1.5):**', '',
             '- Your keys and settings were kept.',
             '- RSS feeds and Exa web search are no longer separate; use "Web" to search and read pages.',
             "- Sites that need a login, such as X and Xiaohongshu, now use Agent Reach's own browser; the first time, it tries to reuse your Chrome login.",
             '- Command-line tools you installed yourself (such as twitter-cli or bili) were left as they are.']
    suggested = [_DISPLAY_NAMES.get(n, n) for n in migration.get('suggested_channels') or []]
    if suggested:
        lines.append('- You used ' + ', '.join(suggested) + ' before; to keep using them, just say "add <name>".')
    old = result.get('old_copies') or {}
    if old.get('removed'):
        lines.append('- The old program was removed, so it will not clash with the new one.')
    for item in old.get('failed') or []:
        from .legacy import manual_command
        lines.append(f"- The old program could not be removed; run: `{manual_command(item)}`")
    return lines + ['']



def installation_report(result):
    """Render one short receipt; keep detailed evidence in the structured summary."""
    def cell(value):
        return str(value).replace('|', r'\|').replace('\n', ' ')

    entries = result['capability_summary']['channels']
    installs = {row['channel']: row for row in result['default_channels']}
    installed = sum(bool(row['ok']) for row in installs.values())
    completed = all(row['ok'] for row in installs.values())
    lines = [
        _local_greeting(), '',
        f"**Agent Reach {result['version']} {'is installed' if completed else 'is one step from done'}.** "
        f'Default channels: {installed}/{len(installs)} ready.', '',
        *_upgrade_lines(result),
        '✅ no login needed; ❌ try after logging in; 🔑 needs a key; — no extra login.', '',
        '| Platform | Without login | Needs login |', '|---|---|---|',
    ]
    for entry in sorted(entries, key=lambda item: item['level'] != 'default'):
        name = entry['channel']
        label = _DISPLAY_NAMES.get(name, name)
        item = installs.get(name)
        if entry['level'] == 'default':
            if item and not item['ok']:
                label += ' (install failed: ' + item.get('error', {}).get('code', 'UNKNOWN') + ')'
            elif not item:
                label += ' (removed by you, kept removed)'
        elif entry['reach_status'] in {'needs_setup', 'needs_login', 'cooldown', 'needs_user_action', 'broken'}:
            label += ' (' + _STATUS_LABELS[entry['reach_status']] + ')'
        public, login = _QUICK_ACCESS.get(name, (entry['public_access'], '—'))
        lines.append('| ' + ' | '.join(cell(value) for value in (label, public, login)) + ' |')
    verified = [entry for entry in entries if entry['verified_actions']]
    if verified:
        names = '; '.join(_DISPLAY_NAMES.get(entry['channel'], entry['channel']) + ': ' +
                          '/'.join(entry['verified_actions']) for entry in verified)
        lines += ['', 'Tested and working: ' + names + '. The others have not been tested online yet.']
    else:
        lines += ['', 'No channel has been tested online yet.']
    lines += ['Snippets, titles and links come from search engines first; comments are only what was read; subtitles must come with the video.', '',
              '**Just say what you want to look up.** Existing logins are reused first; a window opens only when you really need to log in.']
    return '\n'.join(lines) + '\n'



def capability_summary(channels, statuses):
    """Describe public options, declared actions and local evidence without any I/O.

    Management supplies status records so this summary cannot initiate discovery,
    installation, login or a live request. Actions always come from the registry.
    """
    by_name = {entry['channel']: entry for entry in statuses}
    entries = []
    for ch in channels:
        current = by_name.get(ch.name, {})
        names = [action.name for action in ch.actions]
        can_login = bool(ch.login_url or ch.login_argv)
        auth_actions = {'bilibili': ['subtitle'], 'xueqiu': ['hot_posts', 'hot_stocks']}.get(
            ch.name, names if can_login else [])
        entries.append({
            'channel': ch.name,
            'level': ch.level,
            'reach_status': current.get('status', 'unverified'),
            'verified_actions': current.get('verified_actions', []),
            'actions': [{'action': action.name, 'detail': action.help} for action in ch.actions],
            'public_access': _PUBLIC_ACCESS.get(ch.name, "Try the agent's own public search and reading first."),
            'authentication': {
                'when': 'only_if_required',
                'may_enable_actions': [name for name in auth_actions if name in names],
                'note': 'Only when the chosen path for the remaining task really needs authentication: reuse an authorized session first, then ask the user to log in; verify the action again after logging in.',
            },
            'limits': _CAPABILITY_LIMITS.get(ch.name, []),
        })
    message = ["Use the agent's own public search and reading first; Reach fills the gaps on demand, and installing does not need a login per platform."]
    for entry in entries:
        actions = '/'.join(action['action'] for action in entry['actions'])
        status_label = _STATUS_LABELS.get(entry['reach_status'], entry['reach_status'])
        limits = ' '.join(entry['limits'])
        message.append(f"{entry['channel']}: {entry['public_access']} Reach {actions} ({status_label}). {limits}".rstrip())
    return {
        'policy': 'public_first; login_only_for_remaining_task_when_required',
        'evidence_note': 'Public-path notes come from samples and access conditions and do not replace a local Reach check; a network error, 403, timeout or captcha alone does not prove a login is needed.',
        'channels': entries,
        'message': '\n'.join(message),
    }


def cdp_url():
    from .browser import CDP_URL
    return validate_cdp(CDP_URL)


def validate_cdp(value):
    try:
        u = urlsplit(value)
        valid = (u.scheme == 'http' and u.hostname in {'localhost', '127.0.0.1', '::1'}
                 and u.port and not u.username and not u.password and not u.query
                 and not u.fragment and u.path in ('', '/'))
    except (TypeError, ValueError):
        valid = False
    if not valid:
        raise ReachError(BAD_INPUT, 'CDP must be a loopback HTTP address with an explicit port')
    return value.rstrip('/')


def cdp_status():
    url = cdp_url()
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with opener.open(url + '/json/list', timeout=2) as resp:
            tabs = json.loads(resp.read(1024 * 1024))
        found = isinstance(tabs, list) and any(
            isinstance(t, dict) and t.get('type') == 'page'
            and host_matches(t.get('url', ''), 'zhipin.com') for t in tabs)
        return {'endpoint': url, 'connected': isinstance(tabs, list), 'boss_tab_present': bool(found)}
    except (OSError, ValueError):
        return {'endpoint': url, 'connected': False, 'boss_tab_present': False}


def require_boss_cdp():
    from . import browser, session_reuse
    session_reuse.prepare("boss")
    if not cdp_status()['boss_tab_present']:
        browser.open_url('https://www.zhipin.com/web/geek/jobs')
    browser.touch()
    return browser.CDP_URL
