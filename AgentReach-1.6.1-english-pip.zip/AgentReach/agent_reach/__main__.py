"""`python -m agent_reach ...` runs the CLI, for when pip's scripts folder is not on PATH."""

import sys

from agent_reach.cli import main

sys.exit(main())
