# -*- coding: utf-8 -*-
"""Stack Overflow — public StackExchange API 2.3: search questions, read a question with its answers."""

import gzip
import html
import json
import re
import urllib.error
from typing import Any, Optional
from urllib.parse import urlencode, urlsplit

from agent_reach.runtime.result import (
    BAD_INPUT,
    NOT_FOUND,
    RATE_LIMITED,
    UPSTREAM_BROKEN,
    ReachError,
    make_item,
    unix_to_iso,
)
from agent_reach.runtime.run import http_request

from .base import Action, Channel, Param

_API_HOST = "api.stackexchange.com"
_API_BASE = f"https://{_API_HOST}/2.3"
_SITE = "stackoverflow"
_MAX_LIMIT = 100
_MAX_TEXT_CHARS = 200_000
_THROTTLE_ERROR_ID = 502


# ---------------------------------------------------------------------- #
# HTTP
# ---------------------------------------------------------------------- #


def _api_url(path: str, **params: Any) -> str:
    """Build an API URL; caller values only ever land in the encoded query."""
    query = dict(params)
    query["site"] = _SITE
    return f"{_API_BASE}{path}?{urlencode(query)}"


def _validate_api_url(url: str) -> None:
    """Allow only HTTPS requests to the StackExchange API host."""
    try:
        parsed = urlsplit(url)
        port = parsed.port
    except ValueError as exc:
        raise ValueError("invalid StackExchange API URL") from exc
    if (
        parsed.scheme.lower() != "https"
        or (parsed.hostname or "").lower() != _API_HOST
        or port not in {None, 443}
        or parsed.username is not None
        or parsed.password is not None
        or not parsed.path.startswith("/2.3/")
    ):
        raise ValueError("only the StackExchange HTTPS API is allowed")


def _decode(body: bytes) -> Any:
    """Decode a JSON body, transparently handling gzip (the API may gzip regardless)."""
    if body[:2] == b"\x1f\x8b":
        body = gzip.decompress(body)
    return json.loads(body.decode("utf-8"))


def _raise_api_error(data: Any, status: Optional[int] = None) -> None:
    """Map an API error payload (or quota exhaustion) to a ReachError."""
    if not isinstance(data, dict):
        raise ReachError(UPSTREAM_BROKEN, "StackExchange API returned an unexpected response")
    error_id = data.get("error_id")
    message = str(data.get("error_message") or data.get("error_name") or "unknown error")
    if error_id == _THROTTLE_ERROR_ID or data.get("error_name") == "throttle_violation":
        raise ReachError(RATE_LIMITED, f"StackExchange throttle: {message}")
    if error_id is not None:
        if data.get("error_name") == "bad_parameter" or (status == 400 and error_id == 400):
            raise ReachError(BAD_INPUT, f"StackExchange rejected a parameter: {message}")
        raise ReachError(UPSTREAM_BROKEN, f"StackExchange API error {error_id}: {message}")
    if data.get("quota_remaining") == 0:
        raise ReachError(RATE_LIMITED, "StackExchange daily request quota exhausted")


def _get_json(url: str, *, timeout: float) -> dict:
    """GET an API URL and return the decoded wrapper object, raising on API errors."""
    _validate_api_url(url)
    try:
        body = http_request(url, timeout=timeout, headers={"Accept-Encoding": "identity"})
    except urllib.error.HTTPError as exc:
        # The API reports errors (incl. throttling) as HTTP 400 with a JSON body.
        try:
            data = _decode(exc.read() or b"")
        except Exception:
            raise exc from None
        if isinstance(data, dict) and data.get("error_id") is not None:
            _raise_api_error(data, exc.code)
        raise
    data = _decode(body)
    _raise_api_error(data)
    return data


# ---------------------------------------------------------------------- #
# HTML -> text
# ---------------------------------------------------------------------- #

_PRE_RE = re.compile(r"<pre[^>]*>(.*?)</pre>", re.IGNORECASE | re.DOTALL)
_BR_RE = re.compile(r"<br\s*/?>", re.IGNORECASE)
_BLOCK_END_RE = re.compile(r"</(?:p|div|h[1-6]|blockquote|ul|ol|table|tr)>", re.IGNORECASE)
_LI_RE = re.compile(r"<li[^>]*>", re.IGNORECASE)
_TAG_RE = re.compile(r"<[^>]+>")
_BLANKS_RE = re.compile(r"\n{3,}")
_PLACEHOLDER = "\x00CODE{}\x00"


def _html_to_text(value: Any) -> str:
    """Strip HTML to readable plain text, keeping code blocks indented."""
    if not value:
        return ""
    src = str(value)
    blocks: list[str] = []

    def _keep_code(match: "re.Match[str]") -> str:
        code = html.unescape(_TAG_RE.sub("", match.group(1))).strip("\n")
        blocks.append("\n".join("    " + line for line in code.splitlines()))
        return "\n\n" + _PLACEHOLDER.format(len(blocks) - 1) + "\n\n"

    src = _PRE_RE.sub(_keep_code, src)
    src = _BR_RE.sub("\n", src)
    src = _LI_RE.sub("\n- ", src)
    src = _BLOCK_END_RE.sub("\n\n", src)
    text = html.unescape(_TAG_RE.sub("", src))
    for idx, block in enumerate(blocks):
        text = text.replace(_PLACEHOLDER.format(idx), block)
    text = "\n".join(line.rstrip() for line in text.splitlines())
    return _BLANKS_RE.sub("\n\n", text).strip()


def _unescape(value: Any) -> Optional[str]:
    return html.unescape(str(value)) if value else None


def _cap(text: str) -> str:
    if len(text) <= _MAX_TEXT_CHARS:
        return text
    return text[:_MAX_TEXT_CHARS].rstrip() + "\n\n[truncated]"


# ---------------------------------------------------------------------- #
# Target parsing
# ---------------------------------------------------------------------- #

_QUESTION_URL_RE = re.compile(
    r"^(?:https?://)?(?:www\.)?stackoverflow\.com/(?:questions|q)/(\d+)(?:[/?#].*)?$",
    re.IGNORECASE,
)


def _parse_question_id(target: Any) -> int:
    """Accept a question id or a stackoverflow.com/questions/<id> (or /q/<id>) link."""
    t = str(target or "").strip()
    if t.isdigit() and int(t) > 0:
        return int(t)
    match = _QUESTION_URL_RE.match(t)
    if match:
        return int(match.group(1))
    raise ReachError(
        BAD_INPUT,
        "target must be a Stack Overflow question link (https://stackoverflow.com/questions/<id>) or id",
    )


# ---------------------------------------------------------------------- #
# Shaping
# ---------------------------------------------------------------------- #

_QUESTION_RAW_KEYS = (
    "question_id",
    "score",
    "answer_count",
    "is_answered",
    "accepted_answer_id",
    "view_count",
    "tags",
)


def _question_raw(q: dict) -> dict:
    return {k: q.get(k) for k in _QUESTION_RAW_KEYS if k in q}


def _owner(entry: dict) -> Optional[str]:
    return _unescape((entry.get("owner") or {}).get("display_name"))


def _question_item(q: dict, *, text: str, raw: dict) -> dict:
    return make_item(
        title=_unescape(q.get("title")),
        url=q.get("link"),
        author=_owner(q),
        published_at=unix_to_iso(q.get("creation_date")),
        text=_cap(text),
        raw=raw,
    )


def _with_backoff(items: list, data: dict) -> list:
    backoff = data.get("backoff")
    if backoff is not None and items and isinstance(items[0].get("raw"), dict):
        items[0]["raw"]["backoff_seconds"] = backoff
    return items


def _answer_sort_key(a: dict) -> tuple:
    return (0 if a.get("is_accepted") else 1, -int(a.get("score") or 0))


class StackOverflowChannel(Channel):
    name = "stackoverflow"
    description = "Stack Overflow questions and answers"

    level = "default"
    actions = (
        Action(
            "search",
            "Search questions",
            (Param("query", "search words"), Param("limit", "max items", required=False, type=int, default=10),),
            (("stackexchange-api", "_so_search"),),
            live_test={"query": "python asyncio", "limit": 2},
        ),
        Action(
            "read",
            "Read a question and its answers",
            (Param("target", "question link or id"),),
            (("stackexchange-api", "_so_read"),),
            live_test={"target": "https://stackoverflow.com/questions/11227809"},
        ),
    )

    def can_handle(self, url: str) -> bool:
        from agent_reach.utils.url import host_matches

        return host_matches(url, "stackoverflow.com") and ("/questions/" in url or "/q/" in url)

    # ------------------------------------------------------------------ #
    # Unified entry backends
    # ------------------------------------------------------------------ #

    def _so_search(self, *, query: str, limit: int = 10, timeout: float) -> list:
        q = str(query or "").strip()
        if not q:
            raise ReachError(BAD_INPUT, "query must not be empty")
        size = max(1, min(int(limit or 10), _MAX_LIMIT))
        data = _get_json(
            _api_url(
                "/search/advanced",
                order="desc",
                sort="relevance",
                q=q,
                pagesize=size,
                filter="withbody",
            ),
            timeout=timeout,
        )
        questions = [x for x in (data.get("items") or []) if isinstance(x, dict)][:size]
        if not questions:
            raise ReachError(NOT_FOUND, f"no Stack Overflow questions match: {q}")
        items = [
            _question_item(x, text=_html_to_text(x.get("body")), raw=_question_raw(x))
            for x in questions
        ]
        return _with_backoff(items, data)

    def _so_read(self, *, target: str, timeout: float) -> list:
        qid = _parse_question_id(target)
        qdata = _get_json(_api_url(f"/questions/{qid}", filter="withbody"), timeout=timeout)
        questions = [x for x in (qdata.get("items") or []) if isinstance(x, dict)]
        if not questions:
            raise ReachError(NOT_FOUND, f"Stack Overflow question not found: {qid}")
        question = questions[0]
        adata = _get_json(
            _api_url(
                f"/questions/{qid}/answers",
                order="desc",
                sort="votes",
                filter="withbody",
                pagesize=30,
            ),
            timeout=timeout,
        )
        answers = sorted(
            (a for a in (adata.get("items") or []) if isinstance(a, dict)),
            key=_answer_sort_key,
        )
        parts = [_html_to_text(question.get("body"))]
        for a in answers:
            label = f"score {a.get('score', 0)}" + (", accepted" if a.get("is_accepted") else "")
            parts.append(f"--- Answer by {_owner(a) or 'unknown'} ({label}) ---\n{_html_to_text(a.get('body'))}")
        raw = _question_raw(question)
        raw["answers"] = [
            {
                "answer_id": a.get("answer_id"),
                "score": a.get("score"),
                "is_accepted": bool(a.get("is_accepted")),
                "author": _owner(a),
            }
            for a in answers
        ]
        item = _question_item(question, text="\n\n".join(p for p in parts if p), raw=raw)
        backoff = adata.get("backoff", qdata.get("backoff"))
        return _with_backoff([item], {"backoff": backoff})
