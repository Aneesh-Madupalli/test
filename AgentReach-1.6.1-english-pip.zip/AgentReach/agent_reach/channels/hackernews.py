# -*- coding: utf-8 -*-
"""Hacker News — public Algolia search API: stories, front page, a story with its comments."""

import html
import json
import re
from typing import Any, Optional
from urllib.parse import parse_qs, urlencode, urlsplit

from agent_reach.runtime.result import (
    BAD_INPUT,
    NOT_FOUND,
    UPSTREAM_BROKEN,
    ReachError,
    make_item,
    unix_to_iso,
)
from agent_reach.runtime.run import http_request

from .base import Action, Channel, Param

_API_BASE = "https://hn.algolia.com/api/v1"
_API_HOST = "hn.algolia.com"
_HN_ITEM_URL = "https://news.ycombinator.com/item?id="
_MAX_LIMIT = 100
_LIST_MAX_BYTES = 4 * 1024 * 1024
_READ_MAX_BYTES = 16 * 1024 * 1024
_MAX_COMMENTS = 300
_MAX_TEXT_CHARS = 200_000
_HN_HOSTS = {"news.ycombinator.com", "www.news.ycombinator.com"}

_TAG_RE = re.compile(r"<[^>]+>")
_P_RE = re.compile(r"<p\s*/?>", re.IGNORECASE)
_BR_RE = re.compile(r"<br\s*/?>", re.IGNORECASE)


def _validate_api_url(url: str) -> None:
    """Allow only the public Algolia HN HTTPS API."""
    try:
        parsed = urlsplit(url)
        port = parsed.port
    except ValueError as exc:
        raise ReachError(BAD_INPUT, "invalid Hacker News API URL") from exc
    if (
        parsed.scheme.lower() != "https"
        or (parsed.hostname or "").lower() != _API_HOST
        or port not in {None, 443}
        or parsed.username is not None
        or parsed.password is not None
        or not parsed.path.startswith("/api/v1/")
    ):
        raise ReachError(BAD_INPUT, "only the Algolia Hacker News HTTPS API is allowed")


def _api_url(path: str, **params: Any) -> str:
    query = f"?{urlencode(params)}" if params else ""
    return f"{_API_BASE}{path}{query}"


def _get_json(url: str, *, timeout: float, max_bytes: int = _LIST_MAX_BYTES) -> Any:
    _validate_api_url(url)
    body = http_request(url, timeout=timeout, max_bytes=max_bytes)
    try:
        return json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise ReachError(UPSTREAM_BROKEN, "Hacker News API returned invalid JSON") from exc


def _strip_html(text: Optional[str]) -> str:
    """Turn HN comment HTML into plain text; <p> becomes a paragraph break."""
    if not text:
        return ""
    out = _P_RE.sub("\n\n", text)
    out = _BR_RE.sub("\n", out)
    out = _TAG_RE.sub("", out)
    return html.unescape(out).strip()


def _clamp_limit(limit: Any) -> int:
    try:
        value = int(limit)
    except (TypeError, ValueError) as exc:
        raise ReachError(BAD_INPUT, "limit must be an integer") from exc
    return max(1, min(value, _MAX_LIMIT))


def _discussion_url(item_id: Any) -> str:
    return f"{_HN_ITEM_URL}{item_id}"


def _parse_item_id(target: str) -> int:
    """Accept an item id or a news.ycombinator.com/item?id=<id> link."""
    t = str(target or "").strip()
    if t.isdigit():
        return int(t)
    candidate = t if "://" in t else f"https://{t}"
    try:
        parsed = urlsplit(candidate)
        host = (parsed.hostname or "").lower()
        path = parsed.path.rstrip("/")
        query = parsed.query
    except ValueError:
        host, path, query = "", "", ""
    if host in _HN_HOSTS and path == "/item":
        ids = parse_qs(query).get("id") or []
        if ids and ids[0].strip().isdigit():
            return int(ids[0].strip())
    raise ReachError(
        BAD_INPUT,
        "target must be a Hacker News item link (https://news.ycombinator.com/item?id=<id>) or id",
    )


def _hit_item(hit: dict) -> dict:
    item_id = hit.get("objectID")
    discussion = _discussion_url(item_id)
    return make_item(
        title=hit.get("title") or hit.get("story_title"),
        url=hit.get("url") or discussion,
        author=hit.get("author"),
        published_at=unix_to_iso(hit.get("created_at_i")),
        text=_strip_html(hit.get("story_text")) or None,
        raw={
            "id": item_id,
            "points": hit.get("points"),
            "num_comments": hit.get("num_comments"),
            "discussion_url": discussion,
        },
    )


def _hits(data: Any) -> list:
    if not isinstance(data, dict) or not isinstance(data.get("hits"), list):
        raise ReachError(UPSTREAM_BROKEN, "unexpected Hacker News API response")
    return [h for h in data["hits"] if isinstance(h, dict)]


def _flatten_comments(story: dict) -> tuple[list[str], int, bool]:
    """Depth-first comment lines, capped by count and total characters."""
    lines: list[str] = []
    count = 0
    chars = 0
    truncated = False
    stack: list[tuple[dict, int]] = [
        (c, 0) for c in reversed(story.get("children") or []) if isinstance(c, dict)
    ]
    while stack:
        node, depth = stack.pop()
        text = _strip_html(node.get("text"))
        if text or node.get("author"):
            if count >= _MAX_COMMENTS:
                truncated = True
                break
            indent = "  " * depth
            body = text.replace("\n", "\n" + indent + "  ") if text else "[deleted]"
            line = f"{indent}@{node.get('author') or '[deleted]'}: {body}"
            if chars + len(line) > _MAX_TEXT_CHARS:
                truncated = True
                break
            lines.append(line)
            count += 1
            chars += len(line) + 1
        children = [c for c in (node.get("children") or []) if isinstance(c, dict)]
        stack.extend((c, depth + 1) for c in reversed(children))
    return lines, count, truncated


class HackerNewsChannel(Channel):
    name = "hackernews"
    description = "Hacker News stories, front page and comment threads"

    level = "default"
    actions = (
        Action(
            "search",
            "Search stories",
            (Param("query", "search words"), Param("limit", "max items", required=False, type=int, default=10),),
            (("algolia-api", "_hn_search"),),
            live_test={"query": "python", "limit": 2},
        ),
        Action(
            "top",
            "Current front-page stories",
            (Param("limit", "max items", required=False, type=int, default=10),),
            (("algolia-api", "_hn_top"),),
            live_test={"limit": 3},
        ),
        Action(
            "read",
            "Read a story and its comments",
            (Param("target", "item link (news.ycombinator.com/item?id=...) or id"),),
            (("algolia-api", "_hn_read"),),
            live_test={"target": "https://news.ycombinator.com/item?id=1"},
        ),
    )

    def can_handle(self, url: str) -> bool:
        from agent_reach.utils.url import host_matches

        return host_matches(url, "news.ycombinator.com") and "id=" in url

    # ------------------------------------------------------------------ #
    # Unified entry backends
    # ------------------------------------------------------------------ #

    def _hn_search(self, *, query: str, limit: int = 10, timeout: float) -> list:
        query = str(query or "").strip()
        if not query:
            raise ReachError(BAD_INPUT, "query must not be empty")
        n = _clamp_limit(limit)
        data = _get_json(_api_url("/search", query=query, tags="story", hitsPerPage=n), timeout=timeout)
        hits = _hits(data)
        if not hits:
            raise ReachError(NOT_FOUND, "nothing found")
        return [_hit_item(h) for h in hits[:n]]

    def _hn_top(self, *, limit: int = 10, timeout: float) -> list:
        n = _clamp_limit(limit)
        data = _get_json(_api_url("/search", tags="front_page", hitsPerPage=n), timeout=timeout)
        hits = _hits(data)
        if not hits:
            raise ReachError(NOT_FOUND, "nothing found")
        return [_hit_item(h) for h in hits[:n]]

    def _hn_read(self, *, target: str, timeout: float) -> list:
        item_id = _parse_item_id(target)
        data = _get_json(_api_url(f"/items/{item_id}"), timeout=timeout, max_bytes=_READ_MAX_BYTES)
        if not isinstance(data, dict) or (not data.get("title") and not data.get("text")):
            raise ReachError(NOT_FOUND, f"Hacker News item not found: {item_id}")
        story = {k: v for k, v in data.items() if k != "children"}
        discussion = _discussion_url(data.get("id") or item_id)
        story_text = _strip_html(data.get("text"))
        lines, count, truncated = _flatten_comments(data)
        parts = [story_text] if story_text else []
        if lines:
            parts.append("--- comments ---")
            parts.append("\n".join(lines))
        if truncated:
            parts.append(
                f"[truncated: showing the first {count} comments; "
                f"cap is {_MAX_COMMENTS} comments / {_MAX_TEXT_CHARS} characters]"
            )
        return [
            make_item(
                title=data.get("title"),
                url=data.get("url") or discussion,
                author=data.get("author"),
                published_at=unix_to_iso(data.get("created_at_i")),
                text="\n\n".join(parts) or None,
                raw={
                    "story": {**story, "discussion_url": discussion},
                    "comment_count": count,
                    "truncated": truncated,
                },
            )
        ]
