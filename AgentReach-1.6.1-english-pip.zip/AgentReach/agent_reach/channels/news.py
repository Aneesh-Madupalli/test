# -*- coding: utf-8 -*-
"""News — Google News RSS: headlines for a topic, top stories."""

from __future__ import annotations

import datetime as _dt
import email.utils
import html
import re
import xml.etree.ElementTree as ET
from typing import Optional
from urllib.parse import urlencode, urlsplit

from agent_reach.runtime.result import BAD_INPUT, NOT_FOUND, UPSTREAM_BROKEN, ReachError, make_item
from agent_reach.runtime.run import http_request

from .base import Action, Channel, Param

_HOST = "news.google.com"
_BASE = f"https://{_HOST}"
_MAX_LIMIT = 100
_EDITION_RE = re.compile(r"^[a-z]{2}(-[A-Z]{2})?$")


def _parse_edition(lang: object) -> tuple[str, str, str]:
    """Normalise an edition like ``en-us`` / ``de`` to ``(hl, gl, lang)``, e.g. ``("en-US", "US", "en")``."""
    raw = str(lang if lang is not None else "").strip()
    parts = raw.split("-")
    if len(parts) == 1:
        candidate = parts[0].lower()
    elif len(parts) == 2:
        candidate = f"{parts[0].lower()}-{parts[1].upper()}"
    else:
        candidate = raw
    if not _EDITION_RE.match(candidate):
        raise ReachError(BAD_INPUT, f"lang must be an edition like en-US, en-GB or de-DE, got {raw!r}")
    language, _, region = candidate.partition("-")
    region = region or language.upper()
    return f"{language}-{region}", region, language


def _edition_params(lang: object) -> dict[str, str]:
    hl, gl, language = _parse_edition(lang)
    return {"hl": hl, "gl": gl, "ceid": f"{gl}:{language}"}


def _search_url(query: str, lang: object) -> str:
    return f"{_BASE}/rss/search?{urlencode({'q': query, **_edition_params(lang)})}"


def _top_url(lang: object) -> str:
    return f"{_BASE}/rss?{urlencode(_edition_params(lang))}"


def _validate_url(url: str) -> None:
    """Allow only HTTPS requests to news.google.com."""
    try:
        parsed = urlsplit(url)
        port = parsed.port
    except ValueError as exc:
        raise ValueError("invalid Google News URL") from exc
    if (
        parsed.scheme.lower() != "https"
        or (parsed.hostname or "").lower() != _HOST
        or port not in {None, 443}
        or parsed.username is not None
        or parsed.password is not None
        or not parsed.path.startswith("/rss")
    ):
        raise ValueError("only the Google News HTTPS RSS feed is allowed")


def _to_iso(value: Optional[str]) -> Optional[str]:
    if not value:
        return None
    try:
        parsed = email.utils.parsedate_to_datetime(value.strip())
    except (TypeError, ValueError, IndexError):
        return None
    if parsed is None:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=_dt.timezone.utc)
    return parsed.astimezone(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


_BREAK_RE = re.compile(r"<\s*(?:br\s*/?|/\s*li|/\s*p|/\s*div)\s*>", re.IGNORECASE)
_TAG_RE = re.compile(r"<[^>]*>")
_SPACE_RE = re.compile(r"\s+")


def _html_to_text(snippet: Optional[str]) -> Optional[str]:
    """Strip tags and entities; each ``<li>`` (or line break) becomes its own line."""
    if not snippet:
        return None
    marked = _BREAK_RE.sub("\n", snippet)
    plain = html.unescape(_TAG_RE.sub(" ", marked))
    lines = [_SPACE_RE.sub(" ", line).strip() for line in plain.split("\n")]
    text = "\n".join(line for line in lines if line)
    return text or None


def _strip_source(title: str, source: str) -> str:
    suffix = f" - {source}"
    if source and title.endswith(suffix) and len(title) > len(suffix):
        return title[: -len(suffix)].rstrip()
    return title


def _parse_feed(body: bytes, edition: str, limit: int) -> list:
    try:
        root = ET.fromstring(body)
    except ET.ParseError as exc:
        raise ReachError(UPSTREAM_BROKEN, "Google News did not return an RSS feed") from exc
    channel = root.find("channel") if root.tag == "rss" else None
    if channel is None:
        raise ReachError(UPSTREAM_BROKEN, "Google News did not return an RSS feed")
    items = []
    for node in channel.findall("item")[:limit]:
        source_el = node.find("source")
        source = (source_el.text or "").strip() if source_el is not None else ""
        source_url = source_el.get("url") if source_el is not None else None
        title = (node.findtext("title") or "").strip()
        items.append(
            make_item(
                title=_strip_source(title, source),
                url=(node.findtext("link") or "").strip(),
                author=source,
                published_at=_to_iso(node.findtext("pubDate")),
                text=_html_to_text(node.findtext("description")),
                raw={
                    "source": source or None,
                    "source_url": source_url,
                    "guid": (node.findtext("guid") or "").strip() or None,
                    "edition": edition,
                },
            )
        )
    if not items:
        raise ReachError(NOT_FOUND, "nothing found")
    return items


def _clamp_limit(limit: object) -> int:
    try:
        value = int(limit)  # type: ignore[call-overload]
    except (TypeError, ValueError) as exc:
        raise ReachError(BAD_INPUT, "limit must be an integer") from exc
    if value < 1:
        raise ReachError(BAD_INPUT, "limit must be at least 1")
    return min(value, _MAX_LIMIT)


def _fetch(url: str, timeout: float) -> bytes:
    _validate_url(url)
    return http_request(url, timeout=timeout)


class NewsChannel(Channel):
    name = "news"
    description = "Google News headlines"

    level = "default"
    actions = (
        Action(
            "search",
            "Search news headlines",
            (Param("query", "topic, company or phrase"), Param("lang", "edition, e.g. en-US, en-GB, de-DE", required=False, default="en-US"), Param("limit", "max items", required=False, type=int, default=10),),
            (("google-news-rss", "_news_search"),),
            live_test={"query": "eli lilly", "limit": 3},
        ),
        Action(
            "top",
            "Top stories",
            (Param("lang", "edition, e.g. en-US, en-GB, de-DE", required=False, default="en-US"), Param("limit", "max items", required=False, type=int, default=10),),
            (("google-news-rss", "_news_top"),),
            live_test={"limit": 3},
        ),
    )

    def can_handle(self, url: str) -> bool:
        return False  # news.google.com links are redirects; the web channel reads them

    # ------------------------------------------------------------------ #
    # Unified entry backends
    # ------------------------------------------------------------------ #

    def _news_search(self, *, query: str, lang: str = "en-US", limit: int = 10, timeout: float) -> list:
        q = str(query or "").strip()
        if not q:
            raise ReachError(BAD_INPUT, "query must not be empty")
        edition = _parse_edition(lang)[0]
        n = _clamp_limit(limit)
        return _parse_feed(_fetch(_search_url(q, lang), timeout), edition, n)

    def _news_top(self, *, lang: str = "en-US", limit: int = 10, timeout: float) -> list:
        edition = _parse_edition(lang)[0]
        n = _clamp_limit(limit)
        return _parse_feed(_fetch(_top_url(lang), timeout), edition, n)
