# -*- coding: utf-8 -*-
"""PubMed — NCBI E-utilities: search biomedical literature, read an abstract."""

import json
import re
import xml.etree.ElementTree as ET
from typing import Any, Optional
from urllib.parse import urlencode, urlsplit

from agent_reach.runtime.result import BAD_INPUT, NOT_FOUND, UPSTREAM_BROKEN, ReachError, make_item
from agent_reach.runtime.run import http_request

from .base import Action, Channel, Param

_HOST = "eutils.ncbi.nlm.nih.gov"
_BASE = f"https://{_HOST}/entrez/eutils"
_TOOL = "agent-reach"
_MAX_LIMIT = 100

_MONTHS = {
    m: i
    for i, m in enumerate(
        ("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"), start=1
    )
}
_DATE_RE = re.compile(r"^(\d{4})(?:\s+([A-Za-z]{3}|\d{1,2})(?:\s+(\d{1,2}))?)?$")
_PMID_RE = re.compile(r"^(?:PMID\s*:?\s*)?(\d{1,10})$", re.IGNORECASE)
_PUBMED_URL_RE = re.compile(
    r"^(?:https?://)?(?:www\.)?pubmed\.ncbi\.nlm\.nih\.gov/(\d{1,10})/?(?:[?#].*)?$", re.IGNORECASE
)


def _eutils_url(endpoint: str, **params: Any) -> str:
    """Build an E-utilities URL; caller values cannot alter the query structure."""
    params["tool"] = _TOOL
    return f"{_BASE}/{endpoint}?{urlencode(params)}"


def _validate_url(url: str) -> None:
    """Allow only HTTPS to the NCBI E-utilities host."""
    try:
        parsed = urlsplit(url)
        port = parsed.port
    except ValueError as exc:
        raise ValueError("invalid E-utilities URL") from exc
    if (
        parsed.scheme.lower() != "https"
        or (parsed.hostname or "").lower() != _HOST
        or port not in {None, 443}
        or parsed.username is not None
        or parsed.password is not None
        or not parsed.path.startswith("/entrez/eutils/")
    ):
        raise ValueError("only the NCBI E-utilities HTTPS API is allowed")


def _fetch(url: str, timeout: float) -> bytes:
    _validate_url(url)
    return http_request(url, timeout=timeout)


def _check_error(data: Any) -> None:
    """Raise UPSTREAM_BROKEN for an E-utilities JSON error payload."""
    if not isinstance(data, dict):
        raise ReachError(UPSTREAM_BROKEN, "PubMed returned an unexpected response")
    for container in (data, data.get("esearchresult"), data.get("result")):
        if isinstance(container, dict):
            for key in ("error", "ERROR"):
                if container.get(key):
                    raise ReachError(UPSTREAM_BROKEN, f"PubMed error: {container[key]}")


def _fetch_json(url: str, timeout: float) -> dict:
    body = _fetch(url, timeout)
    try:
        data = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise ReachError(UPSTREAM_BROKEN, "PubMed returned malformed JSON") from exc
    _check_error(data)
    return data


def _normalize_date(value: Any) -> Optional[str]:
    """Turn 'YYYY Mon DD' / 'YYYY Mon' / 'YYYY' into ISO dates; anything else is None."""
    if not isinstance(value, str):
        return None
    match = _DATE_RE.match(value.strip())
    if not match:
        return None
    year, month_text, day_text = match.groups()
    if month_text is None:
        return year
    month = int(month_text) if month_text.isdigit() else _MONTHS.get(month_text.lower())
    if not month or not 1 <= month <= 12:
        return None
    if day_text is None:
        return f"{year}-{month:02d}"
    day = int(day_text)
    if not 1 <= day <= 31:
        return None
    return f"{year}-{month:02d}-{day:02d}"


def _format_authors(names: list) -> Optional[str]:
    names = [n for n in names if n]
    if not names:
        return None
    text = ", ".join(names[:3])
    return f"{text} et al." if len(names) > 3 else text


def _parse_pmid(target: Any) -> str:
    """Accept a PMID, 'PMID: 123', or a pubmed.ncbi.nlm.nih.gov/<pmid> link."""
    t = str(target or "").strip()
    match = _PMID_RE.match(t) or _PUBMED_URL_RE.match(t)
    if match:
        return str(int(match.group(1)))
    raise ReachError(BAD_INPUT, "target must be a PMID or a https://pubmed.ncbi.nlm.nih.gov/<pmid>/ link")


def _article_url(pmid: str) -> str:
    return f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/"


def _text(el: Optional[ET.Element]) -> str:
    return "".join(el.itertext()).strip() if el is not None else ""


def _summary_item(pmid: str, doc: dict, count: Any) -> dict:
    authors = [a.get("name") for a in doc.get("authors") or [] if isinstance(a, dict) and a.get("name")]
    doi = next(
        (a.get("value") for a in doc.get("articleids") or [] if isinstance(a, dict) and a.get("idtype") == "doi"),
        None,
    )
    journal = doc.get("source") or doc.get("fulljournalname")
    pubdate = doc.get("pubdate") or doc.get("epubdate") or ""
    lines = [line for line in (journal, pubdate, f"DOI: {doi}" if doi else None) if line]
    raw: dict = {"pmid": pmid, "doi": doi, "journal": journal, "authors": authors, "pubdate": pubdate}
    if count is not None:
        raw["count"] = count
    return make_item(
        title=doc.get("title"),
        url=_article_url(pmid),
        author=_format_authors(authors),
        published_at=_normalize_date(doc.get("pubdate")) or _normalize_date(doc.get("epubdate")),
        text="\n".join(lines),
        raw=raw,
    )


def _pub_date(article: ET.Element) -> tuple:
    """Return (display text, ISO date or None) for the journal PubDate."""
    pub = article.find("./Journal/JournalIssue/PubDate")
    if pub is None:
        return "", None
    medline = pub.findtext("MedlineDate")
    if medline:
        return medline.strip(), _normalize_date(medline)
    parts = [pub.findtext(tag) for tag in ("Year", "Month", "Day")]
    text = " ".join(p.strip() for p in parts if p and p.strip())
    return text, _normalize_date(text)


def _parse_article(root: ET.Element, pmid: str) -> dict:
    node = root.find(".//PubmedArticle")
    if node is None:
        raise ReachError(NOT_FOUND, f"PubMed article not found: {pmid}")
    citation = node.find("MedlineCitation")
    article = citation.find("Article") if citation is not None else None
    if citation is None or article is None:
        raise ReachError(UPSTREAM_BROKEN, "PubMed returned an article without citation data")
    pmid = (citation.findtext("PMID") or pmid).strip()

    authors: list = []
    for author in article.findall("./AuthorList/Author"):
        collective = _text(author.find("CollectiveName"))
        if collective:
            authors.append(collective)
            continue
        name = " ".join(p for p in (author.findtext("LastName"), author.findtext("Initials")) if p)
        if name:
            authors.append(name)

    doi = None
    for aid in node.findall("./PubmedData/ArticleIdList/ArticleId"):
        if aid.get("IdType") == "doi" and aid.text:
            doi = aid.text.strip()
            break
    if doi is None:
        for eloc in article.findall("ELocationID"):
            if eloc.get("EIdType") == "doi" and eloc.text:
                doi = eloc.text.strip()
                break

    sections = []
    for abstract in article.findall("./Abstract/AbstractText"):
        body = _text(abstract)
        if not body:
            continue
        label = (abstract.get("Label") or "").strip()
        sections.append(f"{label}: {body}" if label else body)

    journal = _text(article.find("./Journal/Title")) or None
    date_text, iso = _pub_date(article)
    return make_item(
        title=_text(article.find("ArticleTitle")),
        url=_article_url(pmid),
        author=_format_authors(authors),
        published_at=iso,
        text="\n\n".join(sections) or "No abstract available.",
        raw={
            "pmid": pmid,
            "doi": doi,
            "journal": journal,
            "pubdate": date_text,
            "authors": authors,
            "mesh_terms": [_text(d) for d in citation.findall("./MeshHeadingList/MeshHeading/DescriptorName")],
            "publication_types": [_text(p) for p in article.findall("./PublicationTypeList/PublicationType")],
        },
    )


class PubMedChannel(Channel):
    name = "pubmed"
    description = "PubMed biomedical papers and abstracts"

    level = "default"
    actions = (
        Action(
            "search",
            "Search papers",
            (Param("query", "PubMed query, e.g. semaglutide AND obesity"), Param("limit", "max items", required=False, type=int, default=10),),
            (("eutils", "_pm_search"),),
            live_test={"query": "semaglutide", "limit": 2},
        ),
        Action(
            "read",
            "Read a paper's abstract",
            (Param("target", "PMID or pubmed.ncbi.nlm.nih.gov link"),),
            (("eutils", "_pm_read"),),
            live_test={"target": "33567185"},
        ),
    )

    def can_handle(self, url: str) -> bool:
        from agent_reach.utils.url import host_matches

        return host_matches(url, "pubmed.ncbi.nlm.nih.gov")

    # ------------------------------------------------------------------ #
    # Unified entry backends
    # ------------------------------------------------------------------ #

    def _pm_search(self, *, query: str, limit: int = 10, timeout: float) -> list:
        query = str(query or "").strip()
        if not query:
            raise ReachError(BAD_INPUT, "query must not be empty")
        limit = max(1, min(int(limit), _MAX_LIMIT))
        found = _fetch_json(
            _eutils_url("esearch.fcgi", db="pubmed", term=query, retmax=limit, retmode="json", sort="relevance"),
            timeout,
        )
        result = found.get("esearchresult") or {}
        ids = [str(i) for i in result.get("idlist") or [] if str(i).isdigit()][:limit]
        if not ids:
            raise ReachError(NOT_FOUND, f"No PubMed results for: {query}")
        summary = _fetch_json(_eutils_url("esummary.fcgi", db="pubmed", id=",".join(ids), retmode="json"), timeout)
        docs = summary.get("result") or {}
        order = [str(u) for u in docs.get("uids") or ids]
        items: list = []
        for pmid in order:
            doc = docs.get(pmid)
            if not isinstance(doc, dict) or doc.get("error"):
                continue
            items.append(_summary_item(pmid, doc, result.get("count") if not items else None))
        if not items:
            raise ReachError(NOT_FOUND, f"No PubMed results for: {query}")
        return items

    def _pm_read(self, *, target: str, timeout: float) -> list:
        pmid = _parse_pmid(target)
        body = _fetch(_eutils_url("efetch.fcgi", db="pubmed", id=pmid, rettype="abstract", retmode="xml"), timeout)
        try:
            root = ET.fromstring(body)
        except ET.ParseError as exc:
            raise ReachError(UPSTREAM_BROKEN, "PubMed returned malformed XML") from exc
        return [_parse_article(root, pmid)]
