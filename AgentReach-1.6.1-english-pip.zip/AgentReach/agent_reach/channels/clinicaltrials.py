# -*- coding: utf-8 -*-
"""ClinicalTrials.gov — public API v2: search clinical studies, read one study."""

import json
import re
import urllib.error
from typing import Any, Optional
from urllib.parse import quote, urlencode, urlsplit

from agent_reach.runtime.result import BAD_INPUT, NOT_FOUND, ReachError, make_item
from agent_reach.runtime.run import http_request

from .base import Action, Channel, Param

_API_BASE = "https://clinicaltrials.gov/api/v2"
_STUDY_URL = "https://clinicaltrials.gov/study/"
_MAX_LIMIT = 100
_SUMMARY_CHARS = 600
_MAX_LOCATIONS = 50

_STATUSES = frozenset(
    {
        "RECRUITING",
        "NOT_YET_RECRUITING",
        "ACTIVE_NOT_RECRUITING",
        "ENROLLING_BY_INVITATION",
        "COMPLETED",
        "SUSPENDED",
        "TERMINATED",
        "WITHDRAWN",
        "UNKNOWN",
    }
)

_SEARCH_FIELDS = ",".join(
    (
        "protocolSection.identificationModule",
        "protocolSection.statusModule",
        "protocolSection.sponsorCollaboratorsModule.leadSponsor",
        "protocolSection.descriptionModule.briefSummary",
        "protocolSection.conditionsModule.conditions",
        "protocolSection.designModule",
        "protocolSection.armsInterventionsModule.interventions",
    )
)

_NCT_RE = re.compile(r"^NCT\d{8}$", re.IGNORECASE)
_NCT_URL_RE = re.compile(
    r"^(?:https?://)?(?:www\.)?clinicaltrials\.gov/(?:study|ct2/show)/(NCT\d{8})(?:[/?#].*)?$",
    re.IGNORECASE,
)
_DATE_RE = re.compile(r"^\d{4}-\d{2}(?:-\d{2})?$")


def _validate_api_url(url: str) -> None:
    """Allow only the public ClinicalTrials.gov HTTPS API."""
    try:
        parsed = urlsplit(url)
        port = parsed.port
    except ValueError as exc:
        raise ValueError("invalid ClinicalTrials.gov API URL") from exc
    if (
        parsed.scheme.lower() != "https"
        or (parsed.hostname or "").lower() != "clinicaltrials.gov"
        or port not in {None, 443}
        or parsed.username is not None
        or parsed.password is not None
        or not parsed.path.startswith("/api/v2/")
    ):
        raise ValueError("only the ClinicalTrials.gov HTTPS API is allowed")


def _get_json(url: str, timeout: float) -> Any:
    _validate_api_url(url)
    body = http_request(url, timeout=timeout, headers={"Accept": "application/json"})
    return json.loads(body.decode("utf-8"))


def _parse_nct_id(target: str) -> str:
    """Accept NCT01234567 or a clinicaltrials.gov/study/ or /ct2/show/ link."""
    t = str(target or "").strip()
    if _NCT_RE.match(t):
        return t.upper()
    match = _NCT_URL_RE.match(t)
    if match:
        return match.group(1).upper()
    raise ReachError(
        BAD_INPUT,
        "target must be an NCT id (NCT + 8 digits) or a https://clinicaltrials.gov/study/<NCT id> link",
    )


def _parse_status(status: Optional[str]) -> Optional[str]:
    if status is None or not str(status).strip():
        return None
    values = [s.strip().upper().replace(" ", "_").replace("-", "_") for s in str(status).split(",")]
    values = [v for v in values if v]
    bad = [v for v in values if v not in _STATUSES]
    if bad or not values:
        raise ReachError(
            BAD_INPUT,
            f"unknown status {', '.join(bad) or status!r}; use one of: {', '.join(sorted(_STATUSES))}",
        )
    return ",".join(values)


def _date(struct: Any) -> Optional[str]:
    value = (struct or {}).get("date") if isinstance(struct, dict) else None
    if isinstance(value, str) and _DATE_RE.match(value.strip()):
        return value.strip()
    return None


def _mod(protocol: dict, name: str) -> dict:
    value = protocol.get(name)
    return value if isinstance(value, dict) else {}


def _list(value: Any) -> list:
    return value if isinstance(value, list) else []


class _Study:
    """Tolerant accessors over one study's protocolSection."""

    def __init__(self, protocol: Any):
        self.p = protocol if isinstance(protocol, dict) else {}
        self.ident = _mod(self.p, "identificationModule")
        self.status_mod = _mod(self.p, "statusModule")
        self.sponsor_mod = _mod(self.p, "sponsorCollaboratorsModule")
        self.desc = _mod(self.p, "descriptionModule")
        self.cond = _mod(self.p, "conditionsModule")
        self.design = _mod(self.p, "designModule")
        self.arms = _mod(self.p, "armsInterventionsModule")
        self.elig = _mod(self.p, "eligibilityModule")
        self.contacts = _mod(self.p, "contactsLocationsModule")
        self.outcomes = _mod(self.p, "outcomesModule")

    @property
    def nct_id(self) -> Optional[str]:
        return self.ident.get("nctId")

    @property
    def url(self) -> Optional[str]:
        return f"{_STUDY_URL}{quote(self.nct_id, safe='')}" if self.nct_id else None

    @property
    def status(self) -> Optional[str]:
        return self.status_mod.get("overallStatus")

    @property
    def sponsor(self) -> Optional[str]:
        lead = self.sponsor_mod.get("leadSponsor")
        return lead.get("name") if isinstance(lead, dict) else None

    @property
    def phases(self) -> list:
        return [str(x) for x in _list(self.design.get("phases"))]

    @property
    def conditions(self) -> list:
        return [str(x) for x in _list(self.cond.get("conditions"))]

    @property
    def interventions(self) -> list:
        out = []
        for i in _list(self.arms.get("interventions")):
            if not isinstance(i, dict) or not i.get("name"):
                continue
            out.append(f"{i['name']} ({i['type']})" if i.get("type") else str(i["name"]))
        return out

    @property
    def enrollment(self) -> Any:
        info = self.design.get("enrollmentInfo")
        return info.get("count") if isinstance(info, dict) else None

    @property
    def start(self) -> Optional[str]:
        return _date(self.status_mod.get("startDateStruct"))

    @property
    def completion(self) -> Optional[str]:
        return _date(self.status_mod.get("completionDateStruct")) or _date(
            self.status_mod.get("primaryCompletionDateStruct")
        )

    def overview_lines(self) -> list:
        lines = []
        if self.status:
            lines.append(f"Status: {self.status}")
        if self.phases:
            lines.append(f"Phase: {', '.join(self.phases)}")
        if self.design.get("studyType"):
            lines.append(f"Study type: {self.design['studyType']}")
        if self.conditions:
            lines.append(f"Conditions: {'; '.join(self.conditions)}")
        if self.interventions:
            lines.append(f"Interventions: {'; '.join(self.interventions)}")
        if self.enrollment is not None:
            lines.append(f"Enrollment: {self.enrollment}")
        if self.start or self.completion:
            lines.append(f"Dates: {self.start or '?'} → {self.completion or '?'}")
        return lines


def _truncate(text: str, limit: int) -> str:
    text = " ".join(text.split())
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"


def _search_item(protocol: Any, total: Any = None, first: bool = False) -> dict:
    s = _Study(protocol)
    lines = s.overview_lines()
    summary = s.desc.get("briefSummary")
    if isinstance(summary, str) and summary.strip():
        lines.append("")
        lines.append(_truncate(summary, _SUMMARY_CHARS))
    raw: dict = {
        "nct_id": s.nct_id,
        "status": s.status,
        "phases": s.phases,
        "conditions": s.conditions,
        "interventions": s.interventions,
        "sponsor": s.sponsor,
    }
    if first:
        raw["totalCount"] = total
    return make_item(
        title=s.ident.get("briefTitle") or s.ident.get("officialTitle") or s.nct_id,
        url=s.url,
        author=s.sponsor,
        published_at=s.start,
        text="\n".join(lines).strip() or None,
        raw=raw,
    )


def _section(title: str, body: list) -> list:
    body = [b for b in body if b is not None and str(b).strip()]
    return [f"## {title}", *body, ""] if body else []


def _read_text(s: _Study) -> str:
    out: list = []
    header = [s.nct_id or ""]
    if s.ident.get("acronym"):
        header.append(f"({s.ident['acronym']})")
    out.append(" ".join(h for h in header if h))
    if s.ident.get("officialTitle"):
        out.append(f"Official title: {s.ident['officialTitle']}")
    if s.sponsor:
        out.append(f"Sponsor: {s.sponsor}")
    collabs = [str(c["name"]) for c in _list(s.sponsor_mod.get("collaborators")) if isinstance(c, dict) and c.get("name")]
    if collabs:
        out.append(f"Collaborators: {'; '.join(collabs)}")
    out.append("")

    sm = s.status_mod
    out += _section(
        "Status",
        [
            f"Overall status: {s.status}" if s.status else None,
            f"Start: {s.start}" if s.start else None,
            f"Primary completion: {_date(sm.get('primaryCompletionDateStruct'))}"
            if _date(sm.get("primaryCompletionDateStruct"))
            else None,
            f"Completion: {_date(sm.get('completionDateStruct'))}" if _date(sm.get("completionDateStruct")) else None,
            f"Last update posted: {_date(sm.get('lastUpdatePostDateStruct'))}"
            if _date(sm.get("lastUpdatePostDateStruct"))
            else None,
        ],
    )
    out += _section(
        "Design",
        [
            f"Study type: {s.design['studyType']}" if s.design.get("studyType") else None,
            f"Phase: {', '.join(s.phases)}" if s.phases else None,
            f"Enrollment: {s.enrollment}" if s.enrollment is not None else None,
        ],
    )
    keywords = [str(k) for k in _list(s.cond.get("keywords"))]
    out += _section(
        "Conditions",
        [f"- {c}" for c in s.conditions] + ([f"Keywords: {', '.join(keywords)}"] if keywords else []),
    )
    out += _section("Interventions", [f"- {i}" for i in s.interventions])
    outcomes = []
    for o in _list(s.outcomes.get("primaryOutcomes")):
        if isinstance(o, dict) and o.get("measure"):
            tf = f" [{o['timeFrame']}]" if o.get("timeFrame") else ""
            outcomes.append(f"- {o['measure']}{tf}")
    out += _section("Primary outcomes", outcomes)
    e = s.elig
    ages = " – ".join(x for x in (e.get("minimumAge"), e.get("maximumAge")) if x)
    out += _section(
        "Eligibility",
        [
            f"Sex: {e['sex']}" if e.get("sex") else None,
            f"Age: {ages}" if ages else None,
            str(e["eligibilityCriteria"]).strip() if e.get("eligibilityCriteria") else None,
        ],
    )
    locations = [loc for loc in _list(s.contacts.get("locations")) if isinstance(loc, dict)]
    loc_lines = []
    for loc in locations[:_MAX_LOCATIONS]:
        place = ", ".join(str(x) for x in (loc.get("facility"), loc.get("city"), loc.get("country")) if x)
        if not place:
            continue
        loc_lines.append(f"- {place}" + (f" ({loc['status']})" if loc.get("status") else ""))
    if len(locations) > _MAX_LOCATIONS:
        loc_lines.append(f"+{len(locations) - _MAX_LOCATIONS} more")
    out += _section("Locations", loc_lines)
    out += _section("Summary", [s.desc.get("briefSummary")])
    out += _section("Description", [s.desc.get("detailedDescription")])
    return "\n".join(out).strip()


class ClinicalTrialsChannel(Channel):
    name = "clinicaltrials"
    description = "ClinicalTrials.gov clinical studies"

    level = "default"
    actions = (
        Action(
            "search",
            "Search studies",
            (Param("query", "condition, drug or sponsor"), Param("status", "e.g. RECRUITING, COMPLETED (comma-separated)", required=False), Param("limit", "max items", required=False, type=int, default=10),),
            (("ctgov-api", "_ct_search"),),
            live_test={"query": "semaglutide", "limit": 2},
        ),
        Action(
            "read",
            "Read one study",
            (Param("target", "NCT id or clinicaltrials.gov/study link"),),
            (("ctgov-api", "_ct_read"),),
            live_test={"target": "NCT03548935"},
        ),
    )

    def can_handle(self, url: str) -> bool:
        from agent_reach.utils.url import host_matches

        return host_matches(url, "clinicaltrials.gov") and "NCT" in url.upper()

    # ------------------------------------------------------------------ #
    # Unified entry backends
    # ------------------------------------------------------------------ #

    def _ct_search(
        self, *, query: str, timeout: float, limit: int = 10, status: Optional[str] = None
    ) -> list:
        q = str(query or "").strip()
        if not q:
            raise ReachError(BAD_INPUT, "query must not be empty")
        size = max(1, min(int(limit or 10), _MAX_LIMIT))
        params = {
            "query.term": q,
            "pageSize": size,
            "format": "json",
            "countTotal": "true",
            "fields": _SEARCH_FIELDS,
        }
        statuses = _parse_status(status)
        if statuses:
            params["filter.overallStatus"] = statuses
        data = _get_json(f"{_API_BASE}/studies?{urlencode(params)}", timeout)
        studies = _list(data.get("studies")) if isinstance(data, dict) else []
        if not studies:
            raise ReachError(NOT_FOUND, f"no ClinicalTrials.gov studies match: {q}")
        total = data.get("totalCount")
        return [
            _search_item((st or {}).get("protocolSection") if isinstance(st, dict) else None, total, i == 0)
            for i, st in enumerate(studies[:size])
        ]

    def _ct_read(self, *, target: str, timeout: float) -> list:
        nct = _parse_nct_id(target)
        url = f"{_API_BASE}/studies/{quote(nct, safe='')}?{urlencode({'format': 'json'})}"
        try:
            data = _get_json(url, timeout)
        except urllib.error.HTTPError as exc:
            # The API answers 400 ("incorrect format") for well-formed ids it does not
            # recognise (e.g. NCT00000000) and 404 for unknown ones: both mean no study.
            if exc.code in (400, 404):
                raise ReachError(NOT_FOUND, f"ClinicalTrials.gov study not found: {nct}") from exc
            raise
        protocol = data.get("protocolSection") if isinstance(data, dict) else None
        if not isinstance(protocol, dict) or not protocol:
            raise ReachError(NOT_FOUND, f"ClinicalTrials.gov study not found: {nct}")
        s = _Study(protocol)
        raw = dict(protocol)
        raw["hasResults"] = data.get("hasResults")
        return [
            make_item(
                title=s.ident.get("briefTitle") or s.ident.get("officialTitle") or nct,
                url=s.url or f"{_STUDY_URL}{quote(nct, safe='')}",
                author=s.sponsor,
                published_at=s.start,
                text=_read_text(s),
                raw=raw,
            )
        ]
