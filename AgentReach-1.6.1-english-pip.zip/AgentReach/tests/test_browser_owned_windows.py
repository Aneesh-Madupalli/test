"""Windows ownership check: find our own Chrome by --user-data-dir via PowerShell."""

import json
import os
import subprocess
import sys
from types import SimpleNamespace

import pytest

from agent_reach.runtime import browser
from agent_reach.runtime.result import ReachError

PROFILE = r"C:\Users\me\.agent-reach\browser\profile"
FLAG = f"--user-data-dir={PROFILE}"
CHROME = r"C:\Program Files\Google\Chrome\Application\chrome.exe"


@pytest.fixture
def home(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(browser, "is_running", lambda: False)
    return tmp_path


def _fake_ps(monkeypatch, stdout=None, exc=None):
    """Replace browser.subprocess.run; record every call."""
    calls = []

    def run(argv, **kwargs):
        calls.append((argv, kwargs))
        if exc is not None:
            raise exc
        return SimpleNamespace(stdout=stdout, returncode=0)

    monkeypatch.setattr(browser.subprocess, "run", run)
    return calls


def _rows(*rows):
    return json.dumps([{"ProcessId": pid, "CommandLine": cmd} for pid, cmd in rows])


def test_matches_our_profile_and_helpers_in_a_json_list(monkeypatch):
    out = _rows(
        (100, f"{CHROME} {FLAG} --remote-debugging-port=9222"),
        (101, f"{CHROME} --type=renderer {FLAG} --lang=en"),
        (200, f"{CHROME} --user-data-dir=C:\\Users\\me\\AppData\\Local\\Google\\Chrome\\User Data"),
        (300, f"{CHROME} --type=gpu-process"),
        (102, f"{CHROME} --type=utility {FLAG}"),
    )
    _fake_ps(monkeypatch, out)
    assert sorted(browser._windows_profile_pids(FLAG)) == [100, 101, 102]


def test_single_json_object_output(monkeypatch):
    _fake_ps(monkeypatch, json.dumps({"ProcessId": 42, "CommandLine": f"{CHROME} {FLAG}"}))
    assert browser._windows_profile_pids(FLAG) == [42]


def test_quoted_path_with_spaces(monkeypatch):
    flag = r"--user-data-dir=C:\a b\profile"
    _fake_ps(monkeypatch, _rows((7, f'"{CHROME}" "--user-data-dir=C:\\a b\\profile" --no-first-run')))
    assert browser._windows_profile_pids(flag) == [7]


def test_case_insensitive_path_match(monkeypatch):
    _fake_ps(monkeypatch, _rows((8, f"{CHROME} --user-data-dir={PROFILE.upper()} --x")))
    assert browser._windows_profile_pids(FLAG.lower()) == [8]


def test_sibling_prefix_folders_do_not_match(monkeypatch):
    _fake_ps(monkeypatch, _rows(
        (9, f"{CHROME} {FLAG}-before-cloak-123 --x"),
        (10, f"{CHROME} {FLAG}2"),
        (11, f'"{CHROME}" "{FLAG}2"'),
    ))
    assert browser._windows_profile_pids(FLAG) == []


def test_users_own_chrome_profile_does_not_match(monkeypatch):
    _fake_ps(monkeypatch, _rows(
        (12, f"{CHROME} --user-data-dir=C:\\Users\\me\\AppData\\Local\\Google\\Chrome\\User Data"),
        (13, f"{CHROME} --profile-directory=Default"),
    ))
    assert browser._windows_profile_pids(FLAG) == []


def test_null_command_line_own_pid_and_bad_pid_are_skipped(monkeypatch):
    out = json.dumps([
        {"ProcessId": 14, "CommandLine": None},
        {"ProcessId": os.getpid(), "CommandLine": f"{CHROME} {FLAG}"},
        {"ProcessId": "abc", "CommandLine": f"{CHROME} {FLAG}"},
        {"ProcessId": None, "CommandLine": f"{CHROME} {FLAG}"},
        {"ProcessId": 15, "CommandLine": f"{CHROME} {FLAG}"},
    ])
    _fake_ps(monkeypatch, out)
    assert browser._windows_profile_pids(FLAG) == [15]


@pytest.mark.parametrize("stdout", ["", "   \r\n", "not json {", "WARNING: something"])
def test_empty_or_invalid_output_returns_empty(monkeypatch, stdout):
    _fake_ps(monkeypatch, stdout)
    assert browser._windows_profile_pids(FLAG) == []


@pytest.mark.parametrize("exc", [
    FileNotFoundError("powershell.exe"),
    OSError("access denied"),
    subprocess.TimeoutExpired(cmd="powershell", timeout=10),
])
def test_powershell_failure_returns_empty(monkeypatch, exc):
    _fake_ps(monkeypatch, exc=exc)
    assert browser._windows_profile_pids(FLAG) == []


def test_call_uses_utf8_and_a_finite_timeout(monkeypatch):
    flag = "--user-data-dir=C:\\Users\\J\u00f6rg \u6797\\.agent-reach\\browser\\profile"
    calls = _fake_ps(monkeypatch, _rows((16, f'"{CHROME}" "{flag}"')))
    assert browser._windows_profile_pids(flag) == [16]

    assert len(calls) == 1
    argv, kwargs = calls[0]
    assert "powershell" in os.path.basename(str(argv[0])).lower()
    assert "-NoProfile" in argv and "-NonInteractive" in argv and "-Command" in argv
    script = argv[argv.index("-Command") + 1]
    assert "Win32_Process" in script and "ConvertTo-Json" in script
    assert kwargs.get("encoding") == "utf-8"
    assert kwargs.get("capture_output") is True
    timeout = kwargs.get("timeout")
    assert isinstance(timeout, (int, float)) and 0 < timeout < 120


def _as_windows(monkeypatch):
    fake_sys = SimpleNamespace(**{k: getattr(sys, k) for k in dir(sys) if not k.startswith("__")})
    fake_sys.platform = "win32"
    monkeypatch.setattr(browser, "sys", fake_sys)


def test_profile_pids_delegates_to_windows_helper_with_exact_flag(home, monkeypatch):
    _as_windows(monkeypatch)
    seen = []
    monkeypatch.setattr(browser, "_windows_profile_pids", lambda flag: seen.append(flag) or [5, 6])
    assert browser._profile_pids() == [5, 6]
    assert seen == [f"--user-data-dir={browser.profile_dir()}"]


def test_require_owned_accepts_our_orphaned_chrome(home, monkeypatch):
    _as_windows(monkeypatch)
    monkeypatch.setattr(browser, "is_running", lambda: True)
    monkeypatch.setattr(browser, "watcher_running", lambda: False)
    ours = f"--user-data-dir={browser.profile_dir()}"
    _fake_ps(monkeypatch, _rows((17, f'"{CHROME}" "{ours}" --remote-debugging-port=9222')))
    browser._require_owned()


def test_require_owned_rejects_another_profile(home, monkeypatch):
    _as_windows(monkeypatch)
    monkeypatch.setattr(browser, "is_running", lambda: True)
    monkeypatch.setattr(browser, "watcher_running", lambda: False)
    other = f"--user-data-dir={browser.profile_dir()}-other"
    _fake_ps(monkeypatch, _rows((18, f'"{CHROME}" "{other}" --remote-debugging-port=9222')))
    with pytest.raises(ReachError, match="unmanaged"):
        browser._require_owned()
