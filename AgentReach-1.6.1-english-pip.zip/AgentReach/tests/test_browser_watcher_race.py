"""stop()/_launch wait for a closing browser's watcher to free its lock before relaunching."""

import contextlib
from types import SimpleNamespace

import pytest

from agent_reach.runtime import browser, cdp


@pytest.fixture
def home(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(browser, "is_running", lambda: False)
    return tmp_path


@pytest.fixture
def clock(monkeypatch):
    """A fake clock for browser.wait_for: sleeping advances time instantly."""
    now = [0.0]

    def sleep(seconds):
        now[0] += seconds

    fake = SimpleNamespace(monotonic=lambda: now[0], sleep=sleep, time=lambda: 1_700_000_000.0 + now[0],
                           time_ns=lambda: int((1_700_000_000.0 + now[0]) * 1e9))
    monkeypatch.setattr(browser, "time", fake)
    return now


@pytest.fixture
def waits(monkeypatch):
    """Record the `seconds` of every browser.wait_for call."""
    calls = []
    real = browser.wait_for

    def spy(check, seconds, interval=1.0):
        calls.append(seconds)
        return real(check, seconds, interval)

    monkeypatch.setattr(browser, "wait_for", spy)
    return calls


def _watcher_exits_after(monkeypatch, polls):
    """watcher_running() is True for the first `polls` probes, then False."""
    probes = [0]

    def watcher_running():
        probes[0] += 1
        return probes[0] <= polls

    monkeypatch.setattr(browser, "watcher_running", watcher_running)
    return probes


def _fake_open_browser(monkeypatch):
    """is_running() is True until CDP Browser.close is sent."""
    state = {"open": True}

    def call(method, *a, **k):
        if method == "Browser.close":
            state["open"] = False
        return {}

    monkeypatch.setattr(browser, "is_running", lambda: state["open"])
    monkeypatch.setattr(browser, "_require_owned", lambda: None)
    monkeypatch.setattr(browser, "save_session", lambda: None)
    monkeypatch.setattr(cdp, "call", call)
    return state


def test_stop_waits_for_the_exiting_watcher_before_returning_true(home, monkeypatch, clock, waits):
    state = _fake_open_browser(monkeypatch)
    probes = _watcher_exits_after(monkeypatch, 3)
    assert browser.stop() is True
    assert not state["open"]
    assert probes[0] == 4  # kept polling until the watcher was gone
    assert browser.WATCHER_EXIT_WAIT in waits


def test_stop_returns_false_when_the_watcher_never_exits(home, monkeypatch, clock):
    _fake_open_browser(monkeypatch)
    monkeypatch.setattr(browser, "WATCHER_EXIT_WAIT", 0.5)
    monkeypatch.setattr(browser, "watcher_running", lambda: True)
    assert browser.stop() is False


def test_stop_without_wait_watcher_returns_once_the_port_is_closed(home, monkeypatch, clock):
    state = _fake_open_browser(monkeypatch)
    probes = _watcher_exits_after(monkeypatch, 10**6)
    assert browser.stop(wait_watcher=False) is True
    assert not state["open"]
    assert probes[0] == 0  # never waited on the watcher


def test_stop_with_browser_already_closed_waits_for_exiting_watcher(home, monkeypatch, clock, waits):
    probes = _watcher_exits_after(monkeypatch, 2)
    assert browser.stop() is True
    assert probes[0] == 3
    assert browser.WATCHER_EXIT_WAIT in waits


def test_stop_with_browser_already_closed_fails_if_watcher_stays(home, monkeypatch, clock):
    monkeypatch.setattr(browser, "WATCHER_EXIT_WAIT", 0.5)
    monkeypatch.setattr(browser, "watcher_running", lambda: True)
    assert browser.stop() is False


def _stub_launch(monkeypatch):
    """Stub everything _launch touches before and at subprocess.Popen; return the Popen call log."""
    popen = []

    def fake_popen(argv, **kwargs):
        popen.append(argv)
        return SimpleNamespace(poll=lambda: None, pid=4242)

    monkeypatch.setattr(browser, "ensure_chrome", lambda **k: "/fake/chrome")
    monkeypatch.setattr(browser, "_prepare_shared_profile", lambda: None)
    monkeypatch.setattr(browser, "can_load_extension", lambda: True)
    monkeypatch.setattr(browser, "extension_version", lambda: "1.0.0")
    monkeypatch.setattr(browser, "refresh_extension", lambda **k: pytest.fail("refreshed extension"))
    monkeypatch.setattr(browser, "_spawn_watcher", lambda: pytest.fail("spawned a Windows watcher"))
    monkeypatch.setattr(browser.subprocess, "Popen", fake_popen)
    monkeypatch.setattr(browser, "is_running", lambda: bool(popen))  # the browser opens once launched
    return popen


def test_launch_raises_busy_and_spawns_nothing_while_old_watcher_never_exits(home, monkeypatch, clock):
    from agent_reach.runtime.result import ReachError
    popen = _stub_launch(monkeypatch)
    monkeypatch.setattr(browser, "WATCHER_EXIT_WAIT", 0.5)
    monkeypatch.setattr(browser, "watcher_running", lambda: True)
    monkeypatch.setattr(browser, "ensure_chrome", lambda **k: pytest.fail("prepared a launch"))
    with pytest.raises(ReachError) as err:
        browser._launch("about:blank")
    assert err.value.code == "BUSY"
    assert "still closing" in str(err.value)
    assert popen == []


def test_launch_proceeds_once_old_watcher_exits_in_time(home, monkeypatch, clock, waits):
    popen = _stub_launch(monkeypatch)
    probes = _watcher_exits_after(monkeypatch, 3)
    browser._launch("about:blank")
    assert probes[0] >= 4
    assert browser.WATCHER_EXIT_WAIT in waits
    assert len(popen) == 1 and "agent_reach.runtime.browser_watcher" in popen[0]


def test_watcher_waits_watcher_exit_wait_for_its_lock_when_launching():
    import inspect

    from agent_reach.runtime import browser_watcher
    assert "browser.WATCHER_EXIT_WAIT if launch" in inspect.getsource(browser_watcher.watch)


def test_watcher_idle_close_does_not_wait_for_itself(home, monkeypatch):
    from agent_reach.runtime import bridge, browser_watcher
    stops = []

    def stop(timeout=10.0, **kwargs):
        stops.append(kwargs)
        return True

    monkeypatch.setattr(bridge, "start", lambda: None)
    monkeypatch.setattr(bridge, "close", lambda proc: None)
    monkeypatch.setattr(browser, "is_running", lambda: True)
    monkeypatch.setattr(browser, "observe_activity", lambda: None)
    monkeypatch.setattr(browser, "save_session", lambda: None)
    monkeypatch.setattr(browser, "last_used", lambda: 0.0)
    monkeypatch.setattr(browser, "start_lock", lambda wait=0: contextlib.nullcontext())
    monkeypatch.setattr(browser, "stop", stop)
    assert browser_watcher.watch(idle=0, poll=0.01) == "closed after idle"
    assert stops == [{"wait_watcher": False}]
