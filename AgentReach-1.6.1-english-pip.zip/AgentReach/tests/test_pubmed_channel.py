# -*- coding: utf-8 -*-
"""Offline tests for the ``pubmed`` channel (NCBI E-utilities)."""

import json
from urllib.parse import parse_qs, urlsplit

import pytest

from agent_reach.channels import pubmed as pm
from agent_reach.channels.pubmed import PubMedChannel
from agent_reach.runtime.result import BAD_INPUT, NOT_FOUND, UPSTREAM_BROKEN, ReachError


class FakeHTTP:
    """Records requested URLs and returns queued bodies in order."""

    def __init__(self, *bodies):
        self.bodies = list(bodies)
        self.urls = []

    def __call__(self, url, *, timeout, **kwargs):
        self.urls.append(url)
        body = self.bodies.pop(0)
        return body if isinstance(body, bytes) else json.dumps(body).encode("utf-8")


@pytest.fixture
def fake(monkeypatch):
    def install(*bodies):
        f = FakeHTTP(*bodies)
        monkeypatch.setattr(pm, "http_request", f)
        return f

    return install


def _query(url):
    return {k: v[0] for k, v in parse_qs(urlsplit(url).query).items()}


ESEARCH = {"esearchresult": {"count": "1234", "idlist": ["222", "111"]}}
ESUMMARY = {
    "result": {
        "uids": ["222", "111"],
        "111": {
            "title": "Second paper.",
            "authors": [{"name": "Solo A"}],
            "source": "Lancet",
            "pubdate": "2020",
            "articleids": [],
        },
        "222": {
            "title": "First paper.",
            "authors": [{"name": n} for n in ("Wilding JPH", "Batterham RL", "Calanna S", "Davies M")],
            "source": "N Engl J Med",
            "pubdate": "2021 Mar 18",
            "articleids": [{"idtype": "pubmed", "value": "222"}, {"idtype": "doi", "value": "10.1/abc"}],
        },
    }
}

ARTICLE_XML = b"""<?xml version="1.0"?>
<PubmedArticleSet><PubmedArticle>
<MedlineCitation><PMID>33567185</PMID>
<Article>
<Journal><JournalIssue><PubDate><Year>2021</Year><Month>Mar</Month><Day>18</Day></PubDate></JournalIssue>
<Title>The New England journal of medicine</Title></Journal>
<ArticleTitle>Once-Weekly Semaglutide in <i>Adults</i></ArticleTitle>
<Abstract>
<AbstractText Label="BACKGROUND">Obesity is <i>common</i> with CO<sub>2</sub>.</AbstractText>
<AbstractText Label="METHODS">We did a trial.</AbstractText>
</Abstract>
<AuthorList>
<Author><LastName>Wilding</LastName><Initials>JPH</Initials></Author>
<Author><CollectiveName>STEP 1 Study Group</CollectiveName></Author>
</AuthorList>
<PublicationTypeList><PublicationType>Randomized Controlled Trial</PublicationType></PublicationTypeList>
</Article>
<MeshHeadingList><MeshHeading><DescriptorName>Obesity</DescriptorName></MeshHeading></MeshHeadingList>
</MedlineCitation>
<PubmedData><ArticleIdList><ArticleId IdType="pubmed">33567185</ArticleId>
<ArticleId IdType="doi">10.1056/NEJMoa2032183</ArticleId></ArticleIdList></PubmedData>
</PubmedArticle></PubmedArticleSet>"""

NO_ABSTRACT_XML = b"""<PubmedArticleSet><PubmedArticle><MedlineCitation><PMID>5</PMID>
<Article><Journal><JournalIssue><PubDate><MedlineDate>1998 Dec-1999 Jan</MedlineDate></PubDate></JournalIssue>
<Title>J</Title></Journal><ArticleTitle>T</ArticleTitle></Article></MedlineCitation></PubmedArticle></PubmedArticleSet>"""


def test_can_handle():
    ch = PubMedChannel()
    assert ch.can_handle("https://pubmed.ncbi.nlm.nih.gov/33567185/")
    assert not ch.can_handle("https://example.com/33567185")
    assert not ch.can_handle("")


def test_search_two_calls_ordered_by_uids(fake):
    f = fake(ESEARCH, ESUMMARY)
    items = PubMedChannel()._pm_search(query="semaglutide", limit=5, timeout=5)
    assert len(f.urls) == 2
    q1, q2 = _query(f.urls[0]), _query(f.urls[1])
    assert urlsplit(f.urls[0]).path.endswith("/esearch.fcgi")
    assert q1 == {
        "db": "pubmed", "term": "semaglutide", "retmax": "5", "retmode": "json",
        "sort": "relevance", "tool": "agent-reach",
    }
    assert q2["id"] == "222,111" and q2["tool"] == "agent-reach"
    assert [i["title"] for i in items] == ["First paper.", "Second paper."]
    first = items[0]
    assert first["url"] == "https://pubmed.ncbi.nlm.nih.gov/222/"
    assert first["author"] == "Wilding JPH, Batterham RL, Calanna S et al."
    assert first["published_at"] == "2021-03-18"
    assert "N Engl J Med" in first["text"] and "DOI: 10.1/abc" in first["text"]
    assert first["raw"]["count"] == "1234" and first["raw"]["doi"] == "10.1/abc"
    assert "count" not in items[1]["raw"]
    assert items[1]["author"] == "Solo A" and items[1]["published_at"] == "2020"


def test_search_caps_limit(fake):
    f = fake(ESEARCH, ESUMMARY)
    PubMedChannel()._pm_search(query="x", limit=1000, timeout=5)
    assert _query(f.urls[0])["retmax"] == "100"


def test_search_empty_idlist_not_found(fake):
    fake({"esearchresult": {"count": "0", "idlist": []}})
    with pytest.raises(ReachError) as e:
        PubMedChannel()._pm_search(query="zzzz", limit=3, timeout=5)
    assert e.value.code == NOT_FOUND


@pytest.mark.parametrize("payload", [{"error": "API rate limit"}, {"esearchresult": {"ERROR": "bad term"}}])
def test_search_error_field_upstream_broken(fake, payload):
    fake(payload)
    with pytest.raises(ReachError) as e:
        PubMedChannel()._pm_search(query="x", limit=3, timeout=5)
    assert e.value.code == UPSTREAM_BROKEN
    assert "rate limit" in e.value.message or "bad term" in e.value.message


def test_format_authors():
    assert pm._format_authors([]) is None
    assert pm._format_authors(["A", "B", "C"]) == "A, B, C"
    assert pm._format_authors(["A", "B", "C", "D"]) == "A, B, C et al."


@pytest.mark.parametrize(
    "value,expected",
    [
        ("2021 Mar 18", "2021-03-18"),
        ("2021 Mar", "2021-03"),
        ("2021", "2021"),
        ("2021 Mar-Apr", None),
        ("Spring 2020", None),
        ("2021 Foo 3", None),
        ("", None),
        (None, None),
    ],
)
def test_normalize_date(value, expected):
    assert pm._normalize_date(value) == expected


def test_read_parses_xml(fake):
    f = fake(ARTICLE_XML)
    [item] = PubMedChannel()._pm_read(target="https://pubmed.ncbi.nlm.nih.gov/33567185/", timeout=5)
    assert len(f.urls) == 1
    q = _query(f.urls[0])
    assert q["id"] == "33567185" and q["rettype"] == "abstract" and q["retmode"] == "xml"
    assert q["tool"] == "agent-reach"
    assert item["title"] == "Once-Weekly Semaglutide in Adults"
    assert item["author"] == "Wilding JPH, STEP 1 Study Group"
    assert item["published_at"] == "2021-03-18"
    assert item["text"] == "BACKGROUND: Obesity is common with CO2.\n\nMETHODS: We did a trial."
    raw = item["raw"]
    assert raw["doi"] == "10.1056/NEJMoa2032183"
    assert raw["journal"] == "The New England journal of medicine"
    assert raw["mesh_terms"] == ["Obesity"]
    assert raw["publication_types"] == ["Randomized Controlled Trial"]


def test_read_no_abstract(fake):
    fake(NO_ABSTRACT_XML)
    [item] = PubMedChannel()._pm_read(target="5", timeout=5)
    assert item["text"] == "No abstract available."
    assert item["published_at"] is None
    assert item["raw"]["pubdate"] == "1998 Dec-1999 Jan"
    assert item["author"] is None


def test_read_missing_article_not_found(fake):
    fake(b"<PubmedArticleSet></PubmedArticleSet>")
    with pytest.raises(ReachError) as e:
        PubMedChannel()._pm_read(target="999999999", timeout=5)
    assert e.value.code == NOT_FOUND


def test_read_malformed_xml_upstream_broken(fake):
    fake(b"<PubmedArticleSet><oops")
    with pytest.raises(ReachError) as e:
        PubMedChannel()._pm_read(target="1", timeout=5)
    assert e.value.code == UPSTREAM_BROKEN


@pytest.mark.parametrize(
    "target,pmid",
    [
        ("33567185", "33567185"),
        (" PMID: 33567185 ", "33567185"),
        ("pmid 42", "42"),
        ("pubmed.ncbi.nlm.nih.gov/123", "123"),
        ("https://pubmed.ncbi.nlm.nih.gov/123/", "123"),
    ],
)
def test_parse_pmid_ok(target, pmid):
    assert pm._parse_pmid(target) == pmid


@pytest.mark.parametrize(
    "target", ["abc", "", "https://evil.com/123", "https://pubmed.ncbi.nlm.nih.gov/abc/", "12 34"]
)
def test_parse_pmid_bad(target):
    with pytest.raises(ReachError) as e:
        pm._parse_pmid(target)
    assert e.value.code == BAD_INPUT


@pytest.mark.parametrize(
    "url",
    [
        "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi",
        "https://evil.com/entrez/eutils/esearch.fcgi",
        "https://eutils.ncbi.nlm.nih.gov.evil.com/entrez/eutils/x",
        "https://user:pw@eutils.ncbi.nlm.nih.gov/entrez/eutils/x",
        "https://eutils.ncbi.nlm.nih.gov:8443/entrez/eutils/x",
        "https://eutils.ncbi.nlm.nih.gov/other",
    ],
)
def test_host_validation_rejects(url):
    with pytest.raises(ValueError):
        pm._validate_url(url)


def test_host_validation_accepts_built_urls():
    pm._validate_url(pm._eutils_url("esearch.fcgi", term="a&b=c"))
    assert _query(pm._eutils_url("esearch.fcgi", term="a&b=c"))["term"] == "a&b=c"
