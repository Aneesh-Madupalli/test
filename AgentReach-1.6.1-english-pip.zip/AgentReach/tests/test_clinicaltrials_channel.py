# -*- coding: utf-8 -*-
"""Offline tests for the ``clinicaltrials`` channel (ClinicalTrials.gov API v2)."""

import json
import urllib.error
from urllib.parse import parse_qs, urlsplit

import pytest

from agent_reach.channels import clinicaltrials as ct
from agent_reach.channels.clinicaltrials import ClinicalTrialsChannel
from agent_reach.runtime.result import BAD_INPUT, NOT_FOUND, ReachError


class _FakeHTTP:
    def __init__(self, payload):
        self.payload = payload
        self.urls: list = []

    def __call__(self, url, *, timeout, **kwargs):
        self.urls.append(url)
        return json.dumps(self.payload).encode("utf-8")


@pytest.fixture
def fake(monkeypatch):
    def install(payload):
        f = _FakeHTTP(payload)
        monkeypatch.setattr(ct, "http_request", f)
        return f

    return install


FULL = {
    "identificationModule": {
        "nctId": "NCT03548935",
        "briefTitle": "Semaglutide Effects",
        "officialTitle": "A Long Official Title",
        "acronym": "STEP 1",
    },
    "statusModule": {
        "overallStatus": "COMPLETED",
        "startDateStruct": {"date": "2018-06-04"},
        "primaryCompletionDateStruct": {"date": "2020-03"},
        "completionDateStruct": {"date": "2020-04-01"},
        "lastUpdatePostDateStruct": {"date": "2021-05-01"},
    },
    "sponsorCollaboratorsModule": {"leadSponsor": {"name": "Novo Nordisk A/S"}, "collaborators": [{"name": "Uni"}]},
    "descriptionModule": {"briefSummary": "word " * 300, "detailedDescription": "Details here."},
    "conditionsModule": {"conditions": ["Obesity"], "keywords": ["weight"]},
    "designModule": {"studyType": "INTERVENTIONAL", "phases": ["PHASE3"], "enrollmentInfo": {"count": 1961}},
    "armsInterventionsModule": {"interventions": [{"type": "DRUG", "name": "Semaglutide"}, {"name": "Placebo"}]},
    "eligibilityModule": {
        "eligibilityCriteria": "Inclusion Criteria:\n* BMI >= 30",
        "sex": "ALL",
        "minimumAge": "18 Years",
    },
    "contactsLocationsModule": {
        "locations": [
            {"facility": f"Site {i}", "city": "City", "country": "US", "status": "COMPLETED"} for i in range(55)
        ]
    },
    "outcomesModule": {"primaryOutcomes": [{"measure": "Change in body weight", "timeFrame": "68 weeks"}]},
}


def test_can_handle():
    ch = ClinicalTrialsChannel()
    assert ch.can_handle("https://clinicaltrials.gov/study/NCT03548935")
    assert ch.can_handle("https://www.clinicaltrials.gov/ct2/show/NCT03548935")
    assert not ch.can_handle("https://clinicaltrials.gov/")
    assert not ch.can_handle("https://example.com/study/NCT03548935")


@pytest.mark.parametrize(
    "target",
    [
        "NCT03548935",
        "nct03548935",
        " NCT03548935 ",
        "https://clinicaltrials.gov/study/NCT03548935",
        "https://www.clinicaltrials.gov/study/nct03548935?tab=results",
        "https://clinicaltrials.gov/ct2/show/NCT03548935",
        "clinicaltrials.gov/ct2/show/NCT03548935",
    ],
)
def test_parse_nct_id_ok(target):
    assert ct._parse_nct_id(target) == "NCT03548935"


@pytest.mark.parametrize(
    "target",
    ["abc", "NCT123", "NCT035489350", "https://evil.com/study/NCT03548935", "https://clinicaltrials.gov/search", ""],
)
def test_parse_nct_id_bad(target):
    with pytest.raises(ReachError) as exc:
        ct._parse_nct_id(target)
    assert exc.value.code == BAD_INPUT


def test_search_shaping_and_missing_modules(fake):
    f = fake(
        {
            "studies": [
                {"protocolSection": FULL},
                {"protocolSection": {"identificationModule": {"nctId": "NCT00000001"}}},
                {},
            ],
            "totalCount": 42,
        }
    )
    items = ClinicalTrialsChannel()._ct_search(query="semaglutide", limit=5, timeout=5)
    assert len(items) == 3
    first = items[0]
    assert first["title"] == "Semaglutide Effects"
    assert first["url"] == "https://clinicaltrials.gov/study/NCT03548935"
    assert first["author"] == "Novo Nordisk A/S"
    assert first["published_at"] == "2018-06-04"
    assert "Status: COMPLETED" in first["text"]
    assert "Phase: PHASE3" in first["text"]
    assert "Semaglutide (DRUG); Placebo" in first["text"]
    assert "Enrollment: 1961" in first["text"]
    assert "2018-06-04 → 2020-04-01" in first["text"]
    assert len(first["text"]) < 1000
    assert first["raw"]["totalCount"] == 42
    assert first["raw"]["nct_id"] == "NCT03548935"
    assert first["raw"]["sponsor"] == "Novo Nordisk A/S"
    assert items[1]["title"] == "NCT00000001"
    assert items[1]["author"] is None
    assert "totalCount" not in items[1]["raw"]
    assert items[2]["url"] is None

    q = parse_qs(urlsplit(f.urls[0]).query)
    assert urlsplit(f.urls[0]).netloc == "clinicaltrials.gov"
    assert q["query.term"] == ["semaglutide"]
    assert q["pageSize"] == ["5"]
    assert q["countTotal"] == ["true"]
    assert "filter.overallStatus" not in q


def test_search_caps_limit(fake):
    f = fake({"studies": [{"protocolSection": FULL}]})
    ClinicalTrialsChannel()._ct_search(query="x", limit=500, timeout=5)
    assert parse_qs(urlsplit(f.urls[0]).query)["pageSize"] == ["100"]


def test_search_status_filter(fake):
    f = fake({"studies": [{"protocolSection": FULL}]})
    ClinicalTrialsChannel()._ct_search(query="x", status="recruiting, Not_Yet_Recruiting", timeout=5)
    q = parse_qs(urlsplit(f.urls[0]).query)
    assert q["filter.overallStatus"] == ["RECRUITING,NOT_YET_RECRUITING"]


def test_search_status_invalid(fake):
    f = fake({"studies": []})
    with pytest.raises(ReachError) as exc:
        ClinicalTrialsChannel()._ct_search(query="x", status="recruiting,bogus", timeout=5)
    assert exc.value.code == BAD_INPUT
    assert f.urls == []


def test_search_empty_is_not_found(fake):
    fake({"studies": [], "totalCount": 0})
    with pytest.raises(ReachError) as exc:
        ClinicalTrialsChannel()._ct_search(query="zzzz", timeout=5)
    assert exc.value.code == NOT_FOUND


def test_read_formatting_and_location_cap(fake):
    f = fake({"protocolSection": FULL, "hasResults": True})
    [item] = ClinicalTrialsChannel()._ct_read(target="https://clinicaltrials.gov/ct2/show/nct03548935", timeout=5)
    assert f.urls[0].startswith("https://clinicaltrials.gov/api/v2/studies/NCT03548935?")
    text = item["text"]
    for heading in ("Status", "Design", "Conditions", "Interventions", "Primary outcomes", "Eligibility",
                    "Locations", "Summary", "Description"):
        assert f"## {heading}" in text, heading
    assert "BMI >= 30" in text
    assert "Change in body weight [68 weeks]" in text
    assert "- Site 49, City, US (COMPLETED)" in text
    assert "Site 50," not in text
    assert "+5 more" in text
    assert item["raw"]["hasResults"] is True
    assert item["raw"]["identificationModule"]["nctId"] == "NCT03548935"
    assert item["author"] == "Novo Nordisk A/S"


def test_read_sparse_record(fake):
    fake({"protocolSection": {"identificationModule": {"nctId": "NCT00000002"}, "statusModule": {
        "startDateStruct": {"date": "June 2020"}}}})
    [item] = ClinicalTrialsChannel()._ct_read(target="NCT00000002", timeout=5)
    assert item["title"] == "NCT00000002"
    assert item["published_at"] is None
    assert "## Locations" not in item["text"]


def test_read_missing_protocol_is_not_found(fake):
    fake({})
    with pytest.raises(ReachError) as exc:
        ClinicalTrialsChannel()._ct_read(target="NCT00000000", timeout=5)
    assert exc.value.code == NOT_FOUND


@pytest.mark.parametrize("code", [400, 404])
def test_read_http_400_404_is_not_found(monkeypatch, code):
    def boom(url, *, timeout, **kwargs):
        raise urllib.error.HTTPError(url, code, "nope", None, None)  # type: ignore[arg-type]

    monkeypatch.setattr(ct, "http_request", boom)
    with pytest.raises(ReachError) as exc:
        ClinicalTrialsChannel()._ct_read(target="NCT00000000", timeout=5)
    assert exc.value.code == NOT_FOUND


def test_read_http_500_propagates(monkeypatch):
    def boom(url, *, timeout, **kwargs):
        raise urllib.error.HTTPError(url, 500, "err", None, None)  # type: ignore[arg-type]

    monkeypatch.setattr(ct, "http_request", boom)
    with pytest.raises(urllib.error.HTTPError):
        ClinicalTrialsChannel()._ct_read(target="NCT00000000", timeout=5)


def test_read_bad_target_makes_no_request(fake):
    f = fake({})
    with pytest.raises(ReachError) as exc:
        ClinicalTrialsChannel()._ct_read(target="abc", timeout=5)
    assert exc.value.code == BAD_INPUT
    assert f.urls == []


@pytest.mark.parametrize(
    "url",
    [
        "http://clinicaltrials.gov/api/v2/studies",
        "https://evil.com/api/v2/studies",
        "https://clinicaltrials.gov.evil.com/api/v2/studies",
        "https://user:pw@clinicaltrials.gov/api/v2/studies",
        "https://clinicaltrials.gov:8443/api/v2/studies",
        "https://clinicaltrials.gov/study/NCT03548935",
    ],
)
def test_host_validation_rejects(url, fake):
    f = fake({})
    with pytest.raises(ValueError):
        ct._get_json(url, 5)
    assert f.urls == []


def test_host_validation_accepts_api(fake):
    fake({"ok": 1})
    assert ct._get_json("https://clinicaltrials.gov/api/v2/studies?format=json", 5) == {"ok": 1}
