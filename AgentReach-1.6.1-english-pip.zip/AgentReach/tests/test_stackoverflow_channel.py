# -*- coding: utf-8 -*-
"""Offline tests for the ``stackoverflow`` channel (StackExchange API 2.3).

The shared ``http_request`` is monkeypatched so URL building, response
decoding (plain and gzip), HTML-to-text shaping and error mapping run
without the network.
"""

import gzip
import io
import json
import urllib.error
from urllib.parse import parse_qs, urlsplit

import pytest

from agent_reach.channels import stackoverflow as so
from agent_reach.channels.stackoverflow import StackOverflowChannel
from agent_reach.runtime.result import (
    BAD_INPUT,
    NOT_FOUND,
    RATE_LIMITED,
    UPSTREAM_BROKEN,
    ReachError,
)


def _wrap(items, **extra):
    data = {"items": items, "has_more": False, "quota_remaining": 250, "quota_max": 300}
    data.update(extra)
    return data


class FakeHTTP:
    """Route fake responses by URL path; record every URL requested."""

    def __init__(self, routes, gzip_paths=()):
        self.routes = routes
        self.gzip_paths = set(gzip_paths)
        self.urls: list[str] = []

    def __call__(self, url, *, timeout, headers=None, **_):
        self.urls.append(url)
        assert headers and headers.get("Accept-Encoding") == "identity"
        path = urlsplit(url).path
        payload = self.routes[path]
        if isinstance(payload, BaseException):
            raise payload
        body = json.dumps(payload).encode("utf-8")
        return gzip.compress(body) if path in self.gzip_paths else body


def _install(monkeypatch, routes, gzip_paths=()):
    fake = FakeHTTP(routes, gzip_paths)
    monkeypatch.setattr(so, "http_request", fake)
    return fake


def _question(**over):
    q = {
        "question_id": 11227809,
        "title": "Why is processing a sorted array faster than an &quot;unsorted&quot; one?",
        "link": "https://stackoverflow.com/questions/11227809/why-is-processing",
        "owner": {"display_name": "GManNickG"},
        "creation_date": 1340805096,
        "score": 27000,
        "answer_count": 3,
        "is_answered": True,
        "accepted_answer_id": 2,
        "tags": ["java", "c++"],
        "body": "<p>Here is code &amp; text:</p><pre><code>for (i = 0; i &lt; n; ++i)\n    sum += a[i];\n</code></pre><p>Why?</p>",
    }
    q.update(over)
    return q


def _answer(answer_id, score, accepted=False, name="someone"):
    return {
        "answer_id": answer_id,
        "score": score,
        "is_accepted": accepted,
        "owner": {"display_name": name},
        "creation_date": 1340805200,
        "body": f"<p>Answer {answer_id} body</p>",
    }


# --- can_handle ---


def test_can_handle():
    ch = StackOverflowChannel()
    for url in [
        "https://stackoverflow.com/questions/11227809/slug",
        "https://stackoverflow.com/q/11227809",
    ]:
        assert ch.can_handle(url) is True, url
    for url in [
        "https://stackoverflow.com/users/1",
        "https://stackoverflow.com.evil.test/questions/1",
        "https://example.com/questions/1",
        "",
    ]:
        assert ch.can_handle(url) is False, url


# --- search ---


def test_search_shapes_items_and_unescapes(monkeypatch):
    fake = _install(monkeypatch, {"/2.3/search/advanced": _wrap([_question(), _question(question_id=2)])})
    items = StackOverflowChannel()._so_search(query="sorted array", limit=5, timeout=5)

    assert len(items) == 2
    first = items[0]
    assert first["title"] == 'Why is processing a sorted array faster than an "unsorted" one?'
    assert first["author"] == "GManNickG"
    assert first["url"].startswith("https://stackoverflow.com/questions/11227809")
    assert first["published_at"].startswith("2012-06-27")
    assert "Here is code & text:" in first["text"]
    assert "    for (i = 0; i < n; ++i)\n        sum += a[i];" in first["text"]
    assert "<p>" not in first["text"]
    assert first["raw"] == {
        "question_id": 11227809,
        "score": 27000,
        "answer_count": 3,
        "is_answered": True,
        "accepted_answer_id": 2,
        "tags": ["java", "c++"],
    }
    assert "backoff_seconds" not in first["raw"]

    query = parse_qs(urlsplit(fake.urls[0]).query)
    assert query["site"] == ["stackoverflow"]
    assert query["q"] == ["sorted array"]
    assert query["pagesize"] == ["5"]
    assert query["filter"] == ["withbody"]
    assert query["sort"] == ["relevance"]


def test_search_caps_limit_and_trims(monkeypatch):
    fake = _install(monkeypatch, {"/2.3/search/advanced": _wrap([_question(question_id=i) for i in range(5)])})
    items = StackOverflowChannel()._so_search(query="x", limit=2, timeout=5)
    assert len(items) == 2

    StackOverflowChannel()._so_search(query="x", limit=5000, timeout=5)
    assert parse_qs(urlsplit(fake.urls[-1]).query)["pagesize"] == ["100"]


def test_search_query_cannot_inject_params(monkeypatch):
    fake = _install(monkeypatch, {"/2.3/search/advanced": _wrap([_question()])})
    StackOverflowChannel()._so_search(query="a&site=evil&key=x", limit=1, timeout=5)
    query = parse_qs(urlsplit(fake.urls[0]).query)
    assert query["site"] == ["stackoverflow"]
    assert query["q"] == ["a&site=evil&key=x"]
    assert "key" not in query


def test_search_backoff_is_reported(monkeypatch):
    _install(monkeypatch, {"/2.3/search/advanced": _wrap([_question(), _question()], backoff=10)})
    items = StackOverflowChannel()._so_search(query="x", limit=2, timeout=5)
    assert items[0]["raw"]["backoff_seconds"] == 10
    assert "backoff_seconds" not in items[1]["raw"]


def test_search_empty_is_not_found(monkeypatch):
    _install(monkeypatch, {"/2.3/search/advanced": _wrap([])})
    with pytest.raises(ReachError) as exc:
        StackOverflowChannel()._so_search(query="zzzz", limit=3, timeout=5)
    assert exc.value.code == NOT_FOUND


# --- read ---


def _read_routes(answers, question=None):
    return {
        "/2.3/questions/11227809": _wrap([question or _question()]),
        "/2.3/questions/11227809/answers": _wrap(answers),
    }


def test_read_orders_accepted_first_and_formats(monkeypatch):
    answers = [_answer(1, 50, name="Top"), _answer(2, 10, accepted=True, name="Acc"), _answer(3, 70, name="Best")]
    _install(monkeypatch, _read_routes(answers))
    items = StackOverflowChannel()._so_read(target="https://stackoverflow.com/questions/11227809/slug", timeout=5)

    assert len(items) == 1
    item = items[0]
    text = item["text"]
    assert text.startswith("Here is code & text:")
    acc = text.index("--- Answer by Acc (score 10, accepted) ---")
    best = text.index("--- Answer by Best (score 70) ---")
    top = text.index("--- Answer by Top (score 50) ---")
    assert acc < best < top
    assert "Answer 2 body" in text
    assert item["title"].endswith('"unsorted" one?')
    raw = item["raw"]
    assert "body" not in raw
    assert raw["question_id"] == 11227809
    assert [a["answer_id"] for a in raw["answers"]] == [2, 3, 1]
    assert raw["answers"][0] == {"answer_id": 2, "score": 10, "is_accepted": True, "author": "Acc"}


def test_read_handles_gzip_bodies(monkeypatch):
    routes = _read_routes([_answer(9, 1, accepted=True)])
    _install(monkeypatch, routes, gzip_paths=set(routes))
    items = StackOverflowChannel()._so_read(target="11227809", timeout=5)
    assert "--- Answer by someone (score 1, accepted) ---" in items[0]["text"]


def test_read_caps_text(monkeypatch):
    big = _answer(1, 1)
    big["body"] = "<p>" + "x" * 300_000 + "</p>"
    _install(monkeypatch, _read_routes([big]))
    items = StackOverflowChannel()._so_read(target="11227809", timeout=5)
    assert len(items[0]["text"]) <= 200_100


def test_read_missing_question_is_not_found(monkeypatch):
    fake = _install(monkeypatch, {"/2.3/questions/42": _wrap([])})
    with pytest.raises(ReachError) as exc:
        StackOverflowChannel()._so_read(target="42", timeout=5)
    assert exc.value.code == NOT_FOUND
    assert len(fake.urls) == 1


# --- target parsing ---


@pytest.mark.parametrize(
    "target, expected",
    [
        ("11227809", 11227809),
        (" 123 ", 123),
        ("https://stackoverflow.com/questions/11227809", 11227809),
        ("https://stackoverflow.com/questions/11227809/why-is-processing", 11227809),
        ("https://www.stackoverflow.com/questions/5/slug?noredirect=1#comment", 5),
        ("stackoverflow.com/q/777", 777),
        ("https://stackoverflow.com/q/777/12345", 777),
    ],
)
def test_parse_question_id(target, expected):
    assert so._parse_question_id(target) == expected


@pytest.mark.parametrize(
    "target",
    ["abc", "", "0", "https://example.com/questions/1", "https://stackoverflow.com/users/1",
     "https://stackoverflow.com.evil.test/questions/1"],
)
def test_parse_question_id_rejects(target):
    with pytest.raises(ReachError) as exc:
        so._parse_question_id(target)
    assert exc.value.code == BAD_INPUT


def test_read_bad_target_makes_no_request(monkeypatch):
    fake = _install(monkeypatch, {})
    with pytest.raises(ReachError) as exc:
        StackOverflowChannel()._so_read(target="abc", timeout=5)
    assert exc.value.code == BAD_INPUT
    assert fake.urls == []


# --- error mapping ---


def test_quota_zero_is_rate_limited(monkeypatch):
    _install(monkeypatch, {"/2.3/search/advanced": _wrap([_question()], quota_remaining=0)})
    with pytest.raises(ReachError) as exc:
        StackOverflowChannel()._so_search(query="x", limit=1, timeout=5)
    assert exc.value.code == RATE_LIMITED


def _http_error(status, payload):
    body = json.dumps(payload).encode("utf-8")
    return urllib.error.HTTPError("https://api.stackexchange.com/2.3/x", status, "err", {}, io.BytesIO(body))


def test_throttle_502_is_rate_limited(monkeypatch):
    err = _http_error(400, {"error_id": 502, "error_name": "throttle_violation", "error_message": "too many"})
    _install(monkeypatch, {"/2.3/search/advanced": err})
    with pytest.raises(ReachError) as exc:
        StackOverflowChannel()._so_search(query="x", limit=1, timeout=5)
    assert exc.value.code == RATE_LIMITED


def test_throttle_502_in_ok_body_is_rate_limited(monkeypatch):
    _install(monkeypatch, {"/2.3/search/advanced": {"error_id": 502, "error_name": "throttle_violation",
                                                    "error_message": "slow down"}})
    with pytest.raises(ReachError) as exc:
        StackOverflowChannel()._so_search(query="x", limit=1, timeout=5)
    assert exc.value.code == RATE_LIMITED


def test_bad_parameter_is_bad_input(monkeypatch):
    err = _http_error(400, {"error_id": 400, "error_name": "bad_parameter", "error_message": "pagesize"})
    _install(monkeypatch, {"/2.3/search/advanced": err})
    with pytest.raises(ReachError) as exc:
        StackOverflowChannel()._so_search(query="x", limit=1, timeout=5)
    assert exc.value.code == BAD_INPUT


def test_other_api_error_is_upstream_broken(monkeypatch):
    err = _http_error(500, {"error_id": 500, "error_name": "internal_error", "error_message": "boom"})
    _install(monkeypatch, {"/2.3/search/advanced": err})
    with pytest.raises(ReachError) as exc:
        StackOverflowChannel()._so_search(query="x", limit=1, timeout=5)
    assert exc.value.code == UPSTREAM_BROKEN
    assert "boom" in exc.value.message


def test_plain_404_propagates_for_classify(monkeypatch):
    err = urllib.error.HTTPError("https://api.stackexchange.com/2.3/x", 404, "nf", {}, io.BytesIO(b"not json"))
    _install(monkeypatch, {"/2.3/search/advanced": err})
    with pytest.raises(urllib.error.HTTPError):
        StackOverflowChannel()._so_search(query="x", limit=1, timeout=5)


# --- host validation ---


@pytest.mark.parametrize(
    "url",
    [
        "http://api.stackexchange.com/2.3/search",
        "https://api.stackexchange.com.evil.test/2.3/search",
        "https://evil.test/2.3/search",
        "https://user@api.stackexchange.com/2.3/search",
        "https://api.stackexchange.com:8443/2.3/search",
        "https://api.stackexchange.com/2.2/search",
    ],
)
def test_validate_api_url_rejects(url):
    with pytest.raises(ValueError):
        so._validate_api_url(url)


def test_api_url_is_allowed():
    url = so._api_url("/questions/1", filter="withbody")
    so._validate_api_url(url)
    assert url.startswith("https://api.stackexchange.com/2.3/questions/1?")
    assert "site=stackoverflow" in url
