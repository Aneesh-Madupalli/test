# -*- coding: utf-8 -*-
"""Offline tests for the ``news`` channel (Google News RSS)."""

from urllib.parse import parse_qs, urlsplit

import pytest

from agent_reach.channels import news
from agent_reach.channels.news import NewsChannel
from agent_reach.runtime.result import BAD_INPUT, NOT_FOUND, UPSTREAM_BROKEN, ReachError


def _rss(items: str) -> bytes:
    return (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<rss version="2.0"><channel><title>Google News</title>'
        f"{items}</channel></rss>"
    ).encode("utf-8")


ITEM_OL = (
    "<item><title>Lilly raises guidance - Reuters</title>"
    "<link>https://news.google.com/rss/articles/AAA?oc=5</link>"
    '<guid isPermaLink="false">guid-1</guid>'
    "<pubDate>Fri, 07 Nov 2026 14:03:00 GMT</pubDate>"
    "<description>&lt;ol&gt;&lt;li&gt;&lt;a href=\"https://x\"&gt;Lilly raises guidance&lt;/a&gt;"
    "&amp;nbsp;&amp;nbsp;&lt;font&gt;Reuters&lt;/font&gt;&lt;/li&gt;"
    "&lt;li&gt;&lt;a href=\"https://y\"&gt;Shares &amp;amp; more&lt;/a&gt;&lt;/li&gt;&lt;/ol&gt;</description>"
    '<source url="https://www.reuters.com">Reuters</source></item>'
)
ITEM_PLAIN = (
    "<item><title>Market wrap - Not The Source</title>"
    "<link>https://news.google.com/rss/articles/BBB?oc=5</link>"
    '<guid isPermaLink="false">guid-2</guid>'
    "<pubDate>not a date</pubDate>"
    "<description>&lt;a href=\"https://z\"&gt;Market   wrap&lt;/a&gt;</description>"
    '<source url="https://www.cnbc.com">CNBC</source></item>'
)


@pytest.fixture
def fake_http(monkeypatch):
    calls = []
    state = {"body": _rss(ITEM_OL + ITEM_PLAIN)}

    def fake(url, *, timeout, **kwargs):
        calls.append(url)
        return state["body"]

    monkeypatch.setattr(news, "http_request", fake)
    return calls, state


# --- edition ---

@pytest.mark.parametrize(
    "raw,expected",
    [
        ("en-US", ("en-US", "US", "en")),
        ("EN-us", ("en-US", "US", "en")),
        ("en-gb", ("en-GB", "GB", "en")),
        ("de", ("de-DE", "DE", "de")),
        (" ja-JP ", ("ja-JP", "JP", "ja")),
    ],
)
def test_parse_edition_normalises(raw, expected):
    assert news._parse_edition(raw) == expected


@pytest.mark.parametrize("raw", ["xx_bad", "", "english", "en-USA", "e-US", "en-US-x", "1a-US", None])
def test_parse_edition_rejects_bad_input(raw):
    with pytest.raises(ReachError) as err:
        news._parse_edition(raw)
    assert err.value.code == BAD_INPUT


def test_search_url_exact(fake_http):
    calls, _ = fake_http
    NewsChannel()._news_search(query="eli lilly & co", lang="en-gb", limit=5, timeout=5)
    assert calls == [
        "https://news.google.com/rss/search?q=eli+lilly+%26+co&hl=en-GB&gl=GB&ceid=GB%3Aen"
    ]
    qs = parse_qs(urlsplit(calls[0]).query)
    assert qs == {"q": ["eli lilly & co"], "hl": ["en-GB"], "gl": ["GB"], "ceid": ["GB:en"]}


def test_top_url_exact(fake_http):
    calls, _ = fake_http
    NewsChannel()._news_top(lang="de", limit=1, timeout=5)
    assert calls == ["https://news.google.com/rss?hl=de-DE&gl=DE&ceid=DE%3Ade"]


def test_bad_lang_makes_no_request(fake_http):
    calls, _ = fake_http
    with pytest.raises(ReachError) as err:
        NewsChannel()._news_top(lang="xx_bad", limit=3, timeout=5)
    assert err.value.code == BAD_INPUT
    assert calls == []


def test_empty_query_is_bad_input(fake_http):
    with pytest.raises(ReachError) as err:
        NewsChannel()._news_search(query="  ", timeout=5)
    assert err.value.code == BAD_INPUT


# --- item shaping ---

def test_items_shape(fake_http):
    items = NewsChannel()._news_search(query="lilly", timeout=5)
    assert len(items) == 2
    first, second = items
    assert first["title"] == "Lilly raises guidance"
    assert first["url"] == "https://news.google.com/rss/articles/AAA?oc=5"
    assert first["author"] == "Reuters"
    assert first["published_at"] == "2026-11-07T14:03:00Z"
    assert first["text"] == "Lilly raises guidance Reuters\nShares & more"
    assert first["raw"] == {
        "source": "Reuters",
        "source_url": "https://www.reuters.com",
        "guid": "guid-1",
        "edition": "en-US",
    }
    # Suffix does not match the source: title stays intact.
    assert second["title"] == "Market wrap - Not The Source"
    assert second["published_at"] is None
    assert second["text"] == "Market wrap"


def test_strip_source_only_on_exact_suffix():
    assert news._strip_source("A - B - Reuters", "Reuters") == "A - B"
    assert news._strip_source("A - Reuters Health", "Reuters") == "A - Reuters Health"
    assert news._strip_source("A - Reuters", "") == "A - Reuters"
    assert news._strip_source(" - Reuters", "Reuters") == " - Reuters"


def test_date_conversion():
    assert news._to_iso("Fri, 07 Nov 2026 14:03:00 GMT") == "2026-11-07T14:03:00Z"
    assert news._to_iso("Fri, 07 Nov 2026 16:03:00 +0200") == "2026-11-07T14:03:00Z"
    assert news._to_iso("garbage") is None
    assert news._to_iso("") is None
    assert news._to_iso(None) is None


def test_html_to_text():
    assert news._html_to_text("<p>Hello&nbsp; <b>world</b> &amp; co</p>") == "Hello world & co"
    assert news._html_to_text("<ol><li>One</li><li>Two  <i>x</i></li></ol>") == "One\nTwo x"
    assert news._html_to_text("") is None
    assert news._html_to_text(None) is None


def test_limit_respected_and_capped(fake_http):
    _, state = fake_http
    assert len(NewsChannel()._news_top(limit=1, timeout=5)) == 1
    state["body"] = _rss(ITEM_PLAIN * 150)
    assert len(NewsChannel()._news_top(limit=500, timeout=5)) == 100


def test_bad_limit(fake_http):
    with pytest.raises(ReachError) as err:
        NewsChannel()._news_top(limit=0, timeout=5)
    assert err.value.code == BAD_INPUT


# --- error paths ---

def test_empty_feed_is_not_found(fake_http):
    _, state = fake_http
    state["body"] = _rss("")
    with pytest.raises(ReachError) as err:
        NewsChannel()._news_search(query="zzzz", timeout=5)
    assert err.value.code == NOT_FOUND
    assert err.value.message == "nothing found"


@pytest.mark.parametrize(
    "body",
    [
        b"<!doctype html><html><body>Before you continue to Google</body></html>",
        b"<html><body><p>consent</p></body></html>",
        b"",
        b"<rss><channel><item>",
    ],
)
def test_non_rss_is_upstream_broken(fake_http, body):
    _, state = fake_http
    state["body"] = body
    with pytest.raises(ReachError) as err:
        NewsChannel()._news_top(timeout=5)
    assert err.value.code == UPSTREAM_BROKEN
    assert err.value.message == "Google News did not return an RSS feed"


@pytest.mark.parametrize(
    "url",
    [
        "http://news.google.com/rss",
        "https://evil.com/rss",
        "https://news.google.com.evil.com/rss",
        "https://user:pw@news.google.com/rss",
        "https://news.google.com:8443/rss",
        "https://news.google.com/articles/x",
    ],
)
def test_validate_url_rejects(url):
    with pytest.raises(ValueError):
        news._validate_url(url)


def test_validate_url_accepts():
    news._validate_url("https://news.google.com/rss?hl=en-US")
    news._validate_url("https://NEWS.google.com/rss/search?q=x")


def test_fetch_validates_before_request(monkeypatch):
    called = []
    monkeypatch.setattr(news, "http_request", lambda *a, **k: called.append(a))
    with pytest.raises(ValueError):
        news._fetch("https://example.com/rss", 5)
    assert called == []


def test_can_handle_stays_false():
    ch = NewsChannel()
    for url in ["https://news.google.com/rss/articles/AAA", "https://example.com", ""]:
        assert ch.can_handle(url) is False
