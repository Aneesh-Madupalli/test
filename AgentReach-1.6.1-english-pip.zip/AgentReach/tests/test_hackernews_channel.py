# -*- coding: utf-8 -*-
"""Dedicated offline tests for the ``hackernews`` channel (Algolia HN API)."""

import json
from urllib.parse import parse_qs, urlsplit

import pytest

from agent_reach.channels import hackernews as hn
from agent_reach.channels.hackernews import HackerNewsChannel
from agent_reach.runtime.result import BAD_INPUT, NOT_FOUND, UPSTREAM_BROKEN, ReachError


class _FakeHTTP:
    """Records requested URLs and returns canned JSON bodies."""

    def __init__(self, payload):
        self.payload = payload
        self.calls: list = []

    def __call__(self, url, *, timeout, max_bytes=None, **_):
        self.calls.append(url)
        if isinstance(self.payload, bytes):
            return self.payload
        return json.dumps(self.payload).encode("utf-8")


def _stub(monkeypatch, payload):
    fake = _FakeHTTP(payload)
    monkeypatch.setattr(hn, "http_request", fake)
    return fake


def _hit(i, url="https://example.com/a"):
    return {
        "objectID": str(i),
        "title": f"Story {i}",
        "url": url,
        "author": "pg",
        "points": 10 + i,
        "num_comments": i,
        "created_at_i": 1160418111,
        "story_text": None,
    }


# --- can_handle ---

def test_can_handle():
    ch = HackerNewsChannel()
    for url in ["https://news.ycombinator.com/item?id=1", "http://NEWS.ycombinator.com/item?id=42"]:
        assert ch.can_handle(url) is True, url
    for url in ["https://news.ycombinator.com/", "https://example.com/item?id=1", "https://hn.algolia.com", ""]:
        assert ch.can_handle(url) is False, url


# --- search / top ---

def test_search_shapes_items_and_query(monkeypatch):
    fake = _stub(monkeypatch, {"hits": [_hit(1), _hit(2, url=None)]})
    items = HackerNewsChannel()._hn_search(query="llm agents & co", limit=5, timeout=3)
    q = parse_qs(urlsplit(fake.calls[0]).query)
    assert urlsplit(fake.calls[0]).path == "/api/v1/search"
    assert q == {"query": ["llm agents & co"], "tags": ["story"], "hitsPerPage": ["5"]}
    assert items[0]["title"] == "Story 1"
    assert items[0]["url"] == "https://example.com/a"
    assert items[0]["author"] == "pg"
    assert items[0]["published_at"] == "2006-10-09T18:21:51Z"
    assert items[0]["raw"]["points"] == 11
    assert items[0]["raw"]["num_comments"] == 1
    assert items[0]["raw"]["discussion_url"] == "https://news.ycombinator.com/item?id=1"
    assert items[1]["url"] == "https://news.ycombinator.com/item?id=2"


def test_search_respects_and_caps_limit(monkeypatch):
    fake = _stub(monkeypatch, {"hits": [_hit(i) for i in range(10)]})
    assert len(HackerNewsChannel()._hn_search(query="x", limit=3, timeout=3)) == 3
    HackerNewsChannel()._hn_search(query="x", limit=5000, timeout=3)
    assert parse_qs(urlsplit(fake.calls[1]).query)["hitsPerPage"] == ["100"]


def test_search_empty_is_not_found(monkeypatch):
    _stub(monkeypatch, {"hits": []})
    with pytest.raises(ReachError) as exc:
        HackerNewsChannel()._hn_search(query="zzzz", limit=3, timeout=3)
    assert exc.value.code == NOT_FOUND


def test_top_uses_front_page(monkeypatch):
    fake = _stub(monkeypatch, {"hits": [_hit(i) for i in range(5)]})
    items = HackerNewsChannel()._hn_top(limit=2, timeout=3)
    assert len(items) == 2
    q = parse_qs(urlsplit(fake.calls[0]).query)
    assert q == {"tags": ["front_page"], "hitsPerPage": ["2"]}


def test_invalid_json_is_upstream_broken(monkeypatch):
    _stub(monkeypatch, b"<html>oops</html>")
    with pytest.raises(ReachError) as exc:
        HackerNewsChannel()._hn_top(limit=2, timeout=3)
    assert exc.value.code == UPSTREAM_BROKEN


# --- read ---

def _story(children):
    return {
        "id": 1,
        "title": "Y Combinator",
        "url": "http://ycombinator.com",
        "author": "pg",
        "text": None,
        "points": 57,
        "created_at_i": 1160418111,
        "type": "story",
        "children": children,
    }


def test_read_flattens_nested_comments_and_strips_html(monkeypatch):
    tree = [
        {
            "author": "alice",
            "text": "Hello &amp; <i>welcome</i><p>second para",
            "children": [{"author": "bob", "text": "<a href=\"x\">link</a> &gt; reply", "children": []}],
        },
        {"author": "carol", "text": "top two", "children": []},
    ]
    fake = _stub(monkeypatch, _story(tree))
    [item] = HackerNewsChannel()._hn_read(target="https://news.ycombinator.com/item?id=1", timeout=3)
    assert fake.calls == ["https://hn.algolia.com/api/v1/items/1"]
    text = item["text"]
    assert "@alice: Hello & welcome" in text
    assert "second para" in text
    assert "\n  @bob: link > reply" in text
    assert text.index("@alice") < text.index("@bob") < text.index("@carol")
    assert "<" not in text.replace("--- comments ---", "")
    assert item["url"] == "http://ycombinator.com"
    assert item["raw"]["comment_count"] == 3
    assert item["raw"]["truncated"] is False
    assert "children" not in item["raw"]["story"]
    assert item["raw"]["story"]["points"] == 57


def test_read_story_text_without_url(monkeypatch):
    data = _story([])
    data.update(url=None, text="Ask HN: <b>why</b>?")
    _stub(monkeypatch, data)
    [item] = HackerNewsChannel()._hn_read(target="1", timeout=3)
    assert item["text"] == "Ask HN: why?"
    assert item["url"] == "https://news.ycombinator.com/item?id=1"


def test_read_caps_comment_count(monkeypatch):
    tree = [{"author": f"u{i}", "text": "hi", "children": []} for i in range(hn._MAX_COMMENTS + 50)]
    _stub(monkeypatch, _story(tree))
    [item] = HackerNewsChannel()._hn_read(target="1", timeout=3)
    assert item["raw"]["comment_count"] == hn._MAX_COMMENTS
    assert item["raw"]["truncated"] is True
    assert "[truncated" in item["text"]


def test_read_caps_total_characters(monkeypatch):
    tree = [{"author": "u", "text": "x" * 5000, "children": []} for _ in range(100)]
    _stub(monkeypatch, _story(tree))
    [item] = HackerNewsChannel()._hn_read(target="1", timeout=3)
    assert item["raw"]["truncated"] is True
    assert len(item["text"]) <= hn._MAX_TEXT_CHARS + 500


def test_read_missing_item_is_not_found(monkeypatch):
    _stub(monkeypatch, {"id": 5, "title": None, "text": None, "children": []})
    with pytest.raises(ReachError) as exc:
        HackerNewsChannel()._hn_read(target="5", timeout=3)
    assert exc.value.code == NOT_FOUND


# --- target parsing ---

@pytest.mark.parametrize(
    "target,expected",
    [
        ("1", 1),
        (" 8863 ", 8863),
        ("https://news.ycombinator.com/item?id=8863", 8863),
        ("news.ycombinator.com/item?id=42&p=2", 42),
    ],
)
def test_parse_item_id(target, expected):
    assert hn._parse_item_id(target) == expected


@pytest.mark.parametrize(
    "target",
    ["abc", "", "https://example.com/item?id=1", "https://news.ycombinator.com/item?id=x", "https://news.ycombinator.com/user?id=1"],
)
def test_parse_item_id_rejects_bad_input(target):
    with pytest.raises(ReachError) as exc:
        hn._parse_item_id(target)
    assert exc.value.code == BAD_INPUT


# --- host validation ---

@pytest.mark.parametrize(
    "url",
    [
        "http://hn.algolia.com/api/v1/search",
        "https://evil.com/api/v1/search",
        "https://hn.algolia.com.evil.com/api/v1/search",
        "https://user:pw@hn.algolia.com/api/v1/search",
        "https://hn.algolia.com:8443/api/v1/search",
    ],
)
def test_validate_api_url_rejects_other_hosts(url):
    with pytest.raises(ReachError):
        hn._validate_api_url(url)


def test_validate_api_url_accepts_algolia():
    hn._validate_api_url("https://hn.algolia.com/api/v1/items/1")
