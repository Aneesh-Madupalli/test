# Install or update Agent Reach (English pip edition)

For the person or AI doing the install. Run every command yourself. Each `agent-reach` command prints one JSON object; read `ok`, `result` and `error.hint`.

> ⚠️ The PyPI package named `agent-reach` is NOT this project. Never install that PyPI name; install from this folder or its git URL only.

## 0. Before you start

- You need Python 3.10 or later with pip:
  - Windows: `py --version` and `py -m pip --version`
  - macOS / Linux: `python3 --version` and `python3 -m pip --version`
- Is Agent Reach already installed? Run `agent-reach version`:
  - JSON with `"install_method": "editable"` or `"pip"`: go to [Update](#update).
  - JSON with another method (for example an earlier uv install): go to [Replace an existing install](#replace-an-existing-install).
  - `agent-reach` is not found: continue below.

## 1. Install

From the folder that contains `AgentReach` (or use a full path):

```bash
# Windows
py -m pip install --user -e .\AgentReach

# macOS / Linux
python3 -m pip install --user -e ./AgentReach
```

`-e` (editable) runs the code from this folder, so a `git pull` or local edit applies immediately. Leave out `-e` for a fixed copy.

If you install from a git host instead of a local folder:

```bash
py -m pip install --user "git+https://<your git host>/AgentReach.git"
```

Corporate networks: pip uses your existing `pip.ini` / `pip.conf` (for example an internal Artifactory mirror), so nothing extra is needed. If pip cannot reach any index, ask for your organisation's mirror URL and pass it with `--index-url`.

## 2. Set up

```bash
agent-reach setup
```

`setup` turns on the default channels (GitHub, YouTube, Web, V2EX, Bilibili) and installs the agent skill for every AI found on the machine (Claude Code, Codex, GitHub Copilot, ...). Show `result.installation_report.markdown` to the user as is; `agent-reach setup --text` prints the same report as plain text.

### `agent-reach` is not found

pip put the launcher in its user scripts folder, which is not on PATH. Find it:

```bash
py -c "import sysconfig; print(sysconfig.get_path('scripts', 'nt_user'))"         # Windows
python3 -c "import sysconfig; print(sysconfig.get_path('scripts', 'posix_user'))" # macOS / Linux
```

Add that folder to your user PATH (Windows: search "Edit environment variables for your account" → `Path` → New), then open a new terminal. Until then, every command also works as `py -m agent_reach <command>` (Windows) or `python3 -m agent_reach <command>`.

## Update

```bash
agent-reach update --check   # only checks whether a new version exists
agent-reach update           # upgrades, then syncs every added channel's tools and the skill
```

- **Editable install**: `update` never reinstalls the program. Update the folder first (for example `git pull`), then run `agent-reach update` to sync tools and the skill.
- **Regular pip install**: tell Agent Reach once where releases come from. `{version}` is replaced with the release number:
  ```bash
  agent-reach configure update-source "https://<your git host>/AgentReach/archive/refs/tags/v{version}.zip"
  ```
  `agent-reach update` then runs `python -m pip install --upgrade <that URL>` with the same Python that runs Agent Reach.

Tell the user each line of `result.user_actions`. If it fails, `error.hint` holds the exact command to run.

## Replace an existing install

Your channels, keys and logins under `~/.agent-reach/` are kept.

1. Remove the old program, for example `uv tool uninstall agent-reach` or `pipx uninstall agent-reach`.
2. Install this edition (step 1) and run `agent-reach setup` (step 2). `setup` refreshes the skill with the English version.
3. Open a new terminal and check `agent-reach version` shows `"install_method": "editable"` or `"pip"`.

## Later

- The user just says what they want, e.g. "add Xiaohongshu" → `agent-reach add <channel>`; "remove V2EX" → `agent-reach remove <channel>`.
- Keys are entered by the user, e.g. a Groq key for Xiaoyuzhou transcription: `agent-reach configure groq-key`.
- Everything else (usage, login, browser) is covered by the installed skill.

Problems and rolling back: [troubleshooting.md](troubleshooting.md).
