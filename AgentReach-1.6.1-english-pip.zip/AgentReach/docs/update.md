# Update Agent Reach

Installing and updating use one guide: see [install.md](install.md#update).

- Editable install (`pip install -e`): `git pull` in the AgentReach folder, then `agent-reach update`.
- Regular pip install: `agent-reach configure update-source <pip URL with {version}>` once, then `agent-reach update`.
