<h1 align="center">👁️ Agent Reach (English pip edition)</h1>

<p align="center">
  <strong>Let your AI agent reach the parts of the internet it can't reach on its own</strong>
</p>

<p align="center">
  Login-walled platforms, what's inside videos, Chinese platforms, clean structured data. One command, installed with plain <code>pip</code>.
</p>

<p align="center">
  <a href="LICENSE"><img src="https://img.shields.io/badge/License-MIT-blue.svg?style=for-the-badge" alt="MIT License"></a>
  <a href="https://www.python.org/"><img src="https://img.shields.io/badge/Python-3.10+-green.svg?style=for-the-badge&logo=python&logoColor=white" alt="Python 3.10+"></a>
</p>

> This is an English-only edition of [Panniantong/Agent-Reach](https://github.com/Panniantong/Agent-Reach) v1.6.1 (MIT). It differs from upstream in two ways:
>
> 1. **English only**: messages, the setup report, the agent skill and the docs are all in English.
> 2. **pip instead of uv**: install, update and uninstall use `python -m pip`. uv is not needed anywhere.
>
> Every channel and feature from upstream is kept. See [NOTICE](NOTICE) for attribution.

---

## Why Agent Reach?

CLI agents such as Claude Code, Codex and GitHub Copilot come with web search and page fetching, but they mostly can't reach:

- **Features that need a login**: listing an X account's posts, searching Reddit, reading LinkedIn job details or Xiaohongshu notes.
- **What's inside video**: YouTube and Bilibili subtitles, plus speech-to-text for YouTube videos and Xiaoyuzhou podcasts.
- **Chinese platforms**: Bilibili, Xiaohongshu, V2EX and Xueqiu, which general search covers poorly.
- **Clean structured data**: Xueqiu quotes, V2EX topics and replies, GitHub repos and issues, already cleaned up.
- **Research and developer sources**: PubMed abstracts, ClinicalTrials.gov studies, Stack Overflow answers, Hacker News threads and news headlines, from their public APIs.

Agent Reach installs and tests the tools behind these platforms for you, so your agent can use them with one command:

```bash
agent-reach channels                          # which channels exist and what each can do
agent-reach youtube search "LLM agents"       # agent-reach <channel> <action> [args]
agent-reach read https://www.v2ex.com/t/123   # picks the channel from the link
```

Every command prints one JSON object: `{schema_version, ok, channel, action, backend, items, meta, error}`.

---

## Supported Platforms

| Channel | Level | What it does | Needs |
|---|---|---|---|
| github | default | search repos, read a repo/README, read issues and PRs with comments | nothing |
| youtube | default | video info, search, subtitles, speech-to-text | nothing; speech-to-text needs a Groq or OpenAI key |
| web | default | web search, page reading (fallback) | nothing |
| v2ex | default | hot topics, nodes, topics with replies, users | nothing |
| bilibili | default | search, video info, trending, subtitles | nothing; subtitles need a login (QR scan) |
| hackernews | default | search stories, front page, read a story with its comments | nothing |
| stackoverflow | default | search questions, read a question with its answers | nothing (about 300 requests a day per IP) |
| pubmed | default | search biomedical papers, read abstracts | nothing |
| clinicaltrials | default | search clinical studies, read a full study record | nothing |
| news | default | news headlines for a topic, top stories (Google News) | nothing |
| reddit | optional | search posts, read text/comments, browse a subreddit | login |
| linkedin | optional | search jobs, read job details | public jobs need nothing; in-site search needs a login |
| xiaohongshu | optional | search notes, read text, view comments | login |
| xueqiu | optional | real-time quotes, stock search, hot posts, hot stocks | quotes need nothing; hot posts and stocks need a login |
| boss | optional | job and JD search (BOSS Zhipin) | login |
| xiaoyuzhou | optional | podcast transcription | Groq key |
| twitter | experimental | search tweets, profiles, user tweets, threads | login |
| facebook | experimental | search, profiles | login |
| instagram | experimental | user search, profiles, user posts | login |

- **default**: works right after install; you can remove one, and updates won't add it back.
- **optional**: say "add <name>" (or run `agent-reach add <channel>`) to turn it on; whatever it needs is installed for you.
- **experimental**: works, but the platform fights automation harder and it can break at any time.

---

## Quick Start

Requires Python 3.10+ and pip. Full guide: [docs/install.md](docs/install.md).

```bash
# Windows (from the folder that contains AgentReach)
py -m pip install --user -e .\AgentReach
agent-reach setup

# macOS / Linux
python3 -m pip install --user -e ./AgentReach
agent-reach setup
```

- `-e` (editable) means the code runs straight from this folder: edit or `git pull`, and the change applies immediately.
- `setup` turns on the default channels and installs the agent skill for Claude Code, Codex, GitHub Copilot and other AIs found on the machine.
- `agent-reach` not found? The pip user scripts folder is not on your PATH; see [docs/install.md](docs/install.md#agent-reach-is-not-found).
- Behind a corporate package mirror? pip uses your existing `pip.ini` / `pip.conf`, so nothing extra is needed.

> ⚠️ The PyPI package named `agent-reach` is NOT this project. Install from this folder or its git URL only.

---

## After Install: Managing It

Everything Agent Reach installs (each channel's tools, logins and settings) lives in one folder (`~/.agent-reach/`). Tell your agent in plain words, or run the command yourself:

| You say | Command |
|---|---|
| "How is Agent Reach doing?" | `agent-reach doctor --text` (offline), `agent-reach check <channel> --text` (live) |
| "Add Reddit" / "Remove Reddit" | `agent-reach add reddit` / `agent-reach remove reddit` |
| "My login expired" / "Log out" | `agent-reach login <channel>` (you log in yourself) / `agent-reach logout <channel>` |
| "Upgrade Agent Reach" | `agent-reach update` (see below) |
| "Uninstall Agent Reach" | `agent-reach uninstall --dry-run`, then `agent-reach uninstall` |
| "Let my other AI use it too" | `agent-reach skill link <that AI's skills folder>` |

### Updating

- **Editable install** (`pip install -e`, recommended): update the folder (`git pull`), then run `agent-reach update` to sync channel tools and the skill.
- **Regular pip install**: set where releases come from once, then `agent-reach update` runs `pip install --upgrade` for you:
  ```bash
  agent-reach configure update-source "https://<your git host>/AgentReach/archive/refs/tags/v{version}.zip"
  ```

Problems: [docs/troubleshooting.md](docs/troubleshooting.md).

---

## How it works

Each action on each platform has an ordered list of tools to try. Reading a Bilibili video tries bili-cli first and falls back to Bilibili's public API; reading a web page tries Jina Reader, then Exa. When a tool breaks, only that list changes; the way your agent calls Agent Reach stays the same.

Channel tools (bili-cli, yt-dlp helpers, OpenCLI, ffmpeg, Node.js, the dedicated browser) are installed privately under `~/.agent-reach/tools/`, each Python tool in its own `python -m venv`. Nothing needs admin rights.

---

## Security

- **Read-only**: it searches and reads; it never posts, comments, likes or sends messages.
- **It never logs in for you or asks for your password.** Some platforms reuse a login already on your computer (that one site only, your browser unchanged); a login window opens only when you really need to sign in again, and you do it yourself.
- **The dedicated browser is open to this computer only**; other machines can't connect to it.
- **Use a secondary account.** The reused login is usually your main account, and platforms may restrict accounts used for automation.
- **Never paste keys into a chat**: run `agent-reach configure groq-key` in your own terminal.
- **Check your organisation's policy** before using browser automation or login reuse on a managed device.

### Uninstall

`agent-reach uninstall --dry-run` lists what would be removed; `agent-reach uninstall` removes it. Only what Agent Reach installed is removed. Then remove the program itself:

```bash
py -m pip uninstall agent-reach        # Windows
python3 -m pip uninstall agent-reach   # macOS / Linux
```

---

## Development

```bash
py -m venv .venv
.venv\Scripts\python -m pip install -c constraints.txt -e ".[dev]"
.venv\Scripts\python -m pytest tests -q
```

See [CONTRIBUTING.md](CONTRIBUTING.md).

## Credits

Original project: [Panniantong/Agent-Reach](https://github.com/Panniantong/Agent-Reach) by Neo Reid (MIT).
Tools it builds on: [OpenCLI](https://github.com/jackwener/opencli) · [bili-cli](https://github.com/public-clis/bilibili-cli) · [boss-agent-cli](https://github.com/can4hou6joeng4/boss-agent-cli) · [yt-dlp](https://github.com/yt-dlp/yt-dlp) · [Jina Reader](https://github.com/jina-ai/reader) · [Exa](https://exa.ai)

## License

[MIT](LICENSE)
